"""Role-based data scoping. Every read and write that touches a student goes through here."""
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import Student, TimetableSlot, User, student_subjects


def visible_student_ids(db: Session, user: User) -> set[str] | None:
    """None means 'all students' (admin)."""
    if user.role == "admin":
        return None
    if user.role == "student":
        return {user.student_id} if user.student_id else set()
    if user.role == "parent":
        return set(db.scalars(select(Student.id).where(Student.parent_id == user.parent_id)))
    if user.role == "tutor":
        pairs = db.execute(select(TimetableSlot.class_id, TimetableSlot.subject_id).where(TimetableSlot.tutor_id == user.tutor_id)).all()
        if not pairs:
            return set()
        ids: set[str] = set()
        for class_id, subject_id in set(pairs):
            ids |= set(db.scalars(
                select(Student.id).join(student_subjects, student_subjects.c.student_id == Student.id)
                .where(Student.class_id == class_id, student_subjects.c.subject_id == subject_id)
            ))
        return ids
    return set()


def visible_class_ids(db: Session, user: User) -> set[str] | None:
    if user.role == "admin":
        return None
    if user.role == "tutor":
        return set(db.scalars(select(TimetableSlot.class_id).where(TimetableSlot.tutor_id == user.tutor_id)))
    ids = visible_student_ids(db, user) or set()
    return set(db.scalars(select(Student.class_id).where(Student.id.in_(ids)))) if ids else set()


def ensure_student_access(db: Session, user: User, student_id: str) -> Student:
    s = db.get(Student, student_id)
    allowed = visible_student_ids(db, user)
    if not s or (allowed is not None and student_id not in allowed):
        # 404 rather than 403 so the API does not reveal which student IDs exist
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Student not found.")
    return s


def ensure_tutor_teaches(db: Session, user: User, slot: TimetableSlot) -> None:
    if user.role == "admin":
        return
    if user.role != "tutor" or slot.tutor_id != user.tutor_id:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "You can only record for lessons you teach.")
