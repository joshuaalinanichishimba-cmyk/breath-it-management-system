<script setup lang="ts">
import { computed, ref } from 'vue'
import { useRouter } from 'vue-router'
import { Plus, Download, Search } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Pager from '@/components/ui/Pager.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import Avatar from '@/components/ui/Avatar.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import StudentFormModal from '@/components/domain/StudentFormModal.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useScope } from '@/composables/useScope'
import { usePager } from '@/composables/usePager'
import { iso, addDays } from '@/services/dates'
import { kwacha, pct } from '@/services/format'
import { attendanceRate } from '@/services/analytics'
import { saveFile, toCsv } from '@/services/download'

const store = useDb(); const ui = useUi(); const scope = useScope(); const router = useRouter()
const isAdmin = computed(() => scope.role.value === 'admin')
const q = ref(''); const grade = ref(''); const cls = ref(''); const status = ref('active'); const fees = ref('')
const since = addDays(iso(), -28)

const rows = computed(() => scope.students.value.map((s) => {
  const att = store.db.attendance.filter((a) => a.studentId === s.id && a.date >= since)
  return { s, att: attendanceRate(att), bal: store.balance(s.id), parent: store.parentMap.get(s.parentId) }
}))
const filtered = computed(() => {
  const t = q.value.trim().toLowerCase()
  return rows.value.filter(({ s, bal, parent }) =>
    (!t || `${s.firstName} ${s.lastName} ${s.studentNo} ${parent?.name ?? ''} ${parent?.phone ?? ''}`.toLowerCase().includes(t)) &&
    (!grade.value || s.gradeId === grade.value) && (!cls.value || s.classId === cls.value) && (!status.value || s.status === status.value) &&
    (!fees.value || (fees.value === 'owing' ? bal > 0 : bal <= 0)),
  ).sort((a, b) => a.s.lastName.localeCompare(b.s.lastName) || a.s.firstName.localeCompare(b.s.firstName))
})
const { page, pages, rows: pageRows, range } = usePager(filtered, 12)
const classOptions = computed(() => store.db.classes.filter((c) => scope.classIds.value.has(c.id) && (!grade.value || c.gradeId === grade.value)))
const showForm = ref(false)

async function exportCsv() {
  const head = ['Student no.', 'First name', 'Last name', 'Gender', 'Date of birth', 'Grade', 'Class', 'Status', 'Enrolled', 'Parent', 'Parent phone', 'Subjects', 'Attendance (4 wks)', ...(isAdmin.value ? ['Balance (K)'] : [])]
  const body = filtered.value.map(({ s, att, bal, parent }) => [s.studentNo, s.firstName, s.lastName, s.gender, s.dob, store.gradeName(s.gradeId), store.className(s.classId), s.status, s.enrolmentDate,
    parent?.name ?? '', parent?.phone ?? '', s.subjectIds.map(store.subjectName).join('; '), Number.isFinite(att) ? att.toFixed(0) + '%' : '', ...(isAdmin.value ? [bal.toFixed(2)] : [])])
  try { if ((await saveFile(`students-${iso()}.csv`, toCsv(head, body), 'text/csv')) === 'saved') ui.success('Student list exported', `${body.length} rows`) }
  catch (e) { ui.error('Export failed', (e as Error).message) }
}
</script>
<template>
  <div>
    <PageHeader :title="isAdmin ? 'Students' : 'My students'" :sub="`${scope.students.value.filter((s) => s.status === 'active').length} active of ${scope.students.value.length} registered`">
      <button class="btn btn-secondary" @click="exportCsv"><Download :size="15" />Export CSV</button>
      <button v-if="isAdmin" class="btn btn-primary" @click="showForm = true"><Plus :size="15" />Register student</button>
    </PageHeader>
    <div class="card">
      <div class="p-3 sm:p-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-[1fr_150px_150px_150px_150px] border-b border-line">
        <div class="relative"><Search :size="15" class="absolute left-3 top-1/2 -translate-y-1/2 text-faint" /><input v-model="q" class="input pl-9" placeholder="Name, student number or parent" aria-label="Search students" /></div>
        <select v-model="grade" class="select" aria-label="Grade"><option value="">All grades</option><option v-for="g in store.db.grades" :key="g.id" :value="g.id">{{ g.name }}</option></select>
        <select v-model="cls" class="select" aria-label="Class"><option value="">All classes</option><option v-for="c in classOptions" :key="c.id" :value="c.id">{{ c.name }}</option></select>
        <select v-model="status" class="select" aria-label="Status"><option value="">Any status</option><option value="active">Active</option><option value="inactive">Inactive</option><option value="suspended">Suspended</option><option value="completed">Completed</option></select>
        <select v-if="isAdmin" v-model="fees" class="select" aria-label="Fees"><option value="">Any fee status</option><option value="owing">Owing</option><option value="clear">Fully paid</option></select>
      </div>
      <div v-if="filtered.length" class="table-wrap">
        <table class="tbl">
          <thead><tr><th>Student</th><th>Grade & class</th><th v-if="isAdmin">Parent / guardian</th><th>Subjects</th><th>Attendance</th><th v-if="isAdmin" class="text-right">Balance</th><th>Status</th></tr></thead>
          <tbody>
            <tr v-for="{ s, att, bal, parent } in pageRows" :key="s.id" class="clickable" tabindex="0" @click="router.push(`/students/${s.id}`)" @keydown.enter="router.push(`/students/${s.id}`)">
              <td><div class="flex items-center gap-2.5"><Avatar :name="`${s.firstName} ${s.lastName}`" :size="30" /><div><div class="font-medium">{{ s.firstName }} {{ s.lastName }}</div><div class="text-[12px] text-muted tnum">{{ s.studentNo }}</div></div></div></td>
              <td class="whitespace-nowrap">{{ store.gradeName(s.gradeId) }}<div class="text-[12px] text-muted">{{ store.className(s.classId) }}</div></td>
              <td v-if="isAdmin" class="whitespace-nowrap">{{ parent?.name }}<div class="text-[12px] text-muted tnum">{{ parent?.phone }}</div></td>
              <td class="tnum">{{ s.subjectIds.length }}</td>
              <td><span v-if="Number.isFinite(att)" :class="['tnum', att < store.db.settings.lowAttendanceThreshold ? 'text-bad font-medium' : '']">{{ pct(att) }}</span><span v-else class="text-faint">—</span></td>
              <td v-if="isAdmin" :class="['text-right tnum font-medium', bal > 0 ? 'text-bad' : 'text-muted']">{{ bal > 0 ? kwacha(bal) : 'Paid' }}</td>
              <td><StatusBadge :status="s.status" /></td>
            </tr>
          </tbody>
        </table>
      </div>
      <EmptyState v-else title="No students match these filters" body="Clear the search or choose a different grade, class or status.">
        <button class="btn btn-secondary" @click="q = ''; grade = ''; cls = ''; status = ''; fees = ''">Clear filters</button>
      </EmptyState>
      <Pager v-if="filtered.length" v-model="page" :pages="pages" :range="range" />
    </div>
    <StudentFormModal :open="showForm" @close="showForm = false" @saved="(s) => router.push(`/students/${s.id}`)" />
  </div>
</template>
