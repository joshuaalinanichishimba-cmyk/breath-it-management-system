<script setup lang="ts">
import { ref } from 'vue'
import { useRoute, useRouter, RouterLink } from 'vue-router'
import { LogIn, ArrowRight } from 'lucide-vue-next'
import BrandMark from '@/components/ui/BrandMark.vue'
import { useAuth } from '@/stores/auth'
import { useUi } from '@/stores/ui'
import { DEMO_MODE } from '@/config'
import { DEMO_ACCOUNTS, ROLE_LABEL } from '@/services/demo/accounts'

const auth = useAuth(); const ui = useUi(); const router = useRouter(); const route = useRoute()
const email = ref(''); const password = ref(''); const error = ref(''); const busy = ref(false)

async function submit() {
  error.value = ''
  if (!email.value || !password.value) { error.value = 'Enter your email and password.'; return }
  busy.value = true
  try {
    const u = await auth.login(email.value, password.value)
    ui.success(u.role === 'admin' ? 'Welcome back' : `Welcome, ${u.name.split(' ')[0]}`)
    router.push(typeof route.query.redirect === 'string' ? route.query.redirect : '/dashboard')
  } catch (e) { error.value = (e as Error).message } finally { busy.value = false }
}
function useAccount(e: string, p: string) { email.value = e; password.value = p; submit() }
</script>

<template>
  <div class="min-h-full grid lg:grid-cols-[1fr_520px]">
    <!-- Story side -->
    <section class="hidden lg:flex flex-col justify-between p-12 bg-brand text-brand-ink relative overflow-hidden">
      <BrandMark :size="38" on-brand />
      <div class="relative max-w-[30rem]">
        <p class="text-[34px] leading-[1.12] font-semibold tracking-[-0.02em]">Every register, mark and kwacha — in one place.</p>
        <p class="mt-4 text-[15px] text-brand-ink/80 leading-relaxed">Management tracks fees and attendance, tutors record marks in minutes, and parents in Kaunda Square and beyond can follow their children’s progress from a phone.</p>
      </div>
      <dl class="relative grid grid-cols-3 gap-6 text-[13px]">
        <div><dt class="text-brand-ink/70">Grades</dt><dd class="font-semibold text-[15px]">7, 8, 9, 12 & GCE</dd></div>
        <div><dt class="text-brand-ink/70">Subjects</dt><dd class="font-semibold text-[15px]">16 configured</dd></div>
        <div><dt class="text-brand-ink/70">Portals</dt><dd class="font-semibold text-[15px]">4 roles</dd></div>
      </dl>
      <svg class="absolute -right-24 top-1/2 -translate-y-1/2 opacity-[0.09]" width="560" height="560" viewBox="0 0 32 32" aria-hidden="true">
        <path d="M4 22c5-10 19-10 24 0M8.5 16c4-6 11-6 15 0M12.5 10.5c2-2.6 5-2.6 7 0" stroke="currentColor" stroke-width="1.1" fill="none" stroke-linecap="round" />
      </svg>
    </section>

    <!-- Form side -->
    <section class="flex flex-col justify-center px-5 sm:px-10 py-10 bg-surface">
      <div class="w-full max-w-[400px] mx-auto">
        <BrandMark class="lg:hidden mb-8" />
        <h1 class="text-[24px] font-semibold tracking-[-0.015em]">Sign in</h1>
        <p class="sub mt-1">Breath It Tuition Centre Management System</p>
        <form class="mt-6 grid gap-4" @submit.prevent="submit">
          <div><label class="label" for="email">Email</label><input id="email" v-model="email" type="email" autocomplete="username" class="input h-10" /></div>
          <div><label class="label" for="pw">Password</label><input id="pw" v-model="password" type="password" autocomplete="current-password" class="input h-10" /></div>
          <p v-if="error" class="field-error text-[13px]" role="alert">{{ error }}</p>
          <button class="btn btn-primary h-10" :disabled="busy"><LogIn :size="16" />{{ busy ? 'Signing in…' : 'Sign in' }}</button>
        </form>

        <div v-if="DEMO_MODE" class="mt-8">
          <div class="flex items-baseline justify-between">
            <h2 class="text-[13.5px] font-semibold">Demo accounts</h2>
            <span class="text-[12px] text-muted">password for all: <code class="font-semibold text-ink">demo1234</code></span>
          </div>
          <div class="mt-2 grid gap-2">
            <button v-for="a in DEMO_ACCOUNTS" :key="a.id" type="button" class="group text-left card px-3.5 py-2.5 hover:border-brand flex items-center gap-3" @click="useAccount(a.email, a.password)">
              <span class="badge badge-brand w-[92px] justify-center">{{ ROLE_LABEL[a.role] }}</span>
              <span class="flex-1 min-w-0">
                <span class="block text-[13px] font-medium truncate">{{ a.email }}</span>
                <span class="block text-[12px] text-muted truncate">{{ a.name }} · {{ a.blurb }}</span>
              </span>
              <ArrowRight :size="15" class="text-faint group-hover:text-brand" />
            </button>
          </div>
          <p class="mt-3 text-[12px] text-muted leading-relaxed">New family? The public <RouterLink to="/enquire" class="text-brand hover:underline">enquiry form</RouterLink> sends enquiries straight to Admissions. These accounts exist only in the demonstration build. The production system signs users in through the secured API with hashed passwords.</p>
        </div>
      </div>
    </section>
  </div>
</template>
