export type Role = 'admin' | 'tutor' | 'student' | 'parent'

export interface SessionUser {
  id: string
  name: string
  email: string
  role: Role
  /** tutorId / studentId / parentId depending on role */
  linkedId?: string
}

export interface Grade { id: string; name: string; order: number; examLevel: string; active: boolean }
export interface Subject { id: string; name: string; code: string; gradeIds: string[]; active: boolean }

export interface Parent {
  id: string
  name: string
  relationship: 'Mother' | 'Father' | 'Guardian' | 'Aunt' | 'Uncle' | 'Grandparent'
  phone: string
  altPhone?: string
  email?: string
  address: string
  occupation?: string
  portalAccess: boolean
}

export type TutorStatus = 'active' | 'on_leave' | 'inactive'
export interface Tutor {
  id: string
  staffNo: string
  firstName: string
  lastName: string
  gender: 'Female' | 'Male'
  phone: string
  email: string
  qualification: string
  subjectIds: string[]
  hireDate: string
  status: TutorStatus
}

export interface ClassGroup {
  id: string
  name: string
  gradeId: string
  classTutorId: string
  room: string
  capacity: number
  active: boolean
}

export type StudentStatus = 'active' | 'inactive' | 'suspended' | 'completed'
export interface Student {
  id: string
  studentNo: string
  firstName: string
  lastName: string
  dob: string
  gender: 'Female' | 'Male'
  gradeId: string
  classId: string
  parentId: string
  altContact?: string
  address: string
  enrolmentDate: string
  subjectIds: string[]
  status: StudentStatus
  notes?: string
}

export interface EnrolmentEvent { id: string; studentId: string; date: string; action: string; detail: string }

export interface Lesson {
  id: string
  classId: string
  subjectId: string
  tutorId: string
  /** 1 = Monday … 6 = Saturday */
  day: number
  start: string
  end: string
  room: string
}

export type AttendanceStatus = 'present' | 'absent' | 'late'
export interface AttendanceRecord {
  id: string
  studentId: string
  lessonId: string
  date: string
  status: AttendanceStatus
  recordedBy: string
  recordedAt: string
}

export type AssessmentType = 'Test' | 'Assignment' | 'Mock Exam' | 'End of Term Exam'
export interface Assessment {
  id: string
  studentId: string
  subjectId: string
  type: AssessmentType
  title: string
  maxMarks: number
  marks: number
  date: string
  term: string
  comment: string
  tutorId: string
}

export type FeeCategory = 'Tuition' | 'Registration' | 'Examination' | 'Materials' | 'Discount'
export interface FeeStructure { id: string; gradeId: string; category: FeeCategory; amount: number; frequency: 'per term' | 'once'; description: string }

export interface Charge {
  id: string
  studentId: string
  category: FeeCategory
  term: string
  amount: number
  description: string
  issuedOn: string
  dueDate: string
}

export type PaymentMethod = 'Cash' | 'Mobile Money' | 'Bank Transfer' | 'Card'
export type MobileNetwork = 'Airtel' | 'MTN' | 'Zamtel'
export type GatewayStatus = 'awaiting_customer' | 'confirmed' | 'declined' | 'timed_out'
export type PaymentStatus = 'pending' | 'verified' | 'rejected'
export interface Payment {
  id: string
  reference: string
  receiptNo?: string
  studentId: string
  amount: number
  date: string
  method: PaymentMethod
  category: FeeCategory
  term: string
  externalRef?: string
  recordedBy: string
  recordedAt: string
  status: PaymentStatus
  verifiedBy?: string
  verifiedAt?: string
  /** office = recorded by staff; online = paid by the parent in the app through the payment gateway */
  channel: 'office' | 'online'
  network?: MobileNetwork
  payerPhone?: string
  gatewayRef?: string
  gatewayStatus?: GatewayStatus
  /** Outstanding balance on the student's account right after this payment was verified */
  balanceAfter: number
  notes?: string
}

export type Audience = 'everyone' | 'parents' | 'students' | 'tutors' | 'class'
export interface Announcement {
  id: string
  title: string
  body: string
  audience: Audience
  classId?: string
  priority: 'normal' | 'important'
  authorId: string
  authorName: string
  createdAt: string
  /** in-app delivery is real; SMS / WhatsApp record intent only until a provider is configured */
  channels: { inApp: true; sms: boolean; whatsapp: boolean }
}

export interface Material {
  id: string
  title: string
  description: string
  kind: 'Notes' | 'Worksheet' | 'Past paper' | 'Link'
  subjectId: string
  classId: string
  tutorId: string
  /** Tutor-written notes (downloadable as a text file in the demo) */
  content?: string
  link?: string
  createdAt: string
}

export interface AuditEntry {
  id: string
  at: string
  actorId: string
  actorName: string
  action: string
  entity: string
  entityId: string
  detail: string
}

export interface CentreSettings {
  centreName: string
  tagline: string
  address: string
  phone: string
  email: string
  currency: 'ZMW'
  currentTerm: string
  terms: { name: string; start: string; end: string }[]
  receiptFooter: string
  smsProvider: string | null
  whatsappProvider: string | null
  lowAttendanceThreshold: number
  showFeesToStudents: boolean
  brand: { primary: string; logoDataUrl: string | null }
  onlinePayments: {
    enabled: boolean
    gateway: string | null
    methods: { airtel: boolean; mtn: boolean; zamtel: boolean; card: boolean; bank: boolean }
    passFeeToPayer: boolean
    feePercent: number
    bank: { bankName: string; accountName: string; accountNumber: string; branch: string }
  }
  referralReward: number
  reminderTemplate: string
}

export type LeadStage = 'new' | 'contacted' | 'trial' | 'enrolled' | 'lost'
export type LeadSource = 'Walk-in' | 'WhatsApp' | 'Facebook' | 'Referral' | 'Flyer' | 'School visit' | 'Website'
export interface Lead {
  id: string
  childName: string
  gradeId: string
  subjectIds: string[]
  parentName: string
  phone: string
  source: LeadSource
  referredByParentId?: string
  stage: LeadStage
  createdAt: string
  followUpOn?: string
  notes: string
  lostReason?: string
  studentId?: string
  rewardApplied?: boolean
}
export interface ReminderLog { id: string; parentId: string; at: string; channel: 'WhatsApp' | 'SMS'; amount: number }

export interface DemoDatabase {
  version: number
  generatedAt: string
  settings: CentreSettings
  grades: Grade[]
  subjects: Subject[]
  parents: Parent[]
  tutors: Tutor[]
  classes: ClassGroup[]
  students: Student[]
  enrolmentEvents: EnrolmentEvent[]
  lessons: Lesson[]
  attendance: AttendanceRecord[]
  assessments: Assessment[]
  feeStructures: FeeStructure[]
  charges: Charge[]
  payments: Payment[]
  announcements: Announcement[]
  materials: Material[]
  audit: AuditEntry[]
  leads: Lead[]
  reminders: ReminderLog[]
  referralCodes: Record<string, string>
  counters: Record<string, number>
}
