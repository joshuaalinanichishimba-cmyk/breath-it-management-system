import { computed } from 'vue'
import { useDb } from '@/stores/db'
import { useScope } from './useScope'

export function useAnnouncements() {
  const store = useDb(); const scope = useScope()
  return computed(() => store.db.announcements.filter((a) => {
    switch (scope.role.value) {
      case 'admin': return true
      case 'tutor': return ['everyone', 'tutors'].includes(a.audience) || (a.audience === 'class' && scope.classIds.value.has(a.classId ?? ''))
      case 'student': return ['everyone', 'students'].includes(a.audience) || (a.audience === 'class' && scope.classIds.value.has(a.classId ?? ''))
      case 'parent': return ['everyone', 'parents'].includes(a.audience) || (a.audience === 'class' && scope.classIds.value.has(a.classId ?? ''))
      default: return false
    }
  }).sort((a, b) => b.createdAt.localeCompare(a.createdAt)))
}
