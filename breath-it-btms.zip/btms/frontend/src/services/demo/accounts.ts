/**
 * DEMONSTRATION ACCOUNTS ONLY.
 * These credentials exist purely so the owners can explore each role during a presentation.
 * They are never used in connected mode, where authentication is handled by the FastAPI backend
 * (bcrypt-hashed passwords, signed JWT access tokens). Do not reuse these values anywhere real.
 */
import type { Role, SessionUser } from '@/types'

export interface DemoAccount extends SessionUser { password: string; blurb: string }

export const DEMO_ACCOUNTS: DemoAccount[] = [
  { id: 'admin', role: 'admin', name: 'Centre Administrator', email: 'admin@breathit.demo', password: 'demo1234', blurb: 'Owner and management view' },
  { id: 'u-t1', role: 'tutor', name: 'Chanda Mwila', email: 'tutor@breathit.demo', password: 'demo1234', linkedId: 't1', blurb: 'Mathematics tutor' },
  { id: 'u-s01', role: 'student', name: 'Natasha Banda', email: 'student@breathit.demo', password: 'demo1234', linkedId: 's01', blurb: 'Grade 12 student' },
  { id: 'u-p01', role: 'parent', name: 'Mutale Banda', email: 'parent@breathit.demo', password: 'demo1234', linkedId: 'p01', blurb: 'Parent of Natasha and John' },
]

export const ROLE_LABEL: Record<Role, string> = { admin: 'Administrator', tutor: 'Tutor', student: 'Student', parent: 'Parent' }

export function demoAuthenticate(email: string, password: string): SessionUser | null {
  const acc = DEMO_ACCOUNTS.find((a) => a.email.toLowerCase() === email.trim().toLowerCase() && a.password === password)
  if (!acc) return null
  const { password: _pw, blurb: _b, ...user } = acc
  return user
}
