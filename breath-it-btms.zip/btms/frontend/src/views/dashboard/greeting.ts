import { DAY_NAMES, fmtDate, iso, isoWeekday } from '@/services/dates'
export function greeting(name: string) {
  const h = new Date().getHours()
  const part = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'
  return name ? `${part}, ${name.split(' ')[0]}` : part
}
export const todayLabel = () => `${DAY_NAMES[isoWeekday(iso())]}, ${fmtDate(iso())}`
