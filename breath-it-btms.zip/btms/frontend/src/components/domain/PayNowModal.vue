<script setup lang="ts">
/**
 * Parent / student checkout.
 * Mobile money: the payment gateway pushes a PIN prompt to the payer's phone; the gateway's callback confirms the payment,
 * which verifies it and issues the receipt automatically. Cards go to the gateway's hosted page (we never see card numbers).
 * Bank transfers are reported here and matched by the office against the statement.
 * In the demo there is no gateway: the prompt and callback are simulated and clearly labelled.
 */
import { computed, onBeforeUnmount, reactive, ref, watch } from 'vue'
import { Smartphone, CreditCard, Landmark, CheckCircle2, XCircle, Copy, Loader2, ShieldCheck } from 'lucide-vue-next'
import Modal from '@/components/ui/Modal.vue'
import ReceiptModal from './ReceiptModal.vue'
import { useDb } from '@/stores/db'
import { useAuth } from '@/stores/auth'
import { useUi } from '@/stores/ui'
import type { MobileNetwork, Payment, Student } from '@/types'
import { iso } from '@/services/dates'
import { kwacha, round2 } from '@/services/format'
import { NETWORK_LABEL, NETWORK_PREFIXES, networkFromPhone, normalisePhone, formatPhone } from '@/services/payments'
import { DEMO_MODE } from '@/config'

const props = defineProps<{ open: boolean; students: Student[]; initialStudentId?: string }>()
const emit = defineEmits<{ close: [] }>()
const store = useDb(); const auth = useAuth(); const ui = useUi()
const cfg = computed(() => store.db.settings.onlinePayments)
type Method = 'airtel' | 'mtn' | 'zamtel' | 'card' | 'bank'
const methodNet: Record<string, MobileNetwork> = { airtel: 'Airtel', mtn: 'MTN', zamtel: 'Zamtel' }
const methods = computed(() => ([
  { id: 'airtel', label: 'Airtel Money', sub: NETWORK_PREFIXES.Airtel, icon: Smartphone },
  { id: 'mtn', label: 'MTN MoMo', sub: NETWORK_PREFIXES.MTN, icon: Smartphone },
  { id: 'zamtel', label: 'Zamtel Kwacha', sub: NETWORK_PREFIXES.Zamtel, icon: Smartphone },
  { id: 'card', label: 'Bank card', sub: 'Visa or Mastercard', icon: CreditCard },
  { id: 'bank', label: 'Bank transfer', sub: 'Deposit or internet banking', icon: Landmark },
] as const).filter((m) => cfg.value.methods[m.id]))

const step = ref<'choose' | 'details' | 'waiting' | 'done' | 'failed' | 'reported'>('choose')
const f = reactive({ studentId: '', option: 'term' as 'term' | 'all' | 'custom', custom: null as number | null, method: '' as Method | '', phone: '', bankRef: '', bankDate: iso() })
const err = ref(''); const payment = ref<Payment | null>(null); const receipt = ref<Payment | null>(null)
let timer: ReturnType<typeof setInterval> | undefined
const countdown = ref(0)

watch(() => props.open, (o) => {
  if (!o) { clearInterval(timer); return }
  Object.assign(f, { studentId: props.initialStudentId ?? props.students[0]?.id ?? '', option: 'term', custom: null, method: '', phone: '', bankRef: '', bankDate: iso() })
  step.value = 'choose'; err.value = ''; payment.value = null
  const parentPhone = auth.user?.role === 'parent' ? store.parentMap.get(auth.user.linkedId ?? '')?.phone : store.studentMap.get(auth.user?.linkedId ?? '')?.altContact
  f.phone = parentPhone ? formatPhone(parentPhone) : ''
})
onBeforeUnmount(() => clearInterval(timer))

const student = computed(() => store.studentMap.get(f.studentId))
const term = computed(() => store.db.settings.currentTerm)
const termBal = computed(() => (f.studentId ? Math.max(0, store.balance(f.studentId, term.value)) : 0))
const allBal = computed(() => (f.studentId ? Math.max(0, store.balance(f.studentId)) : 0))
const amount = computed(() => round2(f.option === 'term' ? termBal.value : f.option === 'all' ? allBal.value : Number(f.custom) || 0))
const fee = computed(() => (cfg.value.passFeeToPayer && f.method !== 'bank' ? round2((amount.value * cfg.value.feePercent) / 100) : 0))
const total = computed(() => round2(amount.value + fee.value))
watch(() => f.studentId, () => { f.option = termBal.value > 0 ? 'term' : allBal.value > 0 ? 'all' : 'custom' }, { immediate: true })
const detected = computed(() => networkFromPhone(f.phone))
const wantNet = computed(() => methodNet[f.method] as MobileNetwork | undefined)

function next() {
  err.value = ''
  if (!f.studentId) return (err.value = 'Choose a child.')
  if (!(amount.value > 0)) return (err.value = 'Enter the amount you want to pay.')
  if (!f.method) return (err.value = 'Choose how you want to pay.')
  step.value = 'details'
}
function startMobile() {
  err.value = ''
  const phone = normalisePhone(f.phone)
  if (!phone) return (err.value = 'Enter a Zambian mobile number, e.g. 0977 123 456.')
  if (detected.value !== wantNet.value) return (err.value = `${formatPhone(phone)} is ${detected.value ? `an ${detected.value}` : 'not a'} number. ${NETWORK_LABEL[wantNet.value!]} numbers start with ${NETWORK_PREFIXES[wantNet.value!]}.`)
  payment.value = store.startOnlinePayment({ studentId: f.studentId, amount: amount.value, term: term.value, method: 'Mobile Money', network: wantNet.value, phone, fee: fee.value })
  waitForGateway()
}
function startCard() {
  payment.value = store.startOnlinePayment({ studentId: f.studentId, amount: amount.value, term: term.value, method: 'Card', fee: fee.value })
  waitForGateway()
}
function waitForGateway() {
  step.value = 'waiting'; countdown.value = 90
  clearInterval(timer)
  timer = setInterval(() => { countdown.value--; if (countdown.value <= 0) settle('timed_out') }, 1000)
}
function settle(outcome: 'confirmed' | 'declined' | 'timed_out') {
  clearInterval(timer)
  if (!payment.value) return
  store.settleOnlinePayment(payment.value.id, outcome)
  payment.value = store.db.payments.find((p) => p.id === payment.value!.id) ?? null
  step.value = outcome === 'confirmed' ? 'done' : 'failed'
  if (outcome === 'confirmed') ui.success('Payment received', `${kwacha(amount.value)} · receipt ${payment.value?.receiptNo}`)
}
function reportBank() {
  err.value = ''
  try { payment.value = store.reportBankTransfer({ studentId: f.studentId, amount: amount.value, term: term.value, reference: f.bankRef, date: f.bankDate }); step.value = 'reported' }
  catch (e) { err.value = (e as Error).message }
}
async function copy(text: string) { try { await navigator.clipboard.writeText(text); ui.info('Copied', text) } catch { ui.info('Copy not available', text) } }
const title = computed(() => ({ choose: 'Pay school fees', details: 'Pay school fees', waiting: 'Waiting for approval', done: 'Payment received', failed: 'Payment not completed', reported: 'Transfer submitted' })[step.value])
</script>

<template>
  <Modal :open="open" :title="title" :sub="step === 'choose' ? `${store.db.settings.centreName} · ${term}` : undefined" size="lg" @close="emit('close')">
    <!-- 1. what and how -->
    <div v-if="step === 'choose'" class="grid gap-5">
      <div v-if="students.length > 1"><span class="label">For</span>
        <div class="flex flex-wrap gap-2"><button v-for="s in students" :key="s.id" type="button" :class="['h-9 px-3.5 rounded-full border text-[13px]', f.studentId === s.id ? 'border-brand bg-brand-soft font-medium' : 'border-line text-muted']" @click="f.studentId = s.id">{{ s.firstName }} · {{ store.gradeName(s.gradeId) }}</button></div>
      </div>
      <div><span class="label">Amount</span>
        <div class="grid sm:grid-cols-3 gap-2">
          <button type="button" :disabled="!termBal" :class="['text-left rounded-md border px-3 py-2.5 disabled:opacity-40', f.option === 'term' ? 'border-brand ring-2 ring-brand/20' : 'border-line']" @click="f.option = 'term'">
            <div class="text-[12px] text-muted">{{ term }} balance</div><div class="font-semibold tnum">{{ kwacha(termBal) }}</div></button>
          <button type="button" :disabled="!allBal || allBal === termBal" :class="['text-left rounded-md border px-3 py-2.5 disabled:opacity-40', f.option === 'all' ? 'border-brand ring-2 ring-brand/20' : 'border-line']" @click="f.option = 'all'">
            <div class="text-[12px] text-muted">Everything owed</div><div class="font-semibold tnum">{{ kwacha(allBal) }}</div></button>
          <label :class="['rounded-md border px-3 py-2.5 cursor-text', f.option === 'custom' ? 'border-brand ring-2 ring-brand/20' : 'border-line']" @click="f.option = 'custom'">
            <div class="text-[12px] text-muted">Part payment</div>
            <div class="flex items-center gap-1 font-semibold"><span>K</span><input v-model.number="f.custom" type="number" min="1" step="1" class="w-full bg-transparent outline-none tnum" placeholder="0" aria-label="Custom amount" @focus="f.option = 'custom'" /></div></label>
        </div>
      </div>
      <div><span class="label">Pay with</span>
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <button v-for="m in methods" :key="m.id" type="button" :class="['text-left rounded-md border px-3 py-2.5 flex gap-2.5 items-start', f.method === m.id ? 'border-brand ring-2 ring-brand/20 bg-brand-soft/40' : 'border-line hover:border-faint']" @click="f.method = m.id">
            <component :is="m.icon" :size="17" class="mt-0.5 text-brand shrink-0" />
            <span><span class="block text-[13px] font-medium">{{ m.label }}</span><span class="block text-[11.5px] text-muted">{{ m.sub }}</span></span>
          </button>
        </div>
      </div>
      <p v-if="err" class="field-error text-[13px]">{{ err }}</p>
    </div>

    <!-- 2a. mobile money -->
    <div v-else-if="step === 'details' && wantNet" class="grid gap-4">
      <div><label class="label" for="pn-phone">{{ NETWORK_LABEL[wantNet] }} number that will approve the payment</label>
        <input id="pn-phone" v-model="f.phone" class="input h-10 tnum text-[15px]" inputmode="tel" placeholder="097 123 4567" />
        <p class="text-[12px] mt-1" :class="detected && detected !== wantNet ? 'text-bad' : 'text-muted'">{{ detected ? `${detected} number detected` : `${NETWORK_LABEL[wantNet]} numbers start with ${NETWORK_PREFIXES[wantNet]}` }}</p></div>
      <dl class="rounded-lg bg-sunken/70 border border-line p-3 text-[13px] grid grid-cols-2 gap-y-1.5">
        <dt class="text-muted">For</dt><dd class="text-right">{{ student?.firstName }} {{ student?.lastName }} · {{ term }}</dd>
        <dt class="text-muted">School fees</dt><dd class="text-right tnum">{{ kwacha(amount, { decimals: true }) }}</dd>
        <template v-if="fee"><dt class="text-muted">Transaction fee ({{ cfg.feePercent }}%)</dt><dd class="text-right tnum">{{ kwacha(fee, { decimals: true }) }}</dd></template>
        <dt class="font-semibold">You will approve</dt><dd class="text-right font-semibold tnum">{{ kwacha(total, { decimals: true }) }}</dd>
      </dl>
      <p class="text-[12.5px] text-muted flex gap-2"><ShieldCheck :size="15" class="text-ok shrink-0 mt-px" />You approve the payment on your own phone with your PIN. Breath It never asks for your PIN.</p>
      <p v-if="err" class="field-error text-[13px]">{{ err }}</p>
    </div>

    <!-- 2b. card -->
    <div v-else-if="step === 'details' && f.method === 'card'" class="grid gap-4 text-[13.5px]">
      <p>You will enter your card details on the secure page of our payment provider. Breath It never sees or stores your card number.</p>
      <dl class="rounded-lg bg-sunken/70 border border-line p-3 grid grid-cols-2 gap-y-1.5">
        <dt class="text-muted">School fees</dt><dd class="text-right tnum">{{ kwacha(amount, { decimals: true }) }}</dd>
        <template v-if="fee"><dt class="text-muted">Card fee ({{ cfg.feePercent }}%)</dt><dd class="text-right tnum">{{ kwacha(fee, { decimals: true }) }}</dd></template>
        <dt class="font-semibold">Total</dt><dd class="text-right font-semibold tnum">{{ kwacha(total, { decimals: true }) }}</dd>
      </dl>
    </div>

    <!-- 2c. bank transfer -->
    <div v-else-if="step === 'details' && f.method === 'bank'" class="grid gap-4">
      <dl class="rounded-lg border border-line divide-y divide-line text-[13px]">
        <div v-for="[k, v] in [['Bank', cfg.bank.bankName], ['Account name', cfg.bank.accountName], ['Account number', cfg.bank.accountNumber], ['Branch', cfg.bank.branch], ['Reference to use', student?.studentNo ?? '']]" :key="k" class="flex items-center justify-between gap-3 px-3 py-2">
          <dt class="text-muted">{{ k }}</dt><dd class="flex items-center gap-1.5 font-medium tnum">{{ v }}<button v-if="k === 'Account number' || k === 'Reference to use'" type="button" class="icon-btn h-7 w-7" :aria-label="`Copy ${k}`" @click="copy(String(v))"><Copy :size="13" /></button></dd>
        </div>
      </dl>
      <p class="text-[12.5px] text-muted">After paying {{ kwacha(amount) }}, enter the reference from your deposit slip or banking app. The office confirms it on the bank statement, usually within one working day, and your receipt appears here.</p>
      <div class="grid sm:grid-cols-2 gap-3">
        <div><label class="label" for="pn-bref">Bank reference</label><input id="pn-bref" v-model="f.bankRef" class="input" placeholder="e.g. FT26320ABC12" /></div>
        <div><label class="label" for="pn-bdate">Date paid</label><input id="pn-bdate" v-model="f.bankDate" type="date" :max="iso()" class="input" /></div>
      </div>
      <p v-if="err" class="field-error text-[13px]">{{ err }}</p>
    </div>

    <!-- 3. waiting for the gateway -->
    <div v-else-if="step === 'waiting'" class="text-center py-4">
      <Loader2 :size="34" class="mx-auto text-brand animate-spin" />
      <p v-if="payment?.method === 'Mobile Money'" class="mt-4 text-[15px] font-medium">Check your phone</p>
      <p v-else class="mt-4 text-[15px] font-medium">Complete the payment on the card page</p>
      <p v-if="payment?.method === 'Mobile Money'" class="sub mt-1 max-w-sm mx-auto">A prompt has been sent to <b class="text-ink tnum">{{ formatPhone(payment.payerPhone ?? '') }}</b>. Enter your {{ NETWORK_LABEL[payment.network!] }} PIN to approve <b class="text-ink tnum">{{ kwacha(total, { decimals: true }) }}</b> to {{ store.db.settings.centreName }}.</p>
      <p class="text-[12px] text-faint mt-3 tnum">Waiting {{ countdown }}s · ref {{ payment?.gatewayRef }}</p>
      <div v-if="DEMO_MODE" class="mt-5 rounded-lg border border-dashed border-warn/60 bg-warn-soft/40 p-3 text-left">
        <p class="text-[12.5px] text-warn font-medium">Demonstration: no prompt is sent and no money moves.</p>
        <p class="text-[12px] text-muted mt-0.5">Choose what the payer does on their phone to see how the system responds.</p>
        <div class="flex flex-wrap gap-2 mt-2.5">
          <button class="btn btn-primary btn-sm" @click="settle('confirmed')">Approve with PIN</button>
          <button class="btn btn-secondary btn-sm" @click="settle('declined')">Decline</button>
          <button class="btn btn-ghost btn-sm" @click="settle('timed_out')">Let it expire</button>
        </div>
      </div>
    </div>

    <!-- 4. results -->
    <div v-else-if="step === 'done'" class="text-center py-4">
      <CheckCircle2 :size="40" class="mx-auto text-ok" />
      <p class="mt-3 text-[16px] font-semibold">{{ kwacha(payment?.amount ?? 0, { decimals: true }) }} received</p>
      <p class="sub mt-1">Confirmed by the payment provider · receipt {{ payment?.receiptNo }}</p>
      <p class="mt-3 text-[13.5px]">New balance for {{ student?.firstName }}: <b class="tnum">{{ kwacha(Math.max(0, store.balance(f.studentId)), { decimals: true }) }}</b></p>
    </div>
    <div v-else-if="step === 'failed'" class="text-center py-4">
      <XCircle :size="40" class="mx-auto text-bad" />
      <p class="mt-3 text-[16px] font-semibold">{{ payment?.gatewayStatus === 'declined' ? 'The payment was declined' : 'The prompt expired' }}</p>
      <p class="sub mt-1 max-w-sm mx-auto">No money was taken and the balance has not changed. {{ payment?.gatewayStatus === 'timed_out' ? 'Make sure the phone is on and has network, then try again.' : 'You can try again or choose another way to pay.' }}</p>
    </div>
    <div v-else-if="step === 'reported'" class="text-center py-4">
      <CheckCircle2 :size="40" class="mx-auto text-info" />
      <p class="mt-3 text-[16px] font-semibold">Thank you — we have your transfer details</p>
      <p class="sub mt-1 max-w-sm mx-auto">The office will match reference <b class="text-ink">{{ payment?.externalRef }}</b> on the bank statement. Your balance and receipt update once it is confirmed.</p>
    </div>

    <template #footer>
      <template v-if="step === 'choose'"><button class="btn btn-secondary" @click="emit('close')">Cancel</button><button class="btn btn-primary" @click="next">Continue</button></template>
      <template v-else-if="step === 'details'">
        <button class="btn btn-secondary" @click="step = 'choose'">Back</button>
        <button v-if="wantNet" class="btn btn-primary" @click="startMobile">Send payment request</button>
        <button v-else-if="f.method === 'card'" class="btn btn-primary" @click="startCard">Continue to secure card page</button>
        <button v-else class="btn btn-primary" @click="reportBank">Submit transfer details</button>
      </template>
      <template v-else-if="step === 'waiting'"><button class="btn btn-secondary" @click="settle('declined')">Cancel payment</button></template>
      <template v-else-if="step === 'done'"><button class="btn btn-secondary" @click="emit('close')">Close</button><button class="btn btn-primary" @click="receipt = payment">View receipt</button></template>
      <template v-else-if="step === 'failed'"><button class="btn btn-secondary" @click="emit('close')">Close</button><button class="btn btn-primary" @click="step = 'details'">Try again</button></template>
      <template v-else><button class="btn btn-primary" @click="emit('close')">Done</button></template>
    </template>
  </Modal>
  <ReceiptModal :payment="receipt" @close="receipt = null" />
</template>
