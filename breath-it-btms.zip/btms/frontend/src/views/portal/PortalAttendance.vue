<script setup lang="ts">
import { computed, ref } from 'vue'
import PageHeader from '@/components/ui/PageHeader.vue'
import ChildSwitcher from '@/components/domain/ChildSwitcher.vue'
import StatTile from '@/components/ui/StatTile.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import { usePortalStudent } from '@/composables/usePortalStudent'
import { useDb } from '@/stores/db'
import { iso, isoWeekday, DAY_SHORT, fmtDate } from '@/services/dates'
import { pct } from '@/services/format'
import { attendanceRate, attendanceCounts } from '@/services/analytics'

const { student, isParent } = usePortalStudent(); const store = useDb()
const today = iso()
const month = ref(today.slice(0, 7))
const recs = computed(() => (student.value ? store.db.attendance.filter((a) => a.studentId === student.value!.id) : []))
const monthRecs = computed(() => recs.value.filter((a) => a.date.startsWith(month.value)).sort((a, b) => b.date.localeCompare(a.date) || (store.lessonMap.get(a.lessonId)?.start ?? '').localeCompare(store.lessonMap.get(b.lessonId)?.start ?? '')))
const counts = computed(() => attendanceCounts(monthRecs.value))
const cal = computed(() => {
  const [y, m] = month.value.split('-').map(Number)
  const first = new Date(y, m - 1, 1); const days = new Date(y, m, 0).getDate()
  const lead = (first.getDay() + 6) % 7
  const cells: ({ d: string; state: string } | null)[] = Array(lead).fill(null)
  for (let i = 1; i <= days; i++) {
    const d = `${month.value}-${String(i).padStart(2, '0')}`
    const r = recs.value.filter((a) => a.date === d)
    cells.push({ d, state: !r.length ? 'none' : r.some((x) => x.status === 'absent') ? 'absent' : r.some((x) => x.status === 'late') ? 'late' : 'present' })
  }
  return cells
})
const tone: Record<string, string> = { present: 'bg-ok text-white', late: 'bg-warn text-white', absent: 'bg-bad text-white', none: 'text-muted' }
const months = computed(() => [...new Set(recs.value.map((r) => r.date.slice(0, 7)))].sort().reverse())
</script>
<template>
  <div>
    <PageHeader :title="isParent ? 'Attendance' : 'My attendance'" :sub="student ? `${student.firstName} ${student.lastName} · every lesson is recorded by the tutor` : ''">
      <select v-model="month" class="select w-auto" aria-label="Month"><option v-for="m in months.length ? months : [month]" :key="m" :value="m">{{ new Date(m + '-01T00:00').toLocaleString('en-GB', { month: 'long', year: 'numeric' }) }}</option></select>
    </PageHeader>
    <ChildSwitcher />
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
      <StatTile label="This month" :value="counts.total ? pct(attendanceRate(monthRecs)) : '—'" :tone="counts.total && attendanceRate(monthRecs) < store.db.settings.lowAttendanceThreshold ? 'bad' : 'ok'" :hint="`${counts.total} lessons recorded`" />
      <StatTile label="Present" :value="counts.present" />
      <StatTile label="Late" :value="counts.late" />
      <StatTile label="Absent" :value="counts.absent" />
    </div>
    <div class="grid lg:grid-cols-[340px_1fr] gap-4 items-start">
      <section class="card card-pad">
        <div class="grid grid-cols-7 gap-1 text-center text-[11.5px] text-muted mb-1"><span v-for="d in [1, 2, 3, 4, 5, 6, 7]" :key="d">{{ DAY_SHORT[d] }}</span></div>
        <div class="grid grid-cols-7 gap-1">
          <div v-for="(c, i) in cal" :key="i" :class="['aspect-square rounded-md flex items-center justify-center text-[12.5px] tnum', c ? tone[c.state] : '', c?.d === today ? 'ring-2 ring-brand' : '']" :title="c ? fmtDate(c.d) : ''">{{ c ? +c.d.slice(8) : '' }}</div>
        </div>
        <div class="flex flex-wrap gap-3 mt-3 text-[12px] text-muted">
          <span class="flex items-center gap-1.5"><i class="h-2.5 w-2.5 rounded-sm bg-ok" />All present</span>
          <span class="flex items-center gap-1.5"><i class="h-2.5 w-2.5 rounded-sm bg-warn" />Late</span>
          <span class="flex items-center gap-1.5"><i class="h-2.5 w-2.5 rounded-sm bg-bad" />Missed a lesson</span>
        </div>
      </section>
      <section class="card">
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Date</th><th>Lesson</th><th>Tutor</th><th>Status</th></tr></thead>
          <tbody><tr v-for="a in monthRecs" :key="a.id">
            <td class="whitespace-nowrap">{{ DAY_SHORT[isoWeekday(a.date)] }} {{ fmtDate(a.date, false) }}</td>
            <td class="whitespace-nowrap">{{ store.subjectName(store.lessonMap.get(a.lessonId)?.subjectId ?? '') }} <span class="text-muted">· {{ store.lessonMap.get(a.lessonId)?.start }}</span></td>
            <td class="whitespace-nowrap text-muted">{{ store.tutorName(store.lessonMap.get(a.lessonId)?.tutorId ?? '') }}</td>
            <td><StatusBadge :status="a.status" /></td>
          </tr></tbody>
        </table></div>
        <EmptyState v-if="!monthRecs.length" compact title="No lessons recorded this month" />
      </section>
    </div>
  </div>
</template>
