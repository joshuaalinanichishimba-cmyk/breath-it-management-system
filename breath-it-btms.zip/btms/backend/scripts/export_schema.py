"""Writes schema.sql (PostgreSQL DDL) from the SQLAlchemy models.  Run: python scripts/export_schema.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from sqlalchemy.dialects import postgresql
from sqlalchemy.schema import CreateIndex, CreateTable
from app.db import Base
import app.models  # noqa: F401  (registers tables)

out = ["-- Breath It Tuition Centre Management System — PostgreSQL schema", "-- Generated from backend/app/models. Do not edit by hand; run scripts/export_schema.py.", ""]
for table in Base.metadata.sorted_tables:
    out.append(str(CreateTable(table).compile(dialect=postgresql.dialect())).strip() + ";")
    for idx in sorted(table.indexes, key=lambda i: i.name):
        out.append(str(CreateIndex(idx).compile(dialect=postgresql.dialect())).strip() + ";")
    out.append("")
path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "schema.sql")
open(path, "w", encoding="utf-8").write("\n".join(out))
print(f"Wrote {path} ({len(Base.metadata.sorted_tables)} tables)")
