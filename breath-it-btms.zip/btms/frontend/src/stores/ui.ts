import { defineStore } from 'pinia'
import { ref } from 'vue'

export interface Toast { id: number; kind: 'success' | 'error' | 'info'; title: string; body?: string }
interface ConfirmState { title: string; body: string; confirmLabel: string; tone: 'primary' | 'danger'; resolve: (v: boolean) => void }

export const useUi = defineStore('ui', () => {
  const toasts = ref<Toast[]>([])
  const confirmState = ref<ConfirmState | null>(null)
  const mobileNav = ref(false)
  const selectedChildId = ref<string | null>(null)
  let n = 0

  function toast(kind: Toast['kind'], title: string, body?: string) {
    const id = ++n
    toasts.value.push({ id, kind, title, body })
    setTimeout(() => dismiss(id), kind === 'error' ? 6000 : 3800)
  }
  function dismiss(id: number) { toasts.value = toasts.value.filter((t) => t.id !== id) }
  function confirm(opts: { title: string; body: string; confirmLabel?: string; tone?: 'primary' | 'danger' }): Promise<boolean> {
    return new Promise((resolve) => {
      confirmState.value = { title: opts.title, body: opts.body, confirmLabel: opts.confirmLabel ?? 'Confirm', tone: opts.tone ?? 'primary', resolve }
    })
  }
  function settleConfirm(v: boolean) { confirmState.value?.resolve(v); confirmState.value = null }

  return {
    toasts, confirmState, mobileNav, selectedChildId,
    toast, dismiss, confirm, settleConfirm,
    success: (t: string, b?: string) => toast('success', t, b),
    error: (t: string, b?: string) => toast('error', t, b),
    info: (t: string, b?: string) => toast('info', t, b),
  }
})
