import { computed, ref, watch, type Ref } from 'vue'
export function usePager<T>(items: Ref<T[]>, size = 12) {
  const page = ref(1)
  const pages = computed(() => Math.max(1, Math.ceil(items.value.length / size)))
  watch(() => items.value.length, () => { if (page.value > pages.value) page.value = 1 })
  const rows = computed(() => items.value.slice((page.value - 1) * size, page.value * size))
  const range = computed(() => {
    const n = items.value.length
    return n ? `${(page.value - 1) * size + 1}–${Math.min(page.value * size, n)} of ${n}` : '0 results'
  })
  return { page, pages, rows, range }
}
