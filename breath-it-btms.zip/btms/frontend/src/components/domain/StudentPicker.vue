<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useDb } from '@/stores/db'
import type { Student } from '@/types'
const model = defineModel<string>({ default: '' })
const props = defineProps<{ students: Student[]; placeholder?: string }>()
const store = useDb()
const q = ref('')
const open = ref(false)
const selected = computed(() => props.students.find((s) => s.id === model.value))
watch(selected, (s) => { if (s) q.value = `${s.firstName} ${s.lastName}` }, { immediate: true })
const matches = computed(() => {
  const t = q.value.trim().toLowerCase()
  return props.students.filter((s) => !t || `${s.firstName} ${s.lastName} ${s.studentNo}`.toLowerCase().includes(t)).slice(0, 8)
})
function onBlur() { setTimeout(() => (open.value = false), 150) }
function choose(s: Student) { model.value = s.id; q.value = `${s.firstName} ${s.lastName}`; open.value = false }
</script>
<template>
  <div class="relative">
    <input v-model="q" class="input" :placeholder="placeholder ?? 'Search by name or student number'" role="combobox" :aria-expanded="open"
      @focus="open = true" @input="open = true; model = ''" @blur="onBlur" />
    <div v-if="open && matches.length" class="absolute z-20 mt-1 w-full card shadow-lg py-1 max-h-64 overflow-y-auto">
      <button v-for="s in matches" :key="s.id" type="button" class="w-full text-left px-3 py-2 hover:bg-sunken flex justify-between gap-3" @mousedown.prevent="choose(s)">
        <span class="font-medium">{{ s.firstName }} {{ s.lastName }}</span>
        <span class="text-muted text-[12px] tnum">{{ s.studentNo }} · {{ store.gradeName(s.gradeId) }}</span>
      </button>
    </div>
  </div>
</template>
