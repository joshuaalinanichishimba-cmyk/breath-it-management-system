<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { Plus, MessageCircle, Link2, ChevronRight, Pencil, UserPlus, Gift } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatTile from '@/components/ui/StatTile.vue'
import Modal from '@/components/ui/Modal.vue'
import StudentFormModal from '@/components/domain/StudentFormModal.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import type { Lead, LeadSource, LeadStage, Student } from '@/types'
import { iso, fmtDate, relativeDay, addDays } from '@/services/dates'
import { pct, kwacha } from '@/services/format'
import { waLink } from '@/services/whatsapp'
import { normalisePhone } from '@/services/payments'

const store = useDb(); const ui = useUi()
const today = iso()
const stages: { id: LeadStage; label: string }[] = [
  { id: 'new', label: 'New enquiry' }, { id: 'contacted', label: 'Contacted' }, { id: 'trial', label: 'Trial lesson' }, { id: 'enrolled', label: 'Enrolled' }, { id: 'lost', label: 'Did not join' },
]
const nextStage: Record<LeadStage, LeadStage | null> = { new: 'contacted', contacted: 'trial', trial: 'enrolled', enrolled: null, lost: null }
const sources: LeadSource[] = ['Walk-in', 'WhatsApp', 'Facebook', 'Referral', 'Flyer', 'School visit', 'Website']
const leads = computed(() => store.db.leads)
const open = computed(() => leads.value.filter((l) => ['new', 'contacted', 'trial'].includes(l.stage)))
const due = computed(() => open.value.filter((l) => (l.followUpOn ?? l.createdAt.slice(0, 10)) <= today))
const decided = computed(() => leads.value.filter((l) => l.stage === 'enrolled' || l.stage === 'lost'))
const conversion = computed(() => (decided.value.length ? (leads.value.filter((l) => l.stage === 'enrolled').length / decided.value.length) * 100 : NaN))
const tuitionFor = (gradeId: string) => store.db.feeStructures.find((f) => f.gradeId === gradeId && f.category === 'Tuition')?.amount ?? 0
const pipelineValue = computed(() => open.value.reduce((a, l) => a + tuitionFor(l.gradeId), 0))
const bySource = computed(() => sources.map((s) => {
  const ls = leads.value.filter((l) => l.source === s)
  const enrolled = ls.filter((l) => l.stage === 'enrolled').length
  return { s, n: ls.length, enrolled, rate: ls.length ? (enrolled / ls.length) * 100 : NaN }
}).filter((x) => x.n).sort((a, b) => b.enrolled - a.enrolled || b.n - a.n))
const column = (s: LeadStage) => leads.value.filter((l) => l.stage === s).sort((a, b) => (a.followUpOn ?? '9').localeCompare(b.followUpOn ?? '9') || b.createdAt.localeCompare(a.createdAt))
const overdue = (l: Lead) => ['new', 'contacted', 'trial'].includes(l.stage) && (l.followUpOn ?? l.createdAt.slice(0, 10)) <= today

function waText(l: Lead) {
  const msg: Record<LeadStage, string> = {
    new: `Good day ${l.parentName}, thank you for your enquiry about ${l.childName} at Breath It Tuition Centre (Kaunda Square Stage 2). When would be a good time to talk about ${store.gradeName(l.gradeId)} lessons?`,
    contacted: `Good day ${l.parentName}. ${l.childName} is welcome to attend a free trial lesson at Breath It Tuition Centre this week. Which day suits you?`,
    trial: `Good day ${l.parentName}. We hope ${l.childName} enjoyed the trial lesson. Registration is ${kwacha(150)} and ${store.gradeName(l.gradeId)} tuition is ${kwacha(tuitionFor(l.gradeId))} per term. Shall we reserve a place?`,
    enrolled: `Welcome to Breath It, ${l.parentName}! ${l.childName}'s timetable and progress are available in the parent portal.`,
    lost: `Good day ${l.parentName}. Places are still available at Breath It Tuition Centre if ${l.childName} would like to join this term.`,
  }
  return waLink(l.phone, msg[l.stage])
}
function advance(l: Lead) {
  const to = nextStage[l.stage]
  if (to === 'enrolled') return startEnrol(l)
  if (!to) return
  store.updateLead(l.id, { stage: to, followUpOn: addDays(today, to === 'trial' ? 3 : 2) })
  ui.success(`${l.childName} moved to ${stages.find((s) => s.id === to)!.label.toLowerCase()}`)
}

// enrol → student registration form, prefilled
const enrolLead = ref<Lead | null>(null)
const prefill = computed(() => {
  const l = enrolLead.value; if (!l) return null
  const [first, ...rest] = l.childName.split(' ')
  return { firstName: first, lastName: rest.join(' '), gradeId: l.gradeId, subjectIds: l.subjectIds, parentName: l.parentName, parentPhone: l.phone }
})
function startEnrol(l: Lead) { enrolLead.value = l }
function enrolled(s: Student) {
  const l = enrolLead.value!
  store.updateLead(l.id, { stage: 'enrolled', studentId: s.id, followUpOn: undefined })
  if (l.referredByParentId) ui.info('Referral reward available', `Apply the ${kwacha(store.db.settings.referralReward)} credit for ${store.parentMap.get(l.referredByParentId)?.name} from the Enrolled column.`)
}
function reward(l: Lead) {
  try { store.rewardReferral(l.id); ui.success('Referral reward applied', `${kwacha(store.db.settings.referralReward)} credited to ${store.parentMap.get(l.referredByParentId!)?.name}`) } catch (e) { ui.error((e as Error).message) }
}

// add / edit
const formOpen = ref(false); const editing = ref<Lead | null>(null); const err = ref('')
const blank = () => ({ childName: '', gradeId: store.db.grades[0].id, subjectIds: [] as string[], parentName: '', phone: '', source: 'Walk-in' as LeadSource, referredByParentId: '', followUpOn: addDays(today, 1), notes: '', stage: 'new' as LeadStage, lostReason: '' })
const f = reactive(blank())
function edit(l?: Lead) { editing.value = l ?? null; Object.assign(f, blank(), l ? { ...l, referredByParentId: l.referredByParentId ?? '', followUpOn: l.followUpOn ?? '', lostReason: l.lostReason ?? '', subjectIds: [...l.subjectIds] } : {}); err.value = ''; formOpen.value = true }
const gradeSubjects = computed(() => store.db.subjects.filter((s) => s.active && s.gradeIds.includes(f.gradeId)))
function save() {
  if (!f.childName.trim() || !f.parentName.trim()) return (err.value = 'Child and parent names are required.')
  if (!normalisePhone(f.phone)) return (err.value = 'Enter a valid Zambian phone number.')
  if (f.stage === 'lost' && !f.lostReason.trim()) return (err.value = 'Record why they did not join — it shows what to improve.')
  const data = { childName: f.childName.trim(), gradeId: f.gradeId, subjectIds: f.subjectIds.filter((id) => gradeSubjects.value.some((s) => s.id === id)), parentName: f.parentName.trim(), phone: f.phone.trim(), source: f.source,
    referredByParentId: f.source === 'Referral' && f.referredByParentId ? f.referredByParentId : undefined, followUpOn: f.followUpOn || undefined, notes: f.notes.trim(), stage: f.stage, lostReason: f.stage === 'lost' ? f.lostReason.trim() : undefined }
  if (editing.value) { store.updateLead(editing.value.id, data); ui.success('Enquiry updated') }
  else { store.addLead(data); ui.success('Enquiry added', `Follow up ${f.followUpOn ? relativeDay(f.followUpOn).toLowerCase() : 'soon'}.`) }
  formOpen.value = false
}
async function copyLink() {
  const url = `${location.origin}${location.pathname}#/enquire`
  try { await navigator.clipboard.writeText(url); ui.success('Enquiry link copied', 'Share it on Facebook, WhatsApp status or flyers (QR code).') } catch { ui.info('Enquiry form address', url) }
}
</script>

<template>
  <div>
    <PageHeader title="Admissions" sub="Every enquiry from first contact to enrolled student, so no interested parent is forgotten.">
      <button class="btn btn-secondary" @click="copyLink"><Link2 :size="15" />Copy enquiry form link</button>
      <button class="btn btn-primary" @click="edit()"><Plus :size="15" />Add enquiry</button>
    </PageHeader>
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
      <StatTile label="Open enquiries" :value="open.length" :hint="`${leads.filter((l) => l.stage === 'new').length} not yet contacted`" />
      <StatTile label="Follow-ups due" :value="due.length" :tone="due.length ? 'warn' : 'ok'" hint="Today or overdue" />
      <StatTile label="Conversion rate" :value="Number.isFinite(conversion) ? pct(conversion) : '—'" :hint="`${leads.filter((l) => l.stage === 'enrolled').length} enrolled · ${leads.filter((l) => l.stage === 'lost').length} lost`" />
      <StatTile label="Potential tuition in pipeline" :value="kwacha(pipelineValue)" tone="brand" hint="Per term, if all open enquiries enrol" />
    </div>

    <div class="overflow-x-auto pb-2 -mx-1 px-1">
      <div class="grid grid-cols-[repeat(5,minmax(230px,1fr))] gap-3 min-w-[1180px]">
        <section v-for="s in stages" :key="s.id" class="rounded-lg bg-sunken/60 border border-line p-2.5 flex flex-col gap-2 min-h-[200px]">
          <div class="flex items-center justify-between px-1"><h2 class="text-[13px] font-semibold">{{ s.label }}</h2><span class="badge badge-mute tnum">{{ column(s.id).length }}</span></div>
          <article v-for="l in column(s.id)" :key="l.id" :class="['card px-3 py-2.5', overdue(l) && 'border-warn/70']">
            <div class="flex items-start justify-between gap-2">
              <div class="min-w-0"><div class="font-medium truncate">{{ l.childName }}</div><div class="text-[12px] text-muted truncate">{{ store.gradeName(l.gradeId) }} · {{ l.parentName }}</div></div>
              <button class="icon-btn h-7 w-7 -mr-1" :aria-label="`Edit ${l.childName}`" @click="edit(l)"><Pencil :size="13" /></button>
            </div>
            <div class="flex flex-wrap gap-1 mt-1.5">
              <span class="badge badge-mute">{{ l.source }}</span>
              <span v-if="l.referredByParentId" class="badge badge-brand">via {{ store.parentMap.get(l.referredByParentId)?.name.split(' ')[0] }}</span>
              <span v-if="overdue(l)" class="badge badge-warn">Follow up {{ (l.followUpOn ?? today) < today ? 'overdue' : 'today' }}</span>
              <span v-else-if="l.followUpOn && l.stage !== 'enrolled' && l.stage !== 'lost'" class="badge badge-mute">Next: {{ relativeDay(l.followUpOn) }}</span>
            </div>
            <p v-if="l.lostReason" class="text-[12px] text-muted mt-1.5">Reason: {{ l.lostReason }}</p>
            <p v-else-if="l.notes" class="text-[12px] text-muted mt-1.5 line-clamp-2">{{ l.notes }}</p>
            <div class="flex items-center gap-1.5 mt-2">
              <a :href="waText(l)" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm"><MessageCircle :size="13" />WhatsApp</a>
              <button v-if="l.stage === 'trial'" class="btn btn-primary btn-sm ml-auto" @click="startEnrol(l)"><UserPlus :size="13" />Enrol</button>
              <button v-else-if="nextStage[l.stage]" class="btn btn-ghost btn-sm ml-auto" @click="advance(l)">Next<ChevronRight :size="13" /></button>
              <RouterLink v-else-if="l.studentId" :to="`/students/${l.studentId}`" class="btn btn-ghost btn-sm ml-auto">Profile</RouterLink>
            </div>
            <button v-if="l.stage === 'enrolled' && l.referredByParentId && !l.rewardApplied" class="btn btn-ghost btn-sm w-full mt-1.5 text-brand" @click="reward(l)"><Gift :size="13" />Apply {{ kwacha(store.db.settings.referralReward) }} referral reward</button>
          </article>
        </section>
      </div>
    </div>

    <section class="card mt-5 max-w-2xl">
      <h2 class="h-section px-4 sm:px-5 pt-4">Where enquiries come from</h2>
      <p class="sub px-4 sm:px-5 pb-2">Put marketing effort where families actually enrol.</p>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Source</th><th>Enquiries</th><th>Enrolled</th><th>Conversion</th></tr></thead>
        <tbody><tr v-for="x in bySource" :key="x.s"><td class="font-medium">{{ x.s }}</td><td class="tnum">{{ x.n }}</td><td class="tnum">{{ x.enrolled }}</td><td class="tnum">{{ Number.isFinite(x.rate) ? pct(x.rate) : '—' }}</td></tr></tbody>
      </table></div>
    </section>

    <Modal :open="formOpen" :title="editing ? 'Edit enquiry' : 'Add enquiry'" size="lg" @close="formOpen = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
        <div><label class="label" for="ld-c">Child’s name</label><input id="ld-c" v-model="f.childName" class="input" /></div>
        <div><label class="label" for="ld-g">Grade</label><select id="ld-g" v-model="f.gradeId" class="select"><option v-for="g in store.db.grades" :key="g.id" :value="g.id">{{ g.name }}</option></select></div>
        <div class="sm:col-span-2"><span class="label">Subjects of interest</span>
          <div class="flex flex-wrap gap-2"><label v-for="s in gradeSubjects" :key="s.id" :class="['flex items-center h-8 px-3 rounded-full border text-[13px] cursor-pointer', f.subjectIds.includes(s.id) ? 'border-brand bg-brand-soft' : 'border-line']"><input v-model="f.subjectIds" type="checkbox" :value="s.id" class="sr-only" />{{ s.name }}</label></div></div>
        <div><label class="label" for="ld-p">Parent / guardian</label><input id="ld-p" v-model="f.parentName" class="input" /></div>
        <div><label class="label" for="ld-ph">Phone (WhatsApp)</label><input id="ld-ph" v-model="f.phone" class="input" placeholder="0977 123 456" /></div>
        <div><label class="label" for="ld-s">How they heard about us</label><select id="ld-s" v-model="f.source" class="select"><option v-for="s in sources" :key="s">{{ s }}</option></select></div>
        <div v-if="f.source === 'Referral'"><label class="label" for="ld-r">Referred by</label><select id="ld-r" v-model="f.referredByParentId" class="select"><option value="">Not a current parent</option><option v-for="p in [...store.db.parents].sort((a, b) => a.name.localeCompare(b.name))" :key="p.id" :value="p.id">{{ p.name }} ({{ store.db.referralCodes[p.id] }})</option></select></div>
        <div><label class="label" for="ld-st">Stage</label><select id="ld-st" v-model="f.stage" class="select"><option v-for="s in stages.filter((x) => x.id !== 'enrolled' || editing?.stage === 'enrolled')" :key="s.id" :value="s.id">{{ s.label }}</option></select></div>
        <div><label class="label" for="ld-f">Next follow-up</label><input id="ld-f" v-model="f.followUpOn" type="date" class="input" /></div>
        <div v-if="f.stage === 'lost'" class="sm:col-span-2"><label class="label" for="ld-lr">Why they did not join</label>
          <select id="ld-lr" v-model="f.lostReason" class="select"><option value="">Choose…</option><option>Fees too high</option><option>Chose another centre</option><option>Distance / transport</option><option>Lesson times did not suit</option><option>No response</option><option>Other</option></select></div>
        <div class="sm:col-span-2"><label class="label" for="ld-n">Notes</label><textarea id="ld-n" v-model="f.notes" class="textarea" /></div>
        <p v-if="err" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer><button class="btn btn-secondary" @click="formOpen = false">Cancel</button><button class="btn btn-primary" @click="save">{{ editing ? 'Save changes' : 'Add enquiry' }}</button></template>
    </Modal>
    <StudentFormModal :open="!!enrolLead" :prefill="prefill" @close="enrolLead = null" @saved="enrolled" />
  </div>
</template>
