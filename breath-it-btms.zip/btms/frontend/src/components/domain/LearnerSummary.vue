<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink } from 'vue-router'
import type { ChartConfiguration } from 'chart.js'
import type { Student } from '@/types'
import { useDb } from '@/stores/db'
import { useAuth } from '@/stores/auth'
import StatTile from '@/components/ui/StatTile.vue'
import ChartBox from '@/components/charts/ChartBox.vue'
import { tok } from '@/components/charts/palette'
import { iso, addDays, isoWeekday, DAY_NAMES, fmtDate } from '@/services/dates'
import { kwacha, pct, gradeBand } from '@/services/format'
import { attendanceRate, average, pctOf, progressSeries } from '@/services/analytics'

const props = defineProps<{ student: Student }>()
const store = useDb(); const auth = useAuth()
const today = iso()
const term = computed(() => store.db.settings.currentTerm)
const att = computed(() => store.db.attendance.filter((a) => a.studentId === props.student.id))
const termAtt = computed(() => att.value.filter((a) => a.date >= (store.db.settings.terms.find((t) => t.name === term.value)?.start ?? '0')))
const results = computed(() => store.db.assessments.filter((a) => a.studentId === props.student.id).sort((a, b) => b.date.localeCompare(a.date)))
const termAvg = computed(() => average(results.value.filter((r) => r.term === term.value).map(pctOf)))
const bal = computed(() => store.balance(props.student.id))
const showFees = computed(() => auth.role !== 'student' || store.db.settings.showFeesToStudents)
const nextLessons = computed(() => {
  const out: { date: string; l: (typeof store.db.lessons)[number] }[] = []
  for (let i = 0; i <= 7 && out.length < 4; i++) {
    const d = addDays(today, i)
    store.db.lessons.filter((l) => l.classId === props.student.classId && l.day === isoWeekday(d) && props.student.subjectIds.includes(l.subjectId))
      .sort((a, b) => a.start.localeCompare(b.start)).forEach((l) => out.push({ date: d, l }))
  }
  return out.slice(0, 4)
})
const progressCfg = computed<ChartConfiguration>(() => {
  const series = progressSeries(results.value)
  return { type: 'line', data: { labels: series.map((s) => fmtDate(s.date, false)), datasets: [{ label: 'Average %', data: series.map((s) => +s.avg.toFixed(1)), borderColor: tok('brand'), backgroundColor: tok('brand', 0.1), fill: true, tension: 0.3, pointRadius: 3 }] },
    options: { plugins: { legend: { display: false }, tooltip: { callbacks: { title: (i) => series[i[0].dataIndex]?.title ?? '' } } }, scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + '%' } }, x: { grid: { display: false } } } } }
})
</script>
<template>
  <div class="grid gap-4">
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <StatTile label="Attendance this term" :value="termAtt.length ? pct(attendanceRate(termAtt)) : '—'" :tone="termAtt.length && attendanceRate(termAtt) < store.db.settings.lowAttendanceThreshold ? 'bad' : 'ok'" :hint="`${termAtt.filter((a) => a.status === 'absent').length} absences · ${termAtt.filter((a) => a.status === 'late').length} late`" />
      <StatTile :label="`Average · ${term.replace(' 2026', '')}`" :value="Number.isFinite(termAvg) ? pct(termAvg) : '—'" :hint="Number.isFinite(termAvg) ? gradeBand(termAvg).label : 'No marks yet'" />
      <StatTile label="Subjects" :value="student.subjectIds.length" :hint="store.className(student.classId)" />
      <StatTile v-if="showFees" label="Fee balance" :value="kwacha(Math.max(0, bal))" :tone="bal > 0 ? 'bad' : 'ok'" :hint="bal > 0 ? 'Outstanding' : 'Fully paid'" />
    </div>
    <div class="grid lg:grid-cols-3 gap-4">
      <section class="card card-pad lg:col-span-2"><h2 class="h-section">Progress over time</h2><p class="sub mb-3">Average of all subjects at each test or exam</p><ChartBox :config="progressCfg" :height="230" label="Progress line chart" /></section>
      <section class="card card-pad">
        <h2 class="h-section mb-3">Next lessons</h2>
        <ul class="grid gap-2.5">
          <li v-for="n in nextLessons" :key="n.l.id + n.date" class="flex gap-3 text-[13px]">
            <div class="w-[70px] shrink-0"><div class="font-medium">{{ n.date === today ? 'Today' : DAY_NAMES[isoWeekday(n.date)].slice(0, 3) }}</div><div class="text-muted tnum">{{ n.l.start }}</div></div>
            <div class="min-w-0"><div class="font-medium truncate">{{ store.subjectName(n.l.subjectId) }}</div><div class="text-muted truncate">{{ store.tutorName(n.l.tutorId) }} · {{ n.l.room }}</div></div>
          </li>
        </ul>
        <RouterLink to="/timetable" class="inline-block mt-3 text-[12.5px] text-brand hover:underline">Weekly timetable</RouterLink>
      </section>
    </div>
    <section class="card">
      <div class="flex items-baseline justify-between px-4 sm:px-5 pt-4 pb-2"><h2 class="h-section">Latest results and tutor comments</h2><RouterLink to="/my/results" class="text-[12.5px] text-brand hover:underline">All results</RouterLink></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Subject</th><th>Assessment</th><th>Mark</th><th>Tutor comment</th></tr></thead>
        <tbody><tr v-for="r in results.slice(0, 6)" :key="r.id">
          <td class="font-medium whitespace-nowrap">{{ store.subjectName(r.subjectId) }}</td>
          <td class="whitespace-nowrap">{{ r.title }}<div class="text-[12px] text-muted">{{ fmtDate(r.date) }}</div></td>
          <td class="tnum whitespace-nowrap"><span :class="['badge', 'badge-' + gradeBand(pctOf(r)).tone]">{{ r.marks }}/{{ r.maxMarks }} · {{ pct(pctOf(r)) }}</span></td>
          <td class="text-muted min-w-[220px]">{{ r.comment }} <span class="text-faint">— {{ store.tutorName(r.tutorId) }}</span></td>
        </tr></tbody>
      </table></div>
    </section>
  </div>
</template>
