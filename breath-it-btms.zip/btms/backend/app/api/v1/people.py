from datetime import date, timedelta
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import or_, select, func
from sqlalchemy.orm import Session
from ...db import get_db
from ...deps import current_user, require_roles, client_ip
from ...models import (AttendanceRecord, Charge, ClassGroup, Enrolment, FeeStructure, Grade, Parent, Payment, Student, Subject,
                       Tutor, User, ExaminationResult)
from ...schemas.people import (EnrolmentOut, ParentIn, ParentOut, ParentUpdate, StudentIn, StudentOut, StudentUpdate, TutorIn,
                               TutorOut, TutorUpdate)
from ...schemas.records import AttendanceOut
from ...schemas.finance import ChargeOut, PaymentOut
from ...services.access import ensure_student_access, visible_student_ids
from ...services.audit import audit
from ...services.finance import billed, paid, balance
from .serializers import result_out, payment_out

router = APIRouter(tags=["people"])
admin_only = require_roles("admin")


def student_out(s: Student) -> StudentOut:
    out = StudentOut.model_validate(s)
    out.subject_ids = [x.id for x in s.subjects]
    return out


def tutor_out(t: Tutor) -> TutorOut:
    out = TutorOut.model_validate(t)
    out.subject_ids = [x.id for x in t.subjects]
    return out


def load_subjects(db: Session, ids: list[str]) -> list[Subject]:
    subjects = list(db.scalars(select(Subject).where(Subject.id.in_(ids))))
    if len(subjects) != len(set(ids)):
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "One or more subjects do not exist.")
    return subjects


def term_for(db: Session, d: date) -> str:
    from ...models import CentreSetting
    terms = (db.get(CentreSetting, "terms") or CentreSetting(key="terms", value={"items": []})).value.get("items", [])
    for t in terms:
        if t["start"] <= d.isoformat() <= t["end"]:
            return t["name"]
    past = [t for t in terms if t["start"] <= d.isoformat()]
    return past[-1]["name"] if past else f"{d.year}"


# ---------------- students ----------------
@router.get("/students", response_model=list[StudentOut])
def list_students(q: str = "", grade_id: str | None = None, class_id: str | None = None, status_: str | None = Query(None, alias="status"),
                  user: User = Depends(current_user), db: Session = Depends(get_db)):
    query = select(Student)
    allowed = visible_student_ids(db, user)
    if allowed is not None:
        query = query.where(Student.id.in_(allowed or {""}))
    if q:
        like = f"%{q.lower()}%"
        query = query.where(or_(func.lower(Student.first_name).like(like), func.lower(Student.last_name).like(like), func.lower(Student.student_no).like(like)))
    if grade_id: query = query.where(Student.grade_id == grade_id)
    if class_id: query = query.where(Student.class_id == class_id)
    if status_: query = query.where(Student.status == status_)
    return [student_out(s) for s in db.scalars(query.order_by(Student.last_name, Student.first_name))]


@router.post("/students", response_model=StudentOut, status_code=201)
def create_student(body: StudentIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    cls = db.get(ClassGroup, body.class_id)
    if not cls or cls.grade_id != body.grade_id:
        raise HTTPException(422, "The class does not belong to the selected grade.")
    subjects = load_subjects(db, body.subject_ids)
    grade = db.get(Grade, body.grade_id)
    if any(grade not in s.grades for s in subjects):
        raise HTTPException(422, "Every subject must be offered in the student's grade.")
    if body.new_parent:
        parent = Parent(**body.new_parent.model_dump())
        db.add(parent); db.flush()
    else:
        parent = db.get(Parent, body.parent_id)
        if not parent:
            raise HTTPException(422, "Parent not found.")
    year = body.enrolment_date.year
    count = db.scalar(select(func.count()).select_from(Student)) or 0
    s = Student(student_no=f"BIT-{year}-{count + 1:03d}", first_name=body.first_name.strip(), last_name=body.last_name.strip(), date_of_birth=body.date_of_birth,
                gender=body.gender, grade_id=body.grade_id, class_id=body.class_id, parent_id=parent.id, alt_contact=body.alt_contact,
                address=body.address, enrolment_date=body.enrolment_date, status="active")
    while db.scalar(select(Student.id).where(Student.student_no == s.student_no)):
        count += 1; s.student_no = f"BIT-{year}-{count + 1:03d}"
    s.subjects = subjects
    db.add(s); db.flush()
    db.add(Enrolment(student_id=s.id, event_date=body.enrolment_date, action="Registered", detail=f"Enrolled in {grade.name}, {cls.name}"))
    if body.charge_fees:
        term = term_for(db, body.enrolment_date)
        for f in db.scalars(select(FeeStructure).where(FeeStructure.grade_id == body.grade_id, FeeStructure.category.in_(["Registration", "Tuition"]))):
            db.add(Charge(student_id=s.id, category=f.category, term=term, amount=f.amount, description=f"{term} {f.category.lower()}" if f.category == "Tuition" else "Registration fee",
                          issued_on=body.enrolment_date, due_date=body.enrolment_date + timedelta(days=14 if f.category == "Tuition" else 0)))
    audit(db, user, "student.created", "student", s.student_no, f"Registered {s.full_name} ({grade.name})", client_ip(request))
    db.commit(); db.refresh(s)
    return student_out(s)


@router.get("/students/{student_id}", response_model=StudentOut)
def get_student(student_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    return student_out(ensure_student_access(db, user, student_id))


@router.patch("/students/{student_id}", response_model=StudentOut)
def update_student(student_id: str, body: StudentUpdate, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    s = db.get(Student, student_id)
    if not s:
        raise HTTPException(404, "Student not found.")
    data = body.model_dump(exclude_unset=True)
    changes: list[str] = []
    if "subject_ids" in data:
        s.subjects = load_subjects(db, data.pop("subject_ids")); changes.append("subjects updated")
    for k, v in data.items():
        if getattr(s, k) != v:
            changes.append(f"{k}: {getattr(s, k)} → {v}"); setattr(s, k, v)
    cls = db.get(ClassGroup, s.class_id)
    if cls.grade_id != s.grade_id:
        raise HTTPException(422, "The class does not belong to the selected grade.")
    if changes:
        db.add(Enrolment(student_id=s.id, event_date=date.today(), action="Record updated", detail="; ".join(changes)))
        audit(db, user, "student.updated", "student", s.student_no, f"{s.full_name}: {'; '.join(changes)}", client_ip(request))
    db.commit(); db.refresh(s)
    return student_out(s)


@router.get("/students/{student_id}/history", response_model=list[EnrolmentOut])
def student_history(student_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    ensure_student_access(db, user, student_id)
    return list(db.scalars(select(Enrolment).where(Enrolment.student_id == student_id).order_by(Enrolment.event_date.desc())))


@router.get("/students/{student_id}/attendance", response_model=list[AttendanceOut])
def student_attendance(student_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    ensure_student_access(db, user, student_id)
    return list(db.scalars(select(AttendanceRecord).where(AttendanceRecord.student_id == student_id).order_by(AttendanceRecord.lesson_date.desc())))


@router.get("/students/{student_id}/results")
def student_results(student_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    ensure_student_access(db, user, student_id)
    rows = db.scalars(select(ExaminationResult).where(ExaminationResult.student_id == student_id))
    return sorted((result_out(r) for r in rows), key=lambda r: r.assessment_date, reverse=True)


@router.get("/students/{student_id}/statement")
def student_statement(student_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Fee statement. Visible to admin, the linked parent, and the student themself (if the centre allows it)."""
    from ...models import CentreSetting
    ensure_student_access(db, user, student_id)
    if user.role == "tutor":
        raise HTTPException(403, "Tutors do not have access to fee information.")
    if user.role == "student":
        pol = db.get(CentreSetting, "policies")
        if pol and not pol.value.get("show_fees_to_students", True):
            raise HTTPException(403, "Fee information is shared with parents only.")
    charges = list(db.scalars(select(Charge).where(Charge.student_id == student_id).order_by(Charge.issued_on.desc())))
    payments = list(db.scalars(select(Payment).where(Payment.student_id == student_id).order_by(Payment.payment_date.desc())))
    return {"billed": billed(db, student_id), "paid": paid(db, student_id), "balance": balance(db, student_id),
            "charges": [ChargeOut.model_validate(c) for c in charges], "payments": [payment_out(p) for p in payments]}


# ---------------- parents ----------------
@router.get("/parents", response_model=list[ParentOut])
def list_parents(user: User = Depends(admin_only), db: Session = Depends(get_db)):
    return list(db.scalars(select(Parent).order_by(Parent.name)))


@router.get("/parents/me/children", response_model=list[StudentOut])
def my_children(user: User = Depends(require_roles("parent")), db: Session = Depends(get_db)):
    return [student_out(s) for s in db.scalars(select(Student).where(Student.parent_id == user.parent_id))]


@router.post("/parents", response_model=ParentOut, status_code=201)
def create_parent(body: ParentIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = Parent(**body.model_dump()); db.add(p); db.flush()
    audit(db, user, "parent.created", "parent", p.id, p.name, client_ip(request)); db.commit()
    return p


@router.patch("/parents/{parent_id}", response_model=ParentOut)
def update_parent(parent_id: str, body: ParentUpdate, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Parent, parent_id)
    if not p:
        raise HTTPException(404, "Parent not found.")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(p, k, v)
    audit(db, user, "parent.updated", "parent", p.id, p.name, client_ip(request)); db.commit()
    return p


# ---------------- tutors ----------------
@router.get("/tutors", response_model=list[TutorOut])
def list_tutors(user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    return [tutor_out(t) for t in db.scalars(select(Tutor).order_by(Tutor.staff_no))]


@router.post("/tutors", response_model=TutorOut, status_code=201)
def create_tutor(body: TutorIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    if db.scalar(select(Tutor.id).where(func.lower(Tutor.email) == body.email.lower())):
        raise HTTPException(409, "A tutor with this email already exists.")
    n = (db.scalar(select(func.count()).select_from(Tutor)) or 0) + 1
    t = Tutor(staff_no=f"BIT-T-{n:03d}", **body.model_dump(exclude={"subject_ids"}))
    t.subjects = load_subjects(db, body.subject_ids)
    db.add(t); db.flush()
    audit(db, user, "tutor.created", "tutor", t.staff_no, f"{t.first_name} {t.last_name}", client_ip(request)); db.commit()
    return tutor_out(t)


@router.patch("/tutors/{tutor_id}", response_model=TutorOut)
def update_tutor(tutor_id: str, body: TutorUpdate, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    t = db.get(Tutor, tutor_id)
    if not t:
        raise HTTPException(404, "Tutor not found.")
    data = body.model_dump(exclude_unset=True)
    if "subject_ids" in data:
        t.subjects = load_subjects(db, data.pop("subject_ids"))
    for k, v in data.items():
        setattr(t, k, v)
    audit(db, user, "tutor.updated", "tutor", t.staff_no, f"{t.first_name} {t.last_name}", client_ip(request)); db.commit()
    return tutor_out(t)
