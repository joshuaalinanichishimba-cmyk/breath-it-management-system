import time
from collections import defaultdict, deque
from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ...db import get_db
from ...deps import require_roles, client_ip, current_user
from ...models import Charge, CentreSetting, Grade, Lead, Parent, ReminderLog, Student, User
from ...schemas.growth import EnquiryIn, LeadIn, LeadOut, LeadUpdate
from ...services.audit import audit

router = APIRouter(tags=["growth"])
admin_only = require_roles("admin")
_hits: dict[str, deque] = defaultdict(deque)


def _rate_limit(ip: str | None, limit: int = 5, window: int = 3600) -> None:
    """Simple per-IP limit for the public form (use a shared store such as Redis when running several instances)."""
    q = _hits[ip or "unknown"]; now = time.time()
    while q and now - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(429, "Too many enquiries from this connection. Please call or WhatsApp the centre instead.")
    q.append(now)


@router.post("/enquiries", status_code=202)
def public_enquiry(body: EnquiryIn, request: Request, db: Session = Depends(get_db)):
    """Public, unauthenticated. Creates a lead for the admissions pipeline."""
    if body.website:  # honeypot filled → silently accept and drop
        return {"ok": True}
    _rate_limit(client_ip(request))
    if not db.get(Grade, body.grade_id):
        raise HTTPException(422, "Unknown grade.")
    referrer = db.scalar(select(Parent).where(func.upper(Parent.referral_code) == (body.referral_code or "").strip().upper())) if body.referral_code else None
    lead = Lead(child_name=body.child_name.strip(), grade_id=body.grade_id, subject_ids=body.subject_ids, parent_name=body.parent_name.strip(), phone=body.phone,
                source="Referral" if referrer else (body.source or "Website"), referred_by_parent_id=referrer.id if referrer else None,
                notes="Submitted through the online enquiry form")
    db.add(lead); db.flush()
    db.add_all([])
    from ...models import AuditLog
    db.add(AuditLog(actor_id="public", actor_name="Online enquiry form", action="lead.created", entity="lead", entity_id=lead.id, detail=f"{lead.child_name} — {lead.parent_name}", ip_address=client_ip(request)))
    db.commit()
    return {"ok": True}


@router.get("/leads", response_model=list[LeadOut])
def list_leads(stage: str | None = None, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    q = select(Lead).order_by(Lead.created_at.desc())
    if stage:
        q = q.where(Lead.stage == stage)
    return list(db.scalars(q))


@router.post("/leads", response_model=LeadOut, status_code=201)
def create_lead(body: LeadIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    lead = Lead(**body.model_dump()); db.add(lead); db.flush()
    audit(db, user, "lead.created", "lead", lead.id, f"{lead.child_name} via {lead.source}", client_ip(request)); db.commit()
    return lead


@router.patch("/leads/{lead_id}", response_model=LeadOut)
def update_lead(lead_id: str, body: LeadUpdate, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead:
        raise HTTPException(404, "Enquiry not found.")
    data = body.model_dump(exclude_unset=True)
    if data.get("stage") == "lost" and not (data.get("lost_reason") or lead.lost_reason):
        raise HTTPException(422, "Record why the family did not join.")
    if data.get("stage") == "enrolled" and not (data.get("student_id") or lead.student_id):
        raise HTTPException(422, "Register the student first, then link the student_id.")
    if data.get("student_id") and not db.get(Student, data["student_id"]):
        raise HTTPException(422, "Student not found.")
    before = lead.stage
    for k, v in data.items():
        setattr(lead, k, v)
    audit(db, user, "lead.updated", "lead", lead.id, f"{lead.child_name}: {before} → {lead.stage}", client_ip(request)); db.commit()
    return lead


@router.post("/leads/{lead_id}/reward", response_model=LeadOut)
def reward_referral(lead_id: str, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id)
    if not lead or lead.stage != "enrolled" or not lead.referred_by_parent_id or lead.reward_applied:
        raise HTTPException(409, "This referral is not eligible for a reward.")
    child = db.scalar(select(Student).where(Student.parent_id == lead.referred_by_parent_id, Student.status == "active"))
    if not child:
        raise HTTPException(409, "The referring family has no active student to credit.")
    pol = db.get(CentreSetting, "growth")
    amount = Decimal(str((pol.value if pol else {}).get("referral_reward", 100)))
    term = (db.get(CentreSetting, "centre").value or {}).get("current_term", str(date.today().year))
    db.add(Charge(student_id=child.id, category="Discount", term=term, amount=-amount, description=f"Referral reward — {lead.child_name} enrolled", issued_on=date.today(), due_date=date.today()))
    lead.reward_applied = True
    audit(db, user, "referral.rewarded", "lead", lead.id, f"K{amount} credit to {child.parent.name}", client_ip(request)); db.commit()
    return lead


class ReminderIn(BaseModel):
    parent_id: str
    channel: str = Field(pattern="^(WhatsApp|SMS)$")
    amount: Decimal = Field(ge=0)


@router.post("/reminders", status_code=201)
def log_reminder(body: ReminderIn, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    """Records that staff opened a WhatsApp/SMS reminder for a family (the message is sent from the centre's phone)."""
    if not db.get(Parent, body.parent_id):
        raise HTTPException(404, "Parent not found.")
    db.add(ReminderLog(parent_id=body.parent_id, channel=body.channel, amount=body.amount, sent_by=user.name))
    audit(db, user, "reminder.opened", "parent", body.parent_id, f"{body.channel} K{body.amount}"); db.commit()
    return {"ok": True}


@router.get("/parents/me/referral")
def my_referral(user: User = Depends(require_roles("parent")), db: Session = Depends(get_db)):
    p = db.get(Parent, user.parent_id)
    leads = list(db.scalars(select(Lead).where(Lead.referred_by_parent_id == p.id)))
    return {"code": p.referral_code, "referrals": [{"child_name": l.child_name, "stage": l.stage, "reward_applied": l.reward_applied} for l in leads]}
