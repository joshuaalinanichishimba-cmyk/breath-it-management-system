<script setup lang="ts">
defineProps<{ title: string; sub?: string }>()
</script>
<template>
  <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-5">
    <div class="min-w-0">
      <h1 class="text-[22px] leading-tight font-semibold tracking-[-0.015em]">{{ title }}</h1>
      <p v-if="sub" class="sub mt-1 max-w-[70ch]">{{ sub }}</p>
    </div>
    <div v-if="$slots.default" class="flex flex-wrap gap-2 shrink-0"><slot /></div>
  </div>
</template>
