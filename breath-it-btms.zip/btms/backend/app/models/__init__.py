"""SQLAlchemy models. Importing this package registers every table on Base.metadata."""
from .users import Role, User
from .academics import Grade, Subject, grade_subjects, ClassGroup, TimetableSlot
from .people import Parent, Tutor, tutor_subjects, Student, student_subjects, Enrolment
from .records import AttendanceRecord, Assessment, ExaminationResult
from .finance import FeeStructure, Charge, Payment, Receipt
from .comms import Announcement, LearningMaterial, AuditLog, CentreSetting
from .growth import Lead, ReminderLog

__all__ = [
    "Role", "User", "Grade", "Subject", "grade_subjects", "ClassGroup", "TimetableSlot", "Parent", "Tutor", "tutor_subjects",
    "Student", "student_subjects", "Enrolment", "AttendanceRecord", "Assessment", "ExaminationResult", "FeeStructure", "Charge",
    "Payment", "Receipt", "Announcement", "LearningMaterial", "AuditLog", "CentreSetting", "Lead", "ReminderLog",
]
