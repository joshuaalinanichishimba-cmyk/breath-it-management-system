from datetime import time
from pydantic import BaseModel, Field
from .common import ORM


class GradeIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    sort_order: int = 0
    exam_level: str = ""
    active: bool = True


class GradeOut(ORM):
    id: str
    name: str
    sort_order: int
    exam_level: str
    active: bool


class SubjectIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    code: str = Field(min_length=1, max_length=12)
    grade_ids: list[str] = Field(min_length=1)
    active: bool = True


class SubjectOut(ORM):
    id: str
    name: str
    code: str
    active: bool
    grade_ids: list[str] = []


class ClassIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    grade_id: str
    class_tutor_id: str | None = None
    room: str = Field(min_length=1, max_length=40)
    capacity: int = Field(gt=0, le=200)
    active: bool = True


class ClassOut(ORM):
    id: str
    name: str
    grade_id: str
    class_tutor_id: str | None
    room: str
    capacity: int
    active: bool


class SlotIn(BaseModel):
    class_id: str
    subject_id: str
    tutor_id: str
    day_of_week: int = Field(ge=1, le=7)
    start_time: time
    end_time: time
    room: str = Field(min_length=1, max_length=40)


class SlotOut(ORM):
    id: str
    class_id: str
    subject_id: str
    tutor_id: str
    day_of_week: int
    start_time: time
    end_time: time
    room: str
