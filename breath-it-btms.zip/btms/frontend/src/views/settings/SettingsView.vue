<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { Smartphone, MessageSquare, Wallet, Mail, RotateCcw, Upload, Trash2, Wand2 } from 'lucide-vue-next'
import { brandTokens, dominantColour, resizeLogo, hexToRgb } from '@/services/brand'
import PageHeader from '@/components/ui/PageHeader.vue'
import Pager from '@/components/ui/Pager.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { usePager } from '@/composables/usePager'
import { fmtDateTime } from '@/services/dates'
import { DEMO_MODE } from '@/config'

const store = useDb(); const ui = useUi()
const s = computed(() => store.db.settings)
const f = reactive({ centreName: s.value.centreName, tagline: s.value.tagline, address: s.value.address, phone: s.value.phone, email: s.value.email, receiptFooter: s.value.receiptFooter, currentTerm: s.value.currentTerm, lowAttendanceThreshold: s.value.lowAttendanceThreshold, showFeesToStudents: s.value.showFeesToStudents })
function save() {
  if (!f.centreName.trim()) return ui.error('The centre name is required.')
  if (!(f.lowAttendanceThreshold >= 0 && f.lowAttendanceThreshold <= 100)) return ui.error('The attendance threshold must be between 0 and 100.')
  store.updateSettings({ ...f }); ui.success('Settings saved')
}
// ---------- brand ----------
const colour = ref(s.value.brand.primary)
const suggested = ref<string | null>(null)
const presets = ['#493a8f', '#1d4ed8', '#0f766e', '#15803d', '#b91c1c', '#c2410c', '#a16207', '#0e7490', '#7e22ce', '#1f2937']
const valid = computed(() => !!hexToRgb(colour.value))
const tokens = computed(() => brandTokens(valid.value ? colour.value : s.value.brand.primary))
function applyColour(c = colour.value) {
  if (!hexToRgb(c)) return ui.error('Enter a colour like #1D4ED8.')
  colour.value = c.startsWith('#') ? c : '#' + c
  store.updateSettings({ brand: { ...s.value.brand, primary: colour.value } }); ui.success('Brand colour applied', 'Buttons, navigation, charts, receipts and report cards now use it.')
}
async function onLogo(e: Event) {
  const file = (e.target as HTMLInputElement).files?.[0]; if (!file) return
  if (file.size > 5 * 1024 * 1024) return ui.error('That image is over 5 MB. Use a smaller PNG or JPG.')
  try {
    const url = await resizeLogo(file)
    store.updateSettings({ brand: { ...s.value.brand, logoDataUrl: url } })
    suggested.value = await dominantColour(url)
    ui.success('Logo uploaded', suggested.value ? `Its main colour is ${suggested.value.toUpperCase()} — apply it below.` : 'It now appears in the sidebar, sign-in page, receipts and reports.')
  } catch (err) { ui.error((err as Error).message) }
  (e.target as HTMLInputElement).value = ''
}
function removeLogo() { store.updateSettings({ brand: { ...s.value.brand, logoDataUrl: null } }); suggested.value = null; ui.info('Logo removed') }

// ---------- online payments & growth ----------
const op = reactive(JSON.parse(JSON.stringify(s.value.onlinePayments)) as typeof s.value.onlinePayments)
const referral = ref(s.value.referralReward)
function savePayments() {
  if (!(op.feePercent >= 0 && op.feePercent <= 10)) return ui.error('Transaction fee must be between 0% and 10%.')
  if (!(referral.value >= 0)) return ui.error('Referral reward cannot be negative.')
  store.updateSettings({ onlinePayments: JSON.parse(JSON.stringify(op)), referralReward: referral.value }); ui.success('Payment and referral settings saved')
}

const integrations = [
  { icon: Smartphone, name: 'SMS', body: 'Send announcements and fee reminders by text message (e.g. a Zambian bulk SMS gateway).' },
  { icon: MessageSquare, name: 'WhatsApp', body: 'Deliver announcements and receipts through the WhatsApp Business API.' },
  { icon: Wallet, name: 'Payment gateway', body: 'Airtel Money, MTN MoMo, Zamtel Kwacha and card collections with automatic confirmation (e.g. pawaPay, DPO Pay, MoneyUnify, Bila). The demo simulates it.' },
  { icon: Mail, name: 'Email', body: 'Email receipts and report cards to parents.' },
]
const auditQ = ref('')
const audit = computed(() => store.db.audit.filter((a) => !auditQ.value.trim() || `${a.action} ${a.actorName} ${a.detail} ${a.entityId}`.toLowerCase().includes(auditQ.value.trim().toLowerCase())))
const { page, pages, rows, range } = usePager(audit, 12)
async function reset() {
  if (!(await ui.confirm({ title: 'Reset demonstration data?', body: 'All changes made in this browser — new students, payments, marks and registers — will be discarded and the original sample data restored.', confirmLabel: 'Reset data', tone: 'danger' }))) return
  store.reset(); Object.assign(f, { ...store.db.settings }); ui.success('Demonstration data restored')
}
</script>
<template>
  <div>
    <PageHeader title="Settings" sub="Centre details, academic calendar, integrations and the audit trail" />
    <div class="grid lg:grid-cols-2 gap-4 mb-4">
      <section class="card card-pad">
        <h2 class="h-section mb-4">Centre details</h2>
        <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
          <div class="sm:col-span-2"><label class="label" for="st-n">Centre name</label><input id="st-n" v-model="f.centreName" class="input" /></div>
          <div class="sm:col-span-2"><label class="label" for="st-tg">Tagline</label><input id="st-tg" v-model="f.tagline" class="input" /></div>
          <div class="sm:col-span-2"><label class="label" for="st-a">Address</label><input id="st-a" v-model="f.address" class="input" /></div>
          <div><label class="label" for="st-p">Phone</label><input id="st-p" v-model="f.phone" class="input" /></div>
          <div><label class="label" for="st-e">Email</label><input id="st-e" v-model="f.email" class="input" /></div>
          <div class="sm:col-span-2"><label class="label" for="st-r">Receipt footer</label><input id="st-r" v-model="f.receiptFooter" class="input" /></div>
          <button type="submit" class="hidden" />
        </form>
      </section>
      <section class="card card-pad">
        <h2 class="h-section mb-4">Academic year and policies</h2>
        <div class="grid sm:grid-cols-2 gap-4">
          <div><label class="label" for="st-t">Current term</label><select id="st-t" v-model="f.currentTerm" class="select"><option v-for="t in s.terms" :key="t.name">{{ t.name }}</option></select></div>
          <div><label class="label" for="st-th">Low attendance alert below (%)</label><input id="st-th" v-model.number="f.lowAttendanceThreshold" type="number" min="0" max="100" class="input tnum" /></div>
          <div class="sm:col-span-2">
            <span class="label">Term dates (sample — confirm with management)</span>
            <ul class="text-[13px] grid gap-1"><li v-for="t in s.terms" :key="t.name" class="flex justify-between"><span>{{ t.name }}</span><span class="text-muted tnum">{{ t.start }} → {{ t.end }}</span></li></ul>
          </div>
          <label class="sm:col-span-2 flex items-center gap-2.5 text-[13px]"><input v-model="f.showFeesToStudents" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />Students can see their own fee balance and receipts</label>
        </div>
        <div class="flex justify-end mt-5"><button class="btn btn-primary" @click="save">Save settings</button></div>
      </section>
    </div>

    <section class="card card-pad mb-4">
      <h2 class="h-section">Brand</h2>
      <p class="sub mb-4">Upload the Breath It logo and the system takes its colour automatically, or enter the exact colour from the signboard or uniform.</p>
      <div class="grid lg:grid-cols-[1fr_1fr_300px] gap-6">
        <div>
          <span class="label">Logo</span>
          <div class="flex items-center gap-3">
            <div class="h-16 w-16 rounded-lg border border-line bg-white flex items-center justify-center overflow-hidden">
              <img v-if="s.brand.logoDataUrl" :src="s.brand.logoDataUrl" alt="Current logo" class="max-h-full max-w-full object-contain" />
              <span v-else class="text-[11px] text-faint text-center px-1">No logo yet</span>
            </div>
            <div class="flex flex-col gap-1.5">
              <label class="btn btn-secondary btn-sm cursor-pointer"><Upload :size="14" />Upload PNG or JPG<input type="file" accept="image/png,image/jpeg,image/webp" class="sr-only" @change="onLogo" /></label>
              <button v-if="s.brand.logoDataUrl" class="btn btn-ghost btn-sm text-bad" @click="removeLogo"><Trash2 :size="14" />Remove</button>
            </div>
          </div>
          <div v-if="suggested" class="mt-3 rounded-md bg-sunken p-2.5 flex items-center gap-2.5 text-[13px]">
            <span class="h-6 w-6 rounded-md border border-line" :style="{ background: suggested }" />
            <span class="flex-1">Main colour in the logo: <b class="tnum">{{ suggested.toUpperCase() }}</b></span>
            <button class="btn btn-primary btn-sm" @click="applyColour(suggested!)"><Wand2 :size="13" />Use it</button>
          </div>
        </div>
        <div>
          <label class="label" for="br-c">Brand colour</label>
          <div class="flex gap-2">
            <input v-model="colour" type="color" class="h-9 w-12 rounded-md border border-line bg-surface p-1 cursor-pointer" aria-label="Pick brand colour" />
            <input id="br-c" v-model="colour" class="input tnum uppercase" placeholder="#493A8F" />
            <button class="btn btn-primary" :disabled="!valid" @click="applyColour()">Apply</button>
          </div>
          <div class="flex flex-wrap gap-1.5 mt-3">
            <button v-for="p in presets" :key="p" class="h-7 w-7 rounded-md border border-line" :style="{ background: p }" :aria-label="`Use ${p}`" @click="colour = p" />
          </div>
          <p v-if="valid && tokens.rawContrast < 3" class="text-[12px] text-warn mt-2">This colour is very light; text on buttons will use dark ink so it stays readable.</p>
        </div>
        <div class="rounded-lg border border-line overflow-hidden" aria-label="Preview">
          <div class="px-3 py-2.5 flex items-center justify-between" :style="{ background: `rgb(${tokens.light.brand})`, color: `rgb(${tokens.light.ink})` }"><span class="font-semibold text-[13px]">Breath It</span><span class="text-[11px] opacity-80">Preview</span></div>
          <div class="p-3 grid gap-2 bg-surface">
            <span class="h-8 rounded-md flex items-center px-2.5 text-[12.5px] font-medium" :style="{ background: `rgb(${tokens.light.soft})` }">Selected menu item</span>
            <span class="h-8 rounded-md flex items-center justify-center text-[12.5px] font-medium" :style="{ background: `rgb(${tokens.light.brand})`, color: `rgb(${tokens.light.ink})` }">Record payment</span>
          </div>
        </div>
      </div>
    </section>

    <section class="card card-pad mb-4">
      <h2 class="h-section">Online payments and referrals</h2>
      <p class="sub mb-4">What parents can use in the app. Mobile money and card payments are confirmed by the payment gateway and get a receipt instantly; bank transfers wait for the office to check the statement.</p>
      <div class="grid lg:grid-cols-3 gap-6">
        <div class="grid gap-2 content-start">
          <label class="flex items-center gap-2.5 text-[13px] font-medium"><input v-model="op.enabled" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />Allow parents to pay in the app</label>
          <span class="label mt-2">Payment methods</span>
          <label v-for="[k, l] in [['airtel', 'Airtel Money'], ['mtn', 'MTN MoMo'], ['zamtel', 'Zamtel Kwacha'], ['card', 'Bank card (Visa / Mastercard)'], ['bank', 'Bank transfer']] as const" :key="k" class="flex items-center gap-2.5 text-[13px]"><input v-model="op.methods[k]" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />{{ l }}</label>
          <div class="mt-2 text-[12.5px]"><span class="text-muted">Gateway:</span> <span class="badge badge-warn">Not connected — demo checkout is simulated</span></div>
        </div>
        <div class="grid gap-3 content-start">
          <span class="label">Bank details shown to parents</span>
          <input v-model="op.bank.bankName" class="input" placeholder="Bank" aria-label="Bank name" />
          <input v-model="op.bank.accountName" class="input" placeholder="Account name" aria-label="Account name" />
          <input v-model="op.bank.accountNumber" class="input tnum" placeholder="Account number" aria-label="Account number" />
          <input v-model="op.bank.branch" class="input" placeholder="Branch" aria-label="Branch" />
        </div>
        <div class="grid gap-3 content-start">
          <label class="flex items-start gap-2.5 text-[13px]"><input v-model="op.passFeeToPayer" type="checkbox" class="h-4 w-4 mt-0.5 accent-[rgb(var(--brand))]" /><span>Parent pays the transaction fee<br /><span class="text-muted text-[12px]">Otherwise the centre absorbs it (gateways typically charge around 2–3.5%).</span></span></label>
          <div><label class="label" for="op-fee">Transaction fee (%)</label><input id="op-fee" v-model.number="op.feePercent" type="number" min="0" max="10" step="0.1" class="input tnum" /></div>
          <div><label class="label" for="op-ref">Referral reward per enrolled family (K)</label><input id="op-ref" v-model.number="referral" type="number" min="0" step="10" class="input tnum" />
            <p class="text-[12px] text-muted mt-1">Credited to the referring family’s fees. Set 0 to turn referrals off.</p></div>
          <button class="btn btn-primary justify-self-start" @click="savePayments">Save</button>
        </div>
      </div>
    </section>

    <section class="card card-pad mb-4">
      <h2 class="h-section">Integrations</h2>
      <p class="sub mb-4">Each needs an account with a provider and the hosted backend. Until then nothing is sent externally, and the system says so wherever it matters.</p>
      <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div v-for="i in integrations" :key="i.name" class="rounded-lg border border-line p-3.5">
          <div class="flex items-center justify-between"><div class="flex items-center gap-2 font-medium"><component :is="i.icon" :size="16" class="text-brand" />{{ i.name }}</div><span class="badge badge-mute">Not connected</span></div>
          <p class="text-[12.5px] text-muted mt-2">{{ i.body }}</p>
        </div>
      </div>
    </section>

    <section class="card mb-4">
      <div class="flex flex-wrap items-center justify-between gap-2 px-4 sm:px-5 pt-4 pb-3">
        <div><h2 class="h-section">Audit trail</h2><p class="sub">Who changed what — students, payments, marks, registers and settings</p></div>
        <input v-model="auditQ" class="input w-full sm:w-64" placeholder="Filter the log" aria-label="Filter audit log" />
      </div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>When</th><th>Who</th><th>Action</th><th>Detail</th></tr></thead>
        <tbody><tr v-for="a in rows" :key="a.id"><td class="whitespace-nowrap text-muted">{{ fmtDateTime(a.at) }}</td><td class="whitespace-nowrap">{{ a.actorName }}</td><td><code class="text-[12px] bg-sunken px-1.5 py-0.5 rounded">{{ a.action }}</code></td><td class="min-w-[240px]">{{ a.detail }} <span v-if="a.entityId" class="text-faint tnum">{{ a.entityId }}</span></td></tr></tbody>
      </table></div>
      <Pager v-model="page" :pages="pages" :range="range" />
    </section>

    <section v-if="DEMO_MODE" class="card card-pad border-bad/40">
      <h2 class="h-section">Demonstration data</h2>
      <p class="sub mt-1 mb-3">Everything in this demo is fictional and stored only in this browser. Reset it before a fresh presentation.</p>
      <button class="btn btn-danger" @click="reset"><RotateCcw :size="15" />Reset demonstration data</button>
    </section>
  </div>
</template>
