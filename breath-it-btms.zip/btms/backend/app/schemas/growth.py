from datetime import date, datetime
from typing import Literal
from pydantic import BaseModel, Field, field_validator
from .common import ORM, check_zm_phone

Stage = Literal["new", "contacted", "trial", "enrolled", "lost"]
Source = Literal["Walk-in", "WhatsApp", "Facebook", "Referral", "Flyer", "School visit", "Website"]


class EnquiryIn(BaseModel):
    """Public enquiry form. `website` is a honeypot field that real visitors never fill."""
    parent_name: str = Field(min_length=2, max_length=120)
    phone: str
    child_name: str = Field(min_length=2, max_length=120)
    grade_id: str
    subject_ids: list[str] = []
    source: Source | None = None
    referral_code: str | None = Field(default=None, max_length=20)
    website: str | None = None

    @field_validator("phone")
    @classmethod
    def _p(cls, v): return check_zm_phone(v)


class LeadIn(BaseModel):
    child_name: str = Field(min_length=2, max_length=120)
    grade_id: str
    subject_ids: list[str] = []
    parent_name: str = Field(min_length=2, max_length=120)
    phone: str
    source: Source
    referred_by_parent_id: str | None = None
    follow_up_on: date | None = None
    notes: str = ""

    @field_validator("phone")
    @classmethod
    def _p(cls, v): return check_zm_phone(v)


class LeadUpdate(BaseModel):
    stage: Stage | None = None
    follow_up_on: date | None = None
    notes: str | None = None
    lost_reason: str | None = None
    student_id: str | None = None


class LeadOut(ORM):
    id: str
    child_name: str
    grade_id: str
    subject_ids: list[str]
    parent_name: str
    phone: str
    source: str
    referred_by_parent_id: str | None
    stage: str
    created_at: datetime
    follow_up_on: date | None
    notes: str
    lost_reason: str | None
    student_id: str | None
    reward_applied: bool
