<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { useRoute, RouterLink } from 'vue-router'
import { CheckCheck, Info } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatTile from '@/components/ui/StatTile.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import Avatar from '@/components/ui/Avatar.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useScope } from '@/composables/useScope'
import type { AttendanceStatus } from '@/types'
import { iso, addDays, isoWeekday, DAY_NAMES, DAY_SHORT, fmtDate, fmtDateTime, weekStart } from '@/services/dates'
import { pct } from '@/services/format'
import { attendanceRate, attendanceCounts } from '@/services/analytics'

const store = useDb(); const ui = useUi(); const scope = useScope(); const route = useRoute()
const today = iso()
const tab = ref<'register' | 'overview'>(route.query.lesson || scope.role.value === 'tutor' ? 'register' : 'overview')

// ---------- take register ----------
const qLesson = typeof route.query.lesson === 'string' ? store.lessonMap.get(route.query.lesson) : undefined
const classId = ref(qLesson?.classId ?? [...scope.classIds.value][0] ?? '')
const lessonId = ref(qLesson?.id ?? '')
const date = ref(typeof route.query.date === 'string' ? route.query.date : today)
const classLessons = computed(() => scope.lessons.value.filter((l) => l.classId === classId.value).sort((a, b) => a.day - b.day || a.start.localeCompare(b.start)))
watch(classId, () => { if (!classLessons.value.some((l) => l.id === lessonId.value)) lessonId.value = classLessons.value.find((l) => l.day === isoWeekday(date.value))?.id ?? classLessons.value[0]?.id ?? '' }, { immediate: true })
const lesson = computed(() => store.lessonMap.get(lessonId.value))
const lastOccurrence = computed(() => { if (!lesson.value) return today; let d = today; while (isoWeekday(d) !== lesson.value.day) d = addDays(d, -1); return d })
watch(lessonId, () => { if (lesson.value && isoWeekday(date.value) !== lesson.value.day) date.value = lastOccurrence.value })
const dateProblem = computed(() => {
  if (!lesson.value) return ''
  if (date.value > today) return 'You cannot take a register for a future date.'
  if (isoWeekday(date.value) !== lesson.value.day) return `This lesson runs on ${DAY_NAMES[lesson.value.day]}s. ${fmtDate(date.value)} is a ${DAY_NAMES[isoWeekday(date.value)]}.`
  return ''
})
const roster = computed(() => (lesson.value && !dateProblem.value ? store.rosterFor(lesson.value.id, date.value) : []))
const existing = computed(() => (lesson.value ? store.registerFor(lesson.value.id, date.value) : []))
const marks = reactive<Record<string, AttendanceStatus>>({})
watch([roster, existing], () => {
  for (const k of Object.keys(marks)) delete marks[k]
  for (const s of roster.value) marks[s.id] = existing.value.find((r) => r.studentId === s.id)?.status ?? 'present'
}, { immediate: true })
const counts = computed(() => { const v = Object.values(marks); return { present: v.filter((x) => x === 'present').length, late: v.filter((x) => x === 'late').length, absent: v.filter((x) => x === 'absent').length } })
function allPresent() { for (const s of roster.value) marks[s.id] = 'present' }
async function submit() {
  if (!lesson.value || dateProblem.value || !roster.value.length) return
  if (existing.value.length && !(await ui.confirm({ title: 'Update this register?', body: `A register was already submitted for ${fmtDate(date.value)}. Saving replaces the earlier marks for these students — no duplicate records are created.`, confirmLabel: 'Update register' }))) return
  const r = store.submitRegister(lesson.value.id, date.value, { ...marks })
  ui.success(existing.value.length && !r.created ? 'Register updated' : 'Register submitted', `${counts.value.present} present, ${counts.value.late} late, ${counts.value.absent} absent${r.updated ? ` · ${r.updated} corrected` : ''}`)
}
const opts: { v: AttendanceStatus; label: string; on: string }[] = [
  { v: 'present', label: 'Present', on: 'bg-ok text-white border-ok' },
  { v: 'late', label: 'Late', on: 'bg-warn text-white border-warn' },
  { v: 'absent', label: 'Absent', on: 'bg-bad text-white border-bad' },
]

// ---------- overview ----------
const period = ref<'day' | 'week' | 'month'>('week')
const anchor = ref(today)
const range = computed(() => {
  if (period.value === 'day') return { from: anchor.value, to: anchor.value, label: fmtDate(anchor.value) }
  if (period.value === 'week') { const s = weekStart(anchor.value); return { from: s, to: addDays(s, 5), label: `Week of ${fmtDate(s)}` } }
  const y = +anchor.value.slice(0, 4), m = +anchor.value.slice(5, 7)
  return { from: iso(new Date(y, m - 1, 1)), to: iso(new Date(y, m, 0)), label: new Date(y, m - 1, 1).toLocaleString('en-GB', { month: 'long', year: 'numeric' }) }
})
const recs = computed(() => store.db.attendance.filter((a) => a.date >= range.value.from && a.date <= range.value.to && scope.studentIds.value.has(a.studentId) && scope.lessons.value.some((l) => l.id === a.lessonId)))
const c = computed(() => attendanceCounts(recs.value))
const expectedRegisters = computed(() => {
  let n = 0, done = 0
  for (let d = range.value.from; d <= range.value.to && d <= today; d = addDays(d, 1)) {
    for (const l of scope.lessons.value.filter((x) => x.day === isoWeekday(d))) {
      if (!store.rosterFor(l.id, d).length) continue
      n++; if (store.registerFor(l.id, d).length) done++
    }
  }
  return { n, done }
})
const byClass = computed(() => store.db.classes.filter((x) => scope.classIds.value.has(x.id)).map((cl) => {
  const r = recs.value.filter((a) => store.lessonMap.get(a.lessonId)?.classId === cl.id)
  return { cl, rate: attendanceRate(r), ...attendanceCounts(r) }
}))
const byStudent = computed(() => scope.students.value.filter((s) => s.status === 'active').map((s) => {
  const r = recs.value.filter((a) => a.studentId === s.id)
  return { s, rate: attendanceRate(r), ...attendanceCounts(r) }
}).filter((x) => x.total).sort((a, b) => a.rate - b.rate))
const dayLessons = computed(() => period.value === 'day' ? scope.lessons.value.filter((l) => l.day === isoWeekday(anchor.value)).sort((a, b) => a.start.localeCompare(b.start)) : [])
function shift(n: number) {
  if (period.value === 'day') anchor.value = addDays(anchor.value, n)
  else if (period.value === 'week') anchor.value = addDays(anchor.value, 7 * n)
  else { const d = new Date(+anchor.value.slice(0, 4), +anchor.value.slice(5, 7) - 1 + n, 1); anchor.value = iso(d) }
}
</script>

<template>
  <div>
    <PageHeader title="Attendance" :sub="scope.role.value === 'tutor' ? 'Registers for your lessons' : 'Registers for every lesson, plus daily, weekly and monthly summaries'" />
    <div class="tabs mb-5" role="tablist">
      <button role="tab" :aria-selected="tab === 'register'" :class="['tab', tab === 'register' && 'tab-active']" @click="tab = 'register'">Take register</button>
      <button role="tab" :aria-selected="tab === 'overview'" :class="['tab', tab === 'overview' && 'tab-active']" @click="tab = 'overview'">Summary</button>
    </div>

    <!-- REGISTER -->
    <div v-if="tab === 'register'" class="grid lg:grid-cols-[300px_1fr] gap-4 items-start">
      <section class="card card-pad grid gap-4">
        <div><label class="label" for="at-c">Class</label><select id="at-c" v-model="classId" class="select"><option v-for="cl in store.db.classes.filter((x) => scope.classIds.value.has(x.id))" :key="cl.id" :value="cl.id">{{ cl.name }}</option></select></div>
        <div><label class="label" for="at-l">Lesson</label><select id="at-l" v-model="lessonId" class="select"><option v-for="l in classLessons" :key="l.id" :value="l.id">{{ store.subjectName(l.subjectId) }} · {{ DAY_SHORT[l.day] }} {{ l.start }}</option></select></div>
        <div><label class="label" for="at-d">Date</label><input id="at-d" v-model="date" type="date" :max="today" class="input" />
          <button v-if="lesson && date !== lastOccurrence" class="text-[12px] text-brand hover:underline mt-1" @click="date = lastOccurrence">Use most recent {{ DAY_NAMES[lesson.day] }} ({{ fmtDate(lastOccurrence, false) }})</button></div>
        <div v-if="lesson" class="text-[12.5px] text-muted border-t border-line pt-3">{{ store.tutorName(lesson.tutorId) }} · {{ lesson.room }} · {{ lesson.start }}–{{ lesson.end }}</div>
      </section>

      <section class="card">
        <EmptyState v-if="!lesson" title="Choose a lesson" body="Pick the class and lesson you are taking the register for." />
        <EmptyState v-else-if="dateProblem" :title="dateProblem" body="Choose a date when this lesson took place." />
        <EmptyState v-else-if="!roster.length" title="No students to mark" body="No active students in this class take this subject on that date." />
        <template v-else>
          <div class="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-5 pt-4 pb-3 border-b border-line">
            <div><h2 class="h-section">{{ store.subjectName(lesson.subjectId) }} — {{ store.className(lesson.classId) }}</h2><p class="sub">{{ DAY_NAMES[lesson.day] }}, {{ fmtDate(date) }} · {{ roster.length }} students</p></div>
            <button class="btn btn-secondary btn-sm" @click="allPresent"><CheckCheck :size="15" />Mark all present</button>
          </div>
          <div v-if="existing.length" class="mx-4 sm:mx-5 mt-3 rounded-md bg-info-soft text-info px-3 py-2 text-[12.5px] flex gap-2"><Info :size="15" class="shrink-0 mt-px" />
            Register already submitted ({{ fmtDateTime(existing[0].recordedAt) }}). Changes you save will correct it.</div>
          <ul class="divide-y divide-line">
            <li v-for="s in roster" :key="s.id" class="flex flex-wrap items-center gap-3 px-4 sm:px-5 py-2.5">
              <Avatar :name="`${s.firstName} ${s.lastName}`" :size="30" />
              <RouterLink :to="`/students/${s.id}`" class="flex-1 min-w-[140px] font-medium hover:underline">{{ s.firstName }} {{ s.lastName }}</RouterLink>
              <div class="flex gap-1" role="radiogroup" :aria-label="`Attendance for ${s.firstName}`">
                <button v-for="o in opts" :key="o.v" role="radio" :aria-checked="marks[s.id] === o.v" :class="['h-8 px-3 rounded-md border text-[12.5px] font-medium transition-colors', marks[s.id] === o.v ? o.on : 'border-line text-muted hover:text-ink']" @click="marks[s.id] = o.v">{{ o.label }}</button>
              </div>
            </li>
          </ul>
          <div class="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-5 py-3 border-t border-line bg-sunken/40 rounded-b-lg">
            <span class="text-[13px] text-muted tnum">{{ counts.present }} present · {{ counts.late }} late · {{ counts.absent }} absent</span>
            <button class="btn btn-primary" @click="submit">{{ existing.length ? 'Save corrections' : 'Submit register' }}</button>
          </div>
        </template>
      </section>
    </div>

    <!-- OVERVIEW -->
    <div v-else>
      <div class="flex flex-wrap items-center gap-2 mb-4">
        <div class="seg"><button v-for="p in (['day', 'week', 'month'] as const)" :key="p" :class="{ on: period === p }" @click="period = p">{{ p === 'day' ? 'Daily' : p === 'week' ? 'Weekly' : 'Monthly' }}</button></div>
        <button class="btn btn-secondary btn-sm" aria-label="Previous period" @click="shift(-1)">‹</button>
        <span class="text-[13.5px] font-medium min-w-[150px] text-center">{{ range.label }}</span>
        <button class="btn btn-secondary btn-sm" aria-label="Next period" :disabled="range.to >= today" @click="shift(1)">›</button>
        <button v-if="anchor !== today" class="btn btn-ghost btn-sm" @click="anchor = today">Today</button>
      </div>
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <StatTile label="Attendance rate" :value="c.total ? pct(attendanceRate(recs)) : '—'" :tone="c.total && attendanceRate(recs) < store.db.settings.lowAttendanceThreshold ? 'bad' : 'ok'" :hint="`${c.total} student-lessons`" />
        <StatTile label="Present" :value="c.present" />
        <StatTile label="Late / absent" :value="`${c.late} / ${c.absent}`" />
        <StatTile label="Registers taken" :value="`${expectedRegisters.done} / ${expectedRegisters.n}`" :tone="expectedRegisters.done < expectedRegisters.n ? 'warn' : 'ok'" hint="Lessons so far in this period" />
      </div>
      <div class="grid lg:grid-cols-2 gap-4">
        <section v-if="period === 'day'" class="card lg:col-span-2">
          <h2 class="h-section px-4 sm:px-5 pt-4 pb-2">Lessons on {{ fmtDate(anchor) }}</h2>
          <div class="table-wrap"><table class="tbl">
            <thead><tr><th>Time</th><th>Lesson</th><th>Tutor</th><th>Register</th><th></th></tr></thead>
            <tbody><tr v-for="l in dayLessons" :key="l.id">
              <td class="tnum">{{ l.start }}</td><td>{{ store.subjectName(l.subjectId) }} · {{ store.className(l.classId) }}</td><td>{{ store.tutorName(l.tutorId) }}</td>
              <td><span v-if="store.registerFor(l.id, anchor).length" class="badge badge-ok">{{ attendanceCounts(store.registerFor(l.id, anchor)).present + attendanceCounts(store.registerFor(l.id, anchor)).late }}/{{ store.registerFor(l.id, anchor).length }} attended</span><span v-else class="badge badge-mute">Not taken</span></td>
              <td class="text-right"><button class="btn btn-ghost btn-sm" :disabled="anchor > today" @click="classId = l.classId; lessonId = l.id; date = anchor; tab = 'register'">Open register</button></td>
            </tr></tbody>
          </table></div>
          <EmptyState v-if="!dayLessons.length" compact title="No lessons on this day" />
        </section>
        <section class="card">
          <h2 class="h-section px-4 sm:px-5 pt-4 pb-2">By class</h2>
          <div class="table-wrap"><table class="tbl">
            <thead><tr><th>Class</th><th>Rate</th><th>Late</th><th>Absent</th></tr></thead>
            <tbody><tr v-for="x in byClass" :key="x.cl.id"><td>{{ x.cl.name }}</td><td class="tnum font-medium">{{ x.total ? pct(x.rate) : '—' }}</td><td class="tnum">{{ x.late }}</td><td class="tnum">{{ x.absent }}</td></tr></tbody>
          </table></div>
        </section>
        <section class="card">
          <h2 class="h-section px-4 sm:px-5 pt-4">Students, lowest attendance first</h2>
          <p class="sub px-4 sm:px-5 pb-2">Highlighted below {{ store.db.settings.lowAttendanceThreshold }}%</p>
          <div class="table-wrap max-h-[420px] overflow-y-auto"><table class="tbl">
            <thead><tr><th>Student</th><th>Rate</th><th>Absent</th></tr></thead>
            <tbody><tr v-for="x in byStudent" :key="x.s.id">
              <td><RouterLink :to="`/students/${x.s.id}`" class="hover:underline">{{ x.s.firstName }} {{ x.s.lastName }}</RouterLink><div class="text-[12px] text-muted">{{ store.className(x.s.classId) }}</div></td>
              <td><span :class="['badge tnum', x.rate < store.db.settings.lowAttendanceThreshold ? 'badge-bad' : 'badge-ok']">{{ pct(x.rate) }}</span></td>
              <td class="tnum">{{ x.absent }} of {{ x.total }}</td>
            </tr></tbody>
          </table></div>
          <EmptyState v-if="!byStudent.length" compact title="No registers in this period" />
        </section>
      </div>
    </div>
  </div>
</template>
