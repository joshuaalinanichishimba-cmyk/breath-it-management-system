<script setup lang="ts">
import { computed } from 'vue'
import { useDb } from '@/stores/db'
const props = withDefaults(defineProps<{ size?: number; withText?: boolean; sub?: string; onBrand?: boolean }>(), { size: 30, withText: true, sub: 'Tuition Centre', onBrand: false })
const store = useDb()
const logo = computed(() => store.db.settings.brand.logoDataUrl)
</script>
<template>
  <div class="flex items-center gap-2.5 select-none">
    <span v-if="logo" :class="['rounded-lg overflow-hidden flex items-center justify-center shrink-0', onBrand ? 'bg-white p-1' : '']" :style="{ width: props.size + 'px', height: props.size + 'px' }">
      <img :src="logo" alt="" class="max-w-full max-h-full object-contain" />
    </span>
    <svg v-else :width="size" :height="size" viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="8" :class="onBrand ? 'fill-brand-ink' : 'fill-brand'" />
      <path d="M8.5 20.5c3.2-6.4 11.8-6.4 15 0" :class="onBrand ? 'stroke-brand' : 'stroke-brand-ink'" stroke-width="2.4" fill="none" stroke-linecap="round" />
      <path d="M12 15c2.2-3.2 5.8-3.2 8 0" :class="onBrand ? 'stroke-brand' : 'stroke-brand-ink'" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".75" />
      <circle cx="16" cy="23.6" r="1.6" :class="onBrand ? 'fill-brand' : 'fill-brand-ink'" />
    </svg>
    <div v-if="withText" class="leading-none">
      <div :class="['text-[16px] font-semibold tracking-[-0.01em]', onBrand ? 'text-brand-ink' : 'text-ink']">Breath It</div>
      <div :class="['text-[11.5px] mt-0.5', onBrand ? 'text-brand-ink/75' : 'text-muted']">{{ sub }}</div>
    </div>
  </div>
</template>
