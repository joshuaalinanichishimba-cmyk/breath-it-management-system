import csv, io
from datetime import date, timedelta
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ...db import get_db
from ...deps import require_roles
from ...models import (Assessment, AttendanceRecord, Charge, ClassGroup, ExaminationResult, Payment, Student, TimetableSlot, Tutor, User,
                       CentreSetting)
from ...services import finance as fin

router = APIRouter(tags=["reports"])
admin_only = require_roles("admin")


@router.get("/dashboard/summary")
def dashboard(user: User = Depends(admin_only), db: Session = Depends(get_db)):
    today = date.today()
    term = (db.get(CentreSetting, "centre") or CentreSetting(value={})).value.get("current_term")
    count = lambda q: db.scalar(select(func.count()).select_from(q.subquery())) or 0  # noqa: E731
    collected = db.scalar(select(func.coalesce(func.sum(Payment.amount), 0)).where(Payment.status == "verified", Payment.term == term)) or 0
    billed_t = db.scalar(select(func.coalesce(func.sum(Charge.amount), 0)).where(Charge.term == term)) or 0
    outstanding = sum((max(Decimal(0), fin.balance(db, sid)) for sid in db.scalars(select(Student.id))), Decimal(0))
    today_recs = list(db.scalars(select(AttendanceRecord.status).where(AttendanceRecord.lesson_date == today)))
    months = []
    for i in range(10, -1, -1):
        first = (today.replace(day=1) - timedelta(days=31 * i)).replace(day=1)
        nxt = (first + timedelta(days=32)).replace(day=1)
        months.append({"month": first.strftime("%Y-%m"), "collected": db.scalar(select(func.coalesce(func.sum(Payment.amount), 0)).where(Payment.status == "verified", Payment.payment_date >= first, Payment.payment_date < nxt)) or 0})
    return {
        "current_term": term,
        "students_total": count(select(Student.id)), "students_active": count(select(Student.id).where(Student.status == "active")),
        "tutors_active": count(select(Tutor.id).where(Tutor.status == "active")), "classes_active": count(select(ClassGroup.id).where(ClassGroup.active.is_(True))),
        "collected_this_term": collected, "billed_this_term": billed_t, "outstanding": outstanding,
        "pending_verification": count(select(Payment.id).where(Payment.status == "pending")),
        "attendance_today": round(sum(s != "absent" for s in today_recs) / len(today_recs) * 100, 1) if today_recs else None,
        "lessons_today": count(select(TimetableSlot.id).where(TimetableSlot.day_of_week == today.isoweekday())),
        "revenue_by_month": months,
    }


def _csv(name: str, head: list[str], rows: list[list]) -> StreamingResponse:
    buf = io.StringIO(); buf.write("\ufeff")
    w = csv.writer(buf); w.writerow(head); w.writerows(rows)
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}.csv"'})


@router.get("/reports/{kind}")
def report(kind: str, date_from: date | None = None, date_to: date | None = None, fmt: str = "json", user: User = Depends(admin_only), db: Session = Depends(get_db)):
    d1, d2 = date_from or date(date.today().year, 1, 1), date_to or date.today()
    if kind == "enrolment":
        head = ["student_no", "name", "grade_id", "class_id", "status", "enrolment_date"]
        rows = [[s.student_no, s.full_name, s.grade_id, s.class_id, s.status, s.enrolment_date] for s in db.scalars(select(Student).where(Student.enrolment_date.between(d1, d2)).order_by(Student.enrolment_date))]
    elif kind == "collections":
        head = ["date", "reference", "receipt_no", "student_id", "category", "term", "method", "amount"]
        rows = [[p.payment_date, p.reference, p.receipt.receipt_no if p.receipt else "", p.student_id, p.category, p.term, p.method, p.amount]
                for p in db.scalars(select(Payment).where(Payment.status == "verified", Payment.payment_date.between(d1, d2)).order_by(Payment.payment_date))]
    elif kind == "balances":
        head = ["student_no", "name", "billed", "paid", "balance"]
        rows = [[s.student_no, s.full_name, fin.billed(db, s.id), fin.paid(db, s.id), fin.balance(db, s.id)] for s in db.scalars(select(Student)) if fin.balance(db, s.id) > 0]
    elif kind == "attendance":
        head = ["student_id", "present", "late", "absent"]
        agg: dict[str, list[int]] = {}
        for sid, st in db.execute(select(AttendanceRecord.student_id, AttendanceRecord.status).where(AttendanceRecord.lesson_date.between(d1, d2))):
            agg.setdefault(sid, [0, 0, 0])[["present", "late", "absent"].index(st)] += 1
        rows = [[k, *v] for k, v in agg.items()]
    elif kind == "results":
        head = ["date", "student_id", "subject_id", "title", "marks", "max_marks", "percentage"]
        rows = [[r.assessment.assessment_date, r.student_id, r.assessment.subject_id, r.assessment.title, r.marks, r.assessment.max_marks, r.percentage]
                for r in db.scalars(select(ExaminationResult).join(Assessment).where(Assessment.assessment_date.between(d1, d2)))]
    elif kind == "tutors":
        head = ["staff_no", "name", "lessons_per_week", "registers_taken", "marks_entered"]
        rows = []
        for t in db.scalars(select(Tutor)):
            slots = list(db.scalars(select(TimetableSlot.id).where(TimetableSlot.tutor_id == t.id)))
            regs = len(set(db.execute(select(AttendanceRecord.slot_id, AttendanceRecord.lesson_date).where(AttendanceRecord.slot_id.in_(slots or ['']), AttendanceRecord.lesson_date.between(d1, d2))).all()))
            marks = db.scalar(select(func.count()).select_from(ExaminationResult).join(Assessment).where(Assessment.tutor_id == t.id, Assessment.assessment_date.between(d1, d2))) or 0
            rows.append([t.staff_no, f"{t.first_name} {t.last_name}", len(slots), regs, marks])
    else:
        raise HTTPException(404, "Unknown report. Use enrolment, collections, balances, attendance, results or tutors.")
    if fmt == "csv":
        return _csv(f"{kind}-report-{d2}", head, rows)
    return {"columns": head, "rows": rows, "from": d1, "to": d2}
