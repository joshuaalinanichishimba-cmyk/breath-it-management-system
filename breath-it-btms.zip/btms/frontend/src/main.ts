import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import { router } from './router'
import './style.css'
import { useUi } from './stores/ui'

const app = createApp(App)
app.use(createPinia())
app.use(router)
app.config.errorHandler = (err) => {
  console.error(err)
  useUi().error('Something went wrong', err instanceof Error ? err.message : String(err))
}
app.mount('#app')
