<script setup lang="ts">
import { methodLabel } from '@/services/payments'
import { computed } from 'vue'
import { Download } from 'lucide-vue-next'
import Modal from '@/components/ui/Modal.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import type { Payment } from '@/types'
import { fmtDate, fmtDateTime } from '@/services/dates'
import { kwacha } from '@/services/format'
import { receiptPdf } from '@/services/pdf'
import { saveFile } from '@/services/download'

const props = defineProps<{ payment: Payment | null }>()
const emit = defineEmits<{ close: [] }>()
const store = useDb(); const ui = useUi()
const s = computed(() => (props.payment ? store.studentMap.get(props.payment.studentId) : undefined))
const parent = computed(() => (s.value ? store.parentMap.get(s.value.parentId) : undefined))
async function download() {
  if (!props.payment) return
  try {
    const r = await saveFile(`${props.payment.receiptNo}.pdf`, receiptPdf(store.db, props.payment), 'application/pdf')
    if (r === 'saved') ui.success('Receipt downloaded', `${props.payment.receiptNo}.pdf`)
  } catch (e) { ui.error('Could not download the receipt', (e as Error).message) }
}
</script>
<template>
  <Modal :open="!!payment" title="Payment receipt" :sub="payment?.receiptNo" @close="emit('close')">
    <div v-if="payment && s" class="rounded-lg border border-line overflow-hidden">
      <div class="px-4 py-3 bg-sunken/60 flex justify-between items-start gap-3">
        <div>
          <div class="font-semibold">{{ store.db.settings.centreName }}</div>
          <div class="text-[12px] text-muted">{{ store.db.settings.address }} · {{ store.db.settings.phone }}</div>
        </div>
        <span class="badge badge-ok">Verified</span>
      </div>
      <dl class="grid grid-cols-[130px_1fr] gap-y-2 px-4 py-3 text-[13px]">
        <dt class="text-muted">Receipt no.</dt><dd class="tnum">{{ payment.receiptNo }}</dd>
        <dt class="text-muted">Date</dt><dd>{{ fmtDate(payment.date) }}</dd>
        <dt class="text-muted">Received from</dt><dd>{{ parent?.name }} ({{ parent?.relationship }})</dd>
        <dt class="text-muted">Student</dt><dd>{{ s.firstName }} {{ s.lastName }} · <span class="tnum">{{ s.studentNo }}</span></dd>
        <dt class="text-muted">For</dt><dd>{{ payment.category }} · {{ payment.term }}</dd>
        <dt class="text-muted">Method</dt><dd>{{ methodLabel(payment) }}<span v-if="payment.payerPhone" class="text-muted tnum"> · {{ payment.payerPhone }}</span><span v-if="payment.externalRef || payment.gatewayRef" class="text-muted"> · ref {{ payment.externalRef ?? payment.gatewayRef }}</span></dd>
      </dl>
      <div class="grid grid-cols-2 border-t border-line">
        <div class="px-4 py-3"><div class="text-[12px] text-muted">Amount received</div><div class="text-[20px] font-semibold tnum">{{ kwacha(payment.amount, { decimals: true }) }}</div></div>
        <div class="px-4 py-3 border-l border-line"><div class="text-[12px] text-muted">Balance after payment</div><div class="text-[20px] font-semibold tnum">{{ kwacha(payment.balanceAfter, { decimals: true }) }}</div></div>
      </div>
      <div class="px-4 py-2.5 border-t border-line text-[12px] text-muted">{{ payment.channel === 'online' ? 'Paid online' : 'Recorded by ' + payment.recordedBy }} · {{ payment.verifiedBy === 'Payment gateway' ? 'confirmed by the payment provider' : 'verified by ' + payment.verifiedBy }} on {{ fmtDateTime(payment.verifiedAt) }}</div>
    </div>
    <template #footer>
      <button class="btn btn-secondary" @click="emit('close')">Close</button>
      <button class="btn btn-primary" @click="download"><Download :size="15" />Download PDF</button>
    </template>
  </Modal>
</template>
