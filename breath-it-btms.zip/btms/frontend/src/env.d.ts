/// <reference types="vite/client" />
declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  const component: DefineComponent<object, object, unknown>
  export default component
}
interface ImportMetaEnv {
  readonly VITE_DEMO_MODE?: string
  readonly VITE_API_URL?: string
  readonly VITE_ROUTER_MODE?: 'hash' | 'memory' | 'history'
}
