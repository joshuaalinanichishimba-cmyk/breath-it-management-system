<script setup lang="ts">
import { ChevronLeft, ChevronRight } from 'lucide-vue-next'
const page = defineModel<number>({ required: true })
defineProps<{ pages: number; range: string }>()
</script>
<template>
  <div class="flex items-center justify-between px-4 py-2.5 border-t border-line text-[12.5px] text-muted">
    <span class="tnum">{{ range }}</span>
    <div class="flex items-center gap-1">
      <button class="icon-btn" :disabled="page <= 1" aria-label="Previous page" @click="page--"><ChevronLeft :size="16" /></button>
      <span class="tnum px-1">{{ page }} / {{ pages }}</span>
      <button class="icon-btn" :disabled="page >= pages" aria-label="Next page" @click="page++"><ChevronRight :size="16" /></button>
    </div>
  </div>
</template>
