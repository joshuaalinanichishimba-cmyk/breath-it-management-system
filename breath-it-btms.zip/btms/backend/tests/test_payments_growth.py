import json
from app.services.payment_gateway import sign

API = "/api/v1"


def _webhook(client, ref, status="confirmed", amount=None, sig=None):
    body = json.dumps({"gateway_ref": ref, "status": status, **({"amount": str(amount)} if amount is not None else {})}).encode()
    return client.post(f"{API}/finance/gateway/webhook", content=body, headers={"X-Signature": sig or sign(body), "Content-Type": "application/json"})


def _balance(client, headers, sid="s02"):
    return float(client.get(f"{API}/students/{sid}/statement", headers=headers).json()["balance"])


def test_parent_pays_with_mobile_money_and_gateway_confirms(client, parent):
    before = _balance(client, parent)
    r = client.post(f"{API}/finance/pay", json={"student_id": "s02", "amount": "100", "method": "Mobile Money", "network": "Airtel", "phone": "0977 112 408"}, headers=parent)
    assert r.status_code == 201, r.text
    p = r.json()["payment"]
    assert p["status"] == "pending" and p["channel"] == "online" and p["gateway_status"] == "awaiting_customer"
    assert _balance(client, parent) == before                                   # nothing counts until the gateway confirms
    assert _webhook(client, p["gateway_ref"], sig="forged").status_code == 401   # unsigned callbacks rejected
    ok = _webhook(client, p["gateway_ref"], amount=100)
    assert ok.status_code == 200 and ok.json()["status"] == "verified"
    assert _balance(client, parent) == before - 100
    assert _webhook(client, p["gateway_ref"]).json()["duplicate"] is True        # idempotent
    st = client.get(f"{API}/finance/payments/{p['id']}/status", headers=parent).json()
    assert st["receipt_no"].startswith("RCT-") and st["verified_by"] == "Payment gateway"


def test_wrong_network_and_other_peoples_children_are_rejected(client, parent):
    r = client.post(f"{API}/finance/pay", json={"student_id": "s02", "amount": "50", "method": "Mobile Money", "network": "MTN", "phone": "0977 112 408"}, headers=parent)
    assert r.status_code == 422
    r = client.post(f"{API}/finance/pay", json={"student_id": "s03", "amount": "50", "method": "Mobile Money", "network": "Airtel", "phone": "0977 112 408"}, headers=parent)
    assert r.status_code == 404


def test_declined_payment_changes_nothing(client, parent):
    before = _balance(client, parent)
    p = client.post(f"{API}/finance/pay", json={"student_id": "s02", "amount": "60", "method": "Mobile Money", "network": "Airtel", "phone": "0977112408"}, headers=parent).json()["payment"]
    assert _webhook(client, p["gateway_ref"], status="declined").json()["status"] == "rejected"
    assert _balance(client, parent) == before


def test_amount_mismatch_is_not_verified(client, parent):
    p = client.post(f"{API}/finance/pay", json={"student_id": "s02", "amount": "70", "method": "Card"}, headers=parent).json()
    assert p["checkout_url"]
    assert _webhook(client, p["payment"]["gateway_ref"], amount=7).status_code == 409


def test_tutor_cannot_pay_and_bank_transfer_waits_for_office(client, tutor, parent, admin):
    assert client.post(f"{API}/finance/pay", json={"student_id": "s02", "amount": "10", "method": "Card"}, headers=tutor).status_code == 403
    r = client.post(f"{API}/finance/bank-transfer", json={"student_id": "s01", "amount": "100", "reference": "FT-TEST-1", "payment_date": "2026-11-10"}, headers=parent)
    assert r.status_code == 201 and r.json()["status"] == "pending"
    assert client.post(f"{API}/finance/bank-transfer", json={"student_id": "s01", "amount": "100", "reference": "ft-test-1", "payment_date": "2026-11-10"}, headers=parent).status_code == 409


def test_public_enquiry_with_referral_and_reward(client, admin):
    code = client.get(f"{API}/parents/me/referral", headers=_login(client, "parent@breathit.demo")).json()["code"]
    assert client.post(f"{API}/enquiries", json={"parent_name": "New Parent", "phone": "0966 555 444", "child_name": "New Child", "grade_id": "g8", "referral_code": code}).status_code == 202
    lead = next(l for l in client.get(f"{API}/leads", headers=admin).json() if l["child_name"] == "New Child")
    assert lead["source"] == "Referral" and lead["referred_by_parent_id"] == "p01"
    assert client.patch(f"{API}/leads/{lead['id']}", json={"stage": "enrolled"}, headers=admin).status_code == 422   # must register first
    assert client.patch(f"{API}/leads/{lead['id']}", json={"stage": "enrolled", "student_id": "s12"}, headers=admin).status_code == 200
    before = sum(float(c["amount"]) for c in client.get(f"{API}/students/s01/statement", headers=admin).json()["charges"])
    assert client.post(f"{API}/leads/{lead['id']}/reward", headers=admin).status_code == 200
    after = sum(float(c["amount"]) for c in client.get(f"{API}/students/s01/statement", headers=admin).json()["charges"])
    assert after == before - 100
    assert client.post(f"{API}/leads/{lead['id']}/reward", headers=admin).status_code == 409                       # only once


def test_enquiry_honeypot_and_rate_limit(client, admin):
    n = len(client.get(f"{API}/leads", headers=admin).json())
    client.post(f"{API}/enquiries", json={"parent_name": "Bot", "phone": "0966 555 444", "child_name": "Bot", "grade_id": "g8", "website": "spam"})
    assert len(client.get(f"{API}/leads", headers=admin).json()) == n
    codes = [client.post(f"{API}/enquiries", json={"parent_name": "Many", "phone": "0966 555 444", "child_name": f"Kid {i}", "grade_id": "g8"}).status_code for i in range(6)]
    assert 429 in codes


def _login(client, email):
    r = client.post(f"{API}/auth/login", data={"username": email, "password": "demo1234"})
    return {"Authorization": f"Bearer {r.json()['access_token']}"}
