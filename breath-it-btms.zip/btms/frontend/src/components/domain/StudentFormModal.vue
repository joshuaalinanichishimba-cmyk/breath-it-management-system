<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import Modal from '@/components/ui/Modal.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import type { Parent, Student, StudentStatus } from '@/types'
import { iso } from '@/services/dates'

const props = defineProps<{ open: boolean; student?: Student | null; prefill?: { firstName?: string; lastName?: string; gradeId?: string; subjectIds?: string[]; parentName?: string; parentPhone?: string } | null }>()
const emit = defineEmits<{ close: []; saved: [s: Student] }>()
const store = useDb(); const ui = useUi()

const blank = () => ({
  firstName: '', lastName: '', dob: '', gender: 'Female' as Student['gender'], gradeId: store.db.grades[0]?.id ?? '', classId: '',
  parentMode: 'existing' as 'existing' | 'new', parentId: '', parentName: '', parentPhone: '', parentRelationship: 'Mother' as Parent['relationship'],
  altContact: '', address: '', enrolmentDate: iso(), subjectIds: [] as string[], status: 'active' as StudentStatus, chargeRegistration: true, notes: '',
})
const f = reactive(blank())
const errors = ref<Record<string, string>>({})
const editing = computed(() => !!props.student)

watch(() => props.open, (o) => {
  if (!o) return
  errors.value = {}
  Object.assign(f, blank())
  if (!props.student && props.prefill) {
    const p = props.prefill
    Object.assign(f, { firstName: p.firstName ?? '', lastName: p.lastName ?? '', gradeId: p.gradeId ?? f.gradeId })
    if (p.parentName) Object.assign(f, { parentMode: 'new', parentName: p.parentName, parentPhone: p.parentPhone ?? '' })
    setTimeout(() => { f.subjectIds = [...(p.subjectIds ?? [])] }, 0)
  }
  if (props.student) {
    const s = props.student
    Object.assign(f, { firstName: s.firstName, lastName: s.lastName, dob: s.dob, gender: s.gender, gradeId: s.gradeId, classId: s.classId, parentId: s.parentId,
      altContact: s.altContact ?? '', address: s.address, enrolmentDate: s.enrolmentDate, subjectIds: [...s.subjectIds], status: s.status, notes: s.notes ?? '' })
  }
})
const gradeClasses = computed(() => store.db.classes.filter((c) => c.gradeId === f.gradeId && c.active))
const gradeSubjects = computed(() => store.db.subjects.filter((s) => s.gradeIds.includes(f.gradeId) && s.active))
watch(() => f.gradeId, (g, old) => {
  if (!g) return
  if (!gradeClasses.value.some((c) => c.id === f.classId)) f.classId = gradeClasses.value[0]?.id ?? ''
  if (old && old !== g) f.subjectIds = f.subjectIds.filter((id) => gradeSubjects.value.some((s) => s.id === id))
})
const classLoad = computed(() => {
  const c = store.classMap.get(f.classId)
  if (!c) return null
  const n = store.db.students.filter((s) => s.classId === c.id && s.status === 'active' && s.id !== props.student?.id).length
  return { n, cap: c.capacity }
})
const phoneOk = (p: string) => /^(\+?260|0)[79]\d{8}$/.test(p.replace(/[\s-]/g, ''))

function validate() {
  const e: Record<string, string> = {}
  if (!f.firstName.trim()) e.firstName = 'Required'
  if (!f.lastName.trim()) e.lastName = 'Required'
  if (!f.dob) e.dob = 'Required'; else if (f.dob >= iso()) e.dob = 'Must be in the past'
  if (!f.classId) e.classId = 'Create a class for this grade first'
  if (!f.subjectIds.length) e.subjectIds = 'Choose at least one subject'
  if (!f.address.trim()) e.address = 'Required'
  if (f.altContact && !phoneOk(f.altContact)) e.altContact = 'Use a Zambian number, e.g. 0977 123 456'
  if (!editing.value) {
    if (f.parentMode === 'existing' && !f.parentId) e.parentId = 'Choose a parent or add a new one'
    if (f.parentMode === 'new') {
      if (!f.parentName.trim()) e.parentName = 'Required'
      if (!phoneOk(f.parentPhone)) e.parentPhone = 'Use a Zambian number, e.g. 0977 123 456'
    }
  }
  errors.value = e
  return !Object.keys(e).length
}
function save() {
  if (!validate()) return
  const base = { firstName: f.firstName.trim(), lastName: f.lastName.trim(), dob: f.dob, gender: f.gender, gradeId: f.gradeId, classId: f.classId,
    altContact: f.altContact.trim() || undefined, address: f.address.trim(), enrolmentDate: f.enrolmentDate, subjectIds: f.subjectIds, status: f.status, notes: f.notes.trim() || undefined }
  if (editing.value && props.student) {
    store.updateStudent(props.student.id, base)
    ui.success('Student updated', `${base.firstName} ${base.lastName}`)
    emit('saved', props.student)
  } else {
    let parentId = f.parentId
    if (f.parentMode === 'new') parentId = store.addParent({ name: f.parentName.trim(), phone: f.parentPhone.trim(), relationship: f.parentRelationship, address: f.address.trim(), portalAccess: true }).id
    const s = store.addStudent({ ...base, parentId }, { chargeRegistration: f.chargeRegistration })
    ui.success('Student registered', `${s.firstName} ${s.lastName} · ${s.studentNo}`)
    emit('saved', s)
  }
  emit('close')
}
</script>
<template>
  <Modal :open="open" :title="editing ? 'Edit student' : 'Register a student'" :sub="editing ? student?.studentNo : 'A student number is assigned automatically.'" size="xl" @close="emit('close')">
    <form class="grid gap-6" @submit.prevent="save">
      <section class="grid sm:grid-cols-3 gap-4">
        <h3 class="sm:col-span-3 h-section">Personal details</h3>
        <div><label class="label" for="sf-fn">First name</label><input id="sf-fn" v-model="f.firstName" class="input" /><p v-if="errors.firstName" class="field-error">{{ errors.firstName }}</p></div>
        <div><label class="label" for="sf-ln">Last name</label><input id="sf-ln" v-model="f.lastName" class="input" /><p v-if="errors.lastName" class="field-error">{{ errors.lastName }}</p></div>
        <div><label class="label" for="sf-dob">Date of birth</label><input id="sf-dob" v-model="f.dob" type="date" class="input" :max="iso()" /><p v-if="errors.dob" class="field-error">{{ errors.dob }}</p></div>
        <div><label class="label" for="sf-g">Gender</label><select id="sf-g" v-model="f.gender" class="select"><option>Female</option><option>Male</option></select></div>
        <div class="sm:col-span-2"><label class="label" for="sf-addr">Address</label><input id="sf-addr" v-model="f.address" class="input" placeholder="e.g. House 14, Kaunda Square Stage 2" /><p v-if="errors.address" class="field-error">{{ errors.address }}</p></div>
      </section>

      <section class="grid sm:grid-cols-3 gap-4">
        <h3 class="sm:col-span-3 h-section">Academic details</h3>
        <div><label class="label" for="sf-gr">Grade</label><select id="sf-gr" v-model="f.gradeId" class="select"><option v-for="g in store.db.grades.filter((x) => x.active)" :key="g.id" :value="g.id">{{ g.name }}</option></select></div>
        <div><label class="label" for="sf-cl">Class</label>
          <select id="sf-cl" v-model="f.classId" class="select"><option v-for="c in gradeClasses" :key="c.id" :value="c.id">{{ c.name }}</option></select>
          <p v-if="errors.classId" class="field-error">{{ errors.classId }}</p>
          <p v-else-if="classLoad" :class="['text-[12px] mt-1', classLoad.n >= classLoad.cap ? 'text-warn' : 'text-muted']">{{ classLoad.n }} of {{ classLoad.cap }} places taken{{ classLoad.n >= classLoad.cap ? ' — class is full' : '' }}</p>
        </div>
        <div><label class="label" for="sf-en">Enrolment date</label><input id="sf-en" v-model="f.enrolmentDate" type="date" class="input" /></div>
        <div class="sm:col-span-3">
          <span class="label">Subjects</span>
          <div class="flex flex-wrap gap-2">
            <label v-for="s in gradeSubjects" :key="s.id" :class="['flex items-center gap-2 h-8 px-3 rounded-full border text-[13px] cursor-pointer', f.subjectIds.includes(s.id) ? 'border-brand bg-brand-soft' : 'border-line']">
              <input v-model="f.subjectIds" type="checkbox" :value="s.id" class="sr-only" />{{ s.name }}
            </label>
          </div>
          <p v-if="errors.subjectIds" class="field-error">{{ errors.subjectIds }}</p>
        </div>
        <div v-if="editing"><label class="label" for="sf-st">Registration status</label>
          <select id="sf-st" v-model="f.status" class="select"><option value="active">Active</option><option value="inactive">Inactive</option><option value="suspended">Suspended</option><option value="completed">Completed</option></select></div>
      </section>

      <section class="grid sm:grid-cols-3 gap-4">
        <h3 class="sm:col-span-3 h-section">Parent or guardian</h3>
        <template v-if="!editing">
          <div class="sm:col-span-3 seg w-fit">
            <button type="button" :class="{ on: f.parentMode === 'existing' }" @click="f.parentMode = 'existing'">Existing parent</button>
            <button type="button" :class="{ on: f.parentMode === 'new' }" @click="f.parentMode = 'new'">New parent</button>
          </div>
          <div v-if="f.parentMode === 'existing'" class="sm:col-span-2"><label class="label" for="sf-par">Parent</label>
            <select id="sf-par" v-model="f.parentId" class="select"><option value="" disabled>Choose…</option><option v-for="p in [...store.db.parents].sort((a, b) => a.name.localeCompare(b.name))" :key="p.id" :value="p.id">{{ p.name }} · {{ p.phone }}</option></select>
            <p v-if="errors.parentId" class="field-error">{{ errors.parentId }}</p></div>
          <template v-else>
            <div><label class="label" for="sf-pn">Full name</label><input id="sf-pn" v-model="f.parentName" class="input" /><p v-if="errors.parentName" class="field-error">{{ errors.parentName }}</p></div>
            <div><label class="label" for="sf-pp">Phone</label><input id="sf-pp" v-model="f.parentPhone" class="input" placeholder="0977 123 456" /><p v-if="errors.parentPhone" class="field-error">{{ errors.parentPhone }}</p></div>
            <div><label class="label" for="sf-pr">Relationship</label><select id="sf-pr" v-model="f.parentRelationship" class="select"><option>Mother</option><option>Father</option><option>Guardian</option><option>Aunt</option><option>Uncle</option><option>Grandparent</option></select></div>
          </template>
        </template>
        <div v-else class="sm:col-span-2 text-[13px] text-muted">Linked to {{ store.parentMap.get(student!.parentId)?.name }} — change parent details from the Parents page.</div>
        <div><label class="label" for="sf-alt">Alternative contact</label><input id="sf-alt" v-model="f.altContact" class="input" placeholder="Optional" /><p v-if="errors.altContact" class="field-error">{{ errors.altContact }}</p></div>
      </section>

      <label v-if="!editing" class="flex items-center gap-2.5 text-[13px]"><input v-model="f.chargeRegistration" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />Add the registration fee and this term’s tuition to the student’s account</label>
      <button type="submit" class="hidden" />
    </form>
    <template #footer>
      <button class="btn btn-secondary" @click="emit('close')">Cancel</button>
      <button class="btn btn-primary" @click="save">{{ editing ? 'Save changes' : 'Register student' }}</button>
    </template>
  </Modal>
</template>
