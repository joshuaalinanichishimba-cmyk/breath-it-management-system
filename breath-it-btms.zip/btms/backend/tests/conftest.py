import json, os, sys, tempfile
import pytest

_db = os.path.join(tempfile.mkdtemp(), "btms_test.db")
os.environ["DATABASE_URL"] = f"sqlite:///{_db}"
os.environ["JWT_SECRET"] = "test-secret-" + "x" * 40
os.environ["PAYMENT_GATEWAY"] = "sandbox"
os.environ["PAYMENT_WEBHOOK_SECRET"] = "whsec-test"
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi.testclient import TestClient  # noqa: E402
from app.db import Base, engine, SessionLocal  # noqa: E402
from app.main import app  # noqa: E402
from app.seed import SEED_FILE, load_demo  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def database():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        load_demo(db, json.loads(SEED_FILE.read_text(encoding="utf-8-sig")))
        db.commit()
    yield


@pytest.fixture(scope="session")
def client():
    return TestClient(app)


def _login(client, email):
    r = client.post("/api/v1/auth/login", data={"username": email, "password": "demo1234"})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="session")
def admin(client): return _login(client, "admin@breathit.demo")
@pytest.fixture(scope="session")
def tutor(client): return _login(client, "tutor@breathit.demo")
@pytest.fixture(scope="session")
def student(client): return _login(client, "student@breathit.demo")
@pytest.fixture(scope="session")
def parent(client): return _login(client, "parent@breathit.demo")
