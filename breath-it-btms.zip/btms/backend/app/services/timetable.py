from datetime import time
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import ClassGroup, Subject, TimetableSlot, Tutor

DAYS = ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def conflicts(db: Session, *, class_id: str, tutor_id: str, room: str, day: int, start: time, end: time, ignore_id: str | None = None) -> list[str]:
    out: list[str] = []
    if end <= start:
        return ["End time must be after the start time."]
    q = select(TimetableSlot).where(TimetableSlot.day_of_week == day, TimetableSlot.start_time < end, TimetableSlot.end_time > start)
    if ignore_id:
        q = q.where(TimetableSlot.id != ignore_id)
    for s in db.scalars(q):
        when = f"{DAYS[s.day_of_week]} {s.start_time:%H:%M}–{s.end_time:%H:%M}"
        cls = db.get(ClassGroup, s.class_id); subj = db.get(Subject, s.subject_id)
        if s.tutor_id == tutor_id:
            t = db.get(Tutor, tutor_id)
            out.append(f"{t.first_name} {t.last_name} already teaches {subj.name} ({cls.name}) on {when}.")
        if s.room == room:
            out.append(f"{room} is already booked for {cls.name} on {when}.")
        if s.class_id == class_id:
            out.append(f"{cls.name} already has {subj.name} on {when}.")
    return list(dict.fromkeys(out))
