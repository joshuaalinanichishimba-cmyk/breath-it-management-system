<script setup lang="ts">
import { Inbox } from 'lucide-vue-next'
defineProps<{ title: string; body?: string; compact?: boolean }>()
</script>
<template>
  <div :class="['flex flex-col items-center text-center', compact ? 'py-8 px-4' : 'py-14 px-6']">
    <div class="h-10 w-10 rounded-full bg-sunken flex items-center justify-center text-faint"><Inbox :size="19" /></div>
    <div class="mt-3 font-medium">{{ title }}</div>
    <p v-if="body" class="sub mt-1 max-w-sm">{{ body }}</p>
    <div v-if="$slots.default" class="mt-4"><slot /></div>
  </div>
</template>
