<script setup lang="ts">
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-vue-next'
import { useUi } from '@/stores/ui'
const ui = useUi()
const icon = { success: CheckCircle2, error: AlertCircle, info: Info }
const tone = { success: 'text-ok', error: 'text-bad', info: 'text-info' }
</script>
<template>
  <div class="fixed z-[60] right-3 left-3 sm:left-auto sm:right-5 sm:w-[360px] flex flex-col gap-2" style="bottom: calc(env(safe-area-inset-bottom, 0px) + 16px)" aria-live="polite">
    <TransitionGroup enter-from-class="opacity-0 translate-y-2" enter-active-class="transition duration-200" leave-active-class="transition duration-150" leave-to-class="opacity-0">
      <div v-for="t in ui.toasts" :key="t.id" class="card shadow-lg px-3.5 py-3 flex gap-2.5 items-start">
        <component :is="icon[t.kind]" :size="18" :class="['mt-0.5 shrink-0', tone[t.kind]]" />
        <div class="flex-1 min-w-0">
          <div class="text-[13.5px] font-medium">{{ t.title }}</div>
          <div v-if="t.body" class="text-[12.5px] text-muted mt-0.5">{{ t.body }}</div>
        </div>
        <button class="icon-btn h-6 w-6 -mr-1" aria-label="Dismiss" @click="ui.dismiss(t.id)"><X :size="14" /></button>
      </div>
    </TransitionGroup>
  </div>
</template>
