<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink } from 'vue-router'
import type { ChartConfiguration } from 'chart.js'
import { ArrowRight, MessageCircle } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatTile from '@/components/ui/StatTile.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import ChartBox from '@/components/charts/ChartBox.vue'
import { tok } from '@/components/charts/palette'
import { useDb } from '@/stores/db'
import { iso, addDays } from '@/services/dates'
import { kwacha, pct } from '@/services/format'
import { attendanceRate, average, pctOf } from '@/services/analytics'
import { waLink } from '@/services/whatsapp'

const store = useDb()
const d = computed(() => store.db)
const today = iso()
const term = computed(() => d.value.settings.currentTerm)
const terms = computed(() => d.value.settings.terms.map((t) => t.name))
const prevTerm = computed(() => terms.value[terms.value.indexOf(term.value) - 1])
const active = computed(() => d.value.students.filter((s) => s.status === 'active'))
const tuition = (g: string) => d.value.feeStructures.find((f) => f.gradeId === g && f.category === 'Tuition')?.amount ?? 0

// retention: students billed last term who are still with us
const lastTermStudents = computed(() => (prevTerm.value ? [...new Set(d.value.charges.filter((c) => c.term === prevTerm.value && c.category === 'Tuition').map((c) => c.studentId))] : []))
const returned = computed(() => lastTermStudents.value.filter((id) => store.studentMap.get(id)?.status === 'active'))
const leavers = computed(() => lastTermStudents.value.filter((id) => store.studentMap.get(id)?.status !== 'active').map((id) => store.studentMap.get(id)!))
const retention = computed(() => (lastTermStudents.value.length ? (returned.value.length / lastTermStudents.value.length) * 100 : NaN))

// seats
const seats = computed(() => d.value.classes.filter((c) => c.active).map((c) => {
  const filled = active.value.filter((s) => s.classId === c.id).length
  return { c, filled, empty: Math.max(0, c.capacity - filled), value: Math.max(0, c.capacity - filled) * tuition(c.gradeId) }
}))
const capacity = computed(() => seats.value.reduce((a, x) => a + x.c.capacity, 0))
const emptyValue = computed(() => seats.value.reduce((a, x) => a + x.value, 0))

// money
const billedT = (t: string) => d.value.charges.filter((c) => c.term === t).reduce((a, c) => a + c.amount, 0)
const collectedT = (t: string) => d.value.payments.filter((p) => p.term === t && p.status === 'verified').reduce((a, p) => a + p.amount, 0)
const collection = computed(() => (billedT(term.value) ? (collectedT(term.value) / billedT(term.value)) * 100 : NaN))
const onlineShare = computed(() => {
  const v = d.value.payments.filter((p) => p.status === 'verified' && p.term === term.value)
  return v.length ? (v.filter((p) => p.channel === 'online').length / v.length) * 100 : NaN
})

// at-risk learners (likely to drop out): low attendance, falling marks, or fees more than a term behind
const atRisk = computed(() => active.value.map((s) => {
  const reasons: string[] = []
  const att = d.value.attendance.filter((a) => a.studentId === s.id && a.date >= addDays(today, -28))
  const rate = attendanceRate(att)
  if (att.length >= 5 && rate < d.value.settings.lowAttendanceThreshold) reasons.push(`Attendance ${pct(rate)}`)
  const marks = d.value.assessments.filter((a) => a.studentId === s.id).sort((a, b) => a.date.localeCompare(b.date))
  const dates = [...new Set(marks.map((m) => m.date))]
  if (dates.length >= 3) {
    const recent = average(marks.filter((m) => dates.slice(-2).includes(m.date)).map(pctOf))
    const before = average(marks.filter((m) => dates.slice(-4, -2).includes(m.date)).map(pctOf))
    if (before - recent >= 6) reasons.push(`Marks down ${(before - recent).toFixed(0)} pts`)
  }
  const bal = store.balance(s.id)
  if (bal > tuition(s.gradeId)) reasons.push(`Owes ${kwacha(bal)}`)
  return { s, reasons }
}).filter((x) => x.reasons.length).sort((a, b) => b.reasons.length - a.reasons.length))

const leads = computed(() => d.value.leads)
const due = computed(() => leads.value.filter((l) => ['new', 'contacted', 'trial'].includes(l.stage) && (l.followUpOn ?? l.createdAt.slice(0, 10)) <= today))
const owingFamilies = computed(() => new Set(d.value.students.filter((s) => store.balance(s.id) > 0).map((s) => s.parentId)).size)
const rewardsPending = computed(() => leads.value.filter((l) => l.stage === 'enrolled' && l.referredByParentId && !l.rewardApplied).length)

const actions = computed(() => [
  { n: due.value.length, title: 'enquiries to follow up', body: 'Families waiting for a call back or a trial lesson. Each one is a new student.', to: '/admissions', cta: 'Open admissions' },
  { n: owingFamilies.value, title: 'families with a balance', body: 'Send a polite WhatsApp reminder with the amount and a link to pay by mobile money.', to: '/finance?tab=reminders', cta: 'Send reminders' },
  { n: atRisk.value.length, title: 'learners at risk of leaving', body: 'Low attendance, falling marks or fees behind. A call to the parent now protects next term’s enrolment.', to: '#at-risk', cta: 'See who' },
  { n: seats.value.reduce((a, x) => a + x.empty, 0), title: 'empty seats this term', body: `Worth ${kwacha(emptyValue.value)} in tuition per term if filled. Share the enquiry form and referral codes.`, to: '/admissions', cta: 'Fill seats' },
  { n: rewardsPending.value, title: 'referral rewards to apply', body: 'Thank families who sent you new students — it keeps referrals coming.', to: '/admissions', cta: 'Apply rewards' },
].filter((a) => a.n > 0))

const revenueCfg = computed<ChartConfiguration>(() => ({ type: 'bar', data: { labels: terms.value.map((t) => t.replace(' 2026', '')), datasets: [
  { label: 'Billed', data: terms.value.map(billedT), backgroundColor: tok('faint', 0.35), borderRadius: 4, maxBarThickness: 40 },
  { label: 'Collected', data: terms.value.map(collectedT), backgroundColor: tok('brand', 0.85), borderRadius: 4, maxBarThickness: 40 },
] }, options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } }, scales: { y: { beginAtZero: true, ticks: { callback: (v) => 'K' + Number(v).toLocaleString() } }, x: { grid: { display: false } } } } }))
const funnelCfg = computed<ChartConfiguration>(() => {
  const stages = [['Enquired', leads.value.length], ['Contacted', leads.value.filter((l) => ['contacted', 'trial', 'enrolled'].includes(l.stage)).length], ['Trial lesson', leads.value.filter((l) => ['trial', 'enrolled'].includes(l.stage)).length], ['Enrolled', leads.value.filter((l) => l.stage === 'enrolled').length]] as const
  return { type: 'bar', data: { labels: stages.map((s) => s[0]), datasets: [{ label: 'Families', data: stages.map((s) => s[1]), backgroundColor: [tok('brand', 0.35), tok('brand', 0.55), tok('brand', 0.75), tok('ok', 0.85)], borderRadius: 4, maxBarThickness: 34 }] },
    options: { indexAxis: 'y', plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } }, y: { grid: { display: false } } } } }
})
const seatsCfg = computed<ChartConfiguration>(() => ({ type: 'bar', data: { labels: seats.value.map((x) => x.c.name), datasets: [
  { label: 'Filled', data: seats.value.map((x) => x.filled), backgroundColor: tok('brand', 0.85), borderRadius: 3, maxBarThickness: 30 },
  { label: 'Empty', data: seats.value.map((x) => x.empty), backgroundColor: tok('warn', 0.35), borderRadius: 3, maxBarThickness: 30 },
] }, options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } }, scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } } } } }))
const demand = computed(() => d.value.subjects.map((s) => ({ s, n: active.value.filter((x) => x.subjectIds.includes(s.id)).length, wanted: leads.value.filter((l) => ['new', 'contacted', 'trial'].includes(l.stage) && l.subjectIds.includes(s.id)).length })).filter((x) => x.n || x.wanted).sort((a, b) => b.n + b.wanted - (a.n + a.wanted)))
const parentPhone = (pid: string) => store.parentMap.get(pid)?.phone ?? ''
</script>

<template>
  <div>
    <PageHeader title="Growth" :sub="`Where the next student, kwacha and returning family will come from · ${term}`" />
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5">
      <StatTile label="Active students" :value="active.length" :hint="`${pct((active.length / capacity) * 100)} of ${capacity} seats filled`" />
      <StatTile label="Returned from last term" :value="Number.isFinite(retention) ? pct(retention) : '—'" :tone="retention < 85 ? 'warn' : 'ok'" :hint="`${returned.length} of ${lastTermStudents.length} students`" />
      <StatTile label="Fees collected this term" :value="Number.isFinite(collection) ? pct(collection) : '—'" :hint="`${kwacha(collectedT(term))} of ${kwacha(billedT(term))}`" />
      <StatTile label="Paid online" :value="Number.isFinite(onlineShare) ? pct(onlineShare) : '—'" hint="Share of this term’s payments" />
      <StatTile label="Empty-seat revenue" :value="kwacha(emptyValue)" tone="brand" hint="Per term, if every seat were filled" />
    </div>

    <section class="mb-5">
      <h2 class="h-section mb-3">This week’s opportunities</h2>
      <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
        <component :is="a.to.startsWith('#') ? 'a' : RouterLink" v-for="a in actions" :key="a.title" :to="a.to.startsWith('#') ? undefined : a.to" :href="a.to.startsWith('#') ? a.to : undefined" class="card card-pad hover:border-brand group flex flex-col">
          <div class="flex items-baseline gap-2"><span class="text-[26px] font-semibold tnum text-brand leading-none">{{ a.n }}</span><span class="font-medium">{{ a.title }}</span></div>
          <p class="text-[13px] text-muted mt-2 flex-1">{{ a.body }}</p>
          <span class="text-[13px] text-brand font-medium mt-3 inline-flex items-center gap-1">{{ a.cta }}<ArrowRight :size="14" class="transition-transform group-hover:translate-x-0.5" /></span>
        </component>
      </div>
    </section>

    <div class="grid lg:grid-cols-2 gap-4 mb-5">
      <section class="card card-pad"><h2 class="h-section">Revenue by term</h2><p class="sub mb-3">Billed against verified collections</p><ChartBox :config="revenueCfg" label="Billed versus collected by term" /></section>
      <section class="card card-pad"><h2 class="h-section">Admissions funnel</h2><p class="sub mb-3">From first enquiry to enrolled student</p><ChartBox :config="funnelCfg" label="Admissions funnel" /></section>
      <section class="card card-pad"><h2 class="h-section">Seats by class</h2><p class="sub mb-3">Filled and empty places</p><ChartBox :config="seatsCfg" label="Filled and empty seats per class" /></section>
      <section class="card">
        <h2 class="h-section px-4 sm:px-5 pt-4">Subject demand</h2><p class="sub px-4 sm:px-5 pb-2">Students now, and families asking — a guide for new classes and tutors</p>
        <div class="table-wrap max-h-[290px] overflow-y-auto"><table class="tbl">
          <thead><tr><th>Subject</th><th>Students</th><th>Open enquiries</th></tr></thead>
          <tbody><tr v-for="x in demand" :key="x.s.id"><td>{{ x.s.name }}</td><td class="tnum">{{ x.n }}</td><td class="tnum">{{ x.wanted || '—' }}</td></tr></tbody>
        </table></div>
      </section>
    </div>

    <div class="grid lg:grid-cols-3 gap-4">
      <section id="at-risk" class="card lg:col-span-2">
        <h2 class="h-section px-4 sm:px-5 pt-4">Learners at risk of leaving</h2>
        <p class="sub px-4 sm:px-5 pb-2">A friendly check-in with the parent now is cheaper than finding a new student later.</p>
        <div v-if="atRisk.length" class="table-wrap"><table class="tbl">
          <thead><tr><th>Student</th><th>Why</th><th></th></tr></thead>
          <tbody><tr v-for="x in atRisk" :key="x.s.id">
            <td class="whitespace-nowrap"><RouterLink :to="`/students/${x.s.id}`" class="font-medium hover:underline">{{ x.s.firstName }} {{ x.s.lastName }}</RouterLink><div class="text-[12px] text-muted">{{ store.className(x.s.classId) }}</div></td>
            <td><div class="flex flex-wrap gap-1"><span v-for="r in x.reasons" :key="r" class="badge badge-warn">{{ r }}</span></div></td>
            <td class="text-right"><a :href="waLink(parentPhone(x.s.parentId), `Good day ${store.parentMap.get(x.s.parentId)?.name}. This is Breath It Tuition Centre. We would like to talk briefly about how ${x.s.firstName} is doing and how we can support them this term. When can we call?`)" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm"><MessageCircle :size="13" />Check in</a></td>
          </tr></tbody>
        </table></div>
        <EmptyState v-else compact title="No learners at risk right now" />
      </section>
      <section class="card card-pad">
        <h2 class="h-section">Did not return</h2><p class="sub mb-3">Students from {{ prevTerm ?? 'last term' }} who are not active now</p>
        <ul v-if="leavers.length" class="grid gap-2.5">
          <li v-for="s in leavers" :key="s.id" class="flex items-center justify-between gap-2 text-[13px]">
            <RouterLink :to="`/students/${s.id}`" class="hover:underline">{{ s.firstName }} {{ s.lastName }} <span class="text-muted">· {{ store.gradeName(s.gradeId) }}</span></RouterLink>
            <a :href="waLink(parentPhone(s.parentId), `Good day ${store.parentMap.get(s.parentId)?.name}. We miss ${s.firstName} at Breath It Tuition Centre! Places are open for ${term}. Would ${s.firstName} like to come back?`)" target="_blank" rel="noopener noreferrer" class="btn btn-ghost btn-sm">Win back</a>
          </li>
        </ul>
        <p v-else class="text-[13px] text-muted">Every student from last term came back.</p>
      </section>
    </div>
  </div>
</template>
