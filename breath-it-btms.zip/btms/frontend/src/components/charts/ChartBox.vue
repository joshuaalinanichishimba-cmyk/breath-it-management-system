<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref, toRaw, watch } from 'vue'
import { Chart, registerables, type ChartConfiguration } from 'chart.js'
Chart.register(...registerables)

const props = withDefaults(defineProps<{ config: ChartConfiguration; height?: number; label: string }>(), { height: 240 })
const canvas = ref<HTMLCanvasElement>()
let chart: Chart | null = null
const css = (v: string) => `rgb(${getComputedStyle(document.documentElement).getPropertyValue(v).trim().split(' ').join(',')})`

function render() {
  chart?.destroy()
  if (!canvas.value) return
  Chart.defaults.font.family = '"Instrument Sans", system-ui, sans-serif'
  Chart.defaults.font.size = 11.5
  Chart.defaults.color = css('--muted')
  Chart.defaults.borderColor = css('--line')
  const cfg = { ...toRaw(props.config) } as ChartConfiguration
  cfg.options = { responsive: true, maintainAspectRatio: false, animation: { duration: 350 }, ...cfg.options }
  chart = new Chart(canvas.value, cfg)
}
let mq: MediaQueryList | null = null
onMounted(() => { render(); mq = window.matchMedia('(prefers-color-scheme: dark)'); mq.addEventListener('change', render) })
watch(() => props.config, render, { deep: true })
onBeforeUnmount(() => { chart?.destroy(); mq?.removeEventListener('change', render) })
</script>
<template>
  <div :style="{ height: height + 'px' }" class="relative"><canvas ref="canvas" role="img" :aria-label="label" /></div>
</template>
