from datetime import date, timedelta
from decimal import Decimal
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ...db import get_db
from ...deps import require_roles, current_user, client_ip
from ...models import Charge, FeeStructure, Payment, Student, User, CentreSetting
from ...schemas.finance import BalanceOut, BankTransferIn, FeeOut, FeeUpdate, GatewayEvent, OnlinePayIn, OnlinePayOut, PaymentIn, PaymentOut, RejectIn
from ...services import payment_gateway as pg
from ...services.access import ensure_student_access
from ...services.audit import audit
from ...services import finance as fin
from .serializers import payment_out

router = APIRouter(prefix="/finance", tags=["finance"])
admin_only = require_roles("admin")


@router.get("/payments", response_model=list[PaymentOut])
def list_payments(status: str | None = None, method: str | None = None, term: str | None = None, student_id: str | None = None,
                  date_from: date | None = None, date_to: date | None = None, q: str = "", limit: int = Query(200, le=1000),
                  user: User = Depends(admin_only), db: Session = Depends(get_db)):
    query = select(Payment)
    if status: query = query.where(Payment.status == status)
    if method: query = query.where(Payment.method == method)
    if term: query = query.where(Payment.term == term)
    if student_id: query = query.where(Payment.student_id == student_id)
    if date_from: query = query.where(Payment.payment_date >= date_from)
    if date_to: query = query.where(Payment.payment_date <= date_to)
    if q:
        like = f"%{q.lower()}%"
        query = query.join(Student).where((func.lower(Payment.reference).like(like)) | (func.lower(Payment.external_ref).like(like)) | (func.lower(Student.first_name + " " + Student.last_name).like(like)))
    return [payment_out(p) for p in db.scalars(query.order_by(Payment.payment_date.desc(), Payment.reference.desc()).limit(limit))]


@router.post("/payments", response_model=PaymentOut, status_code=201)
def record_payment(body: PaymentIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    s = db.get(Student, body.student_id)
    if not s:
        raise HTTPException(404, "Student not found.")
    ref = (body.external_ref or "").strip() or None
    if ref and db.scalar(select(Payment.id).where(func.lower(Payment.external_ref) == ref.lower())):
        raise HTTPException(409, "A payment with this transaction reference has already been recorded.")
    p = Payment(reference=fin.next_number(db, Payment, Payment.reference, f"PAY-{body.payment_date.year}-"), student_id=s.id, amount=body.amount,
                payment_date=body.payment_date, method=body.method, category=body.category, term=body.term, external_ref=ref, notes=body.notes,
                status="pending", recorded_by=user.name, channel="office", network=body.network if body.method == "Mobile Money" else None)
    db.add(p); db.flush()
    p.balance_after = fin.balance(db, s.id) - p.amount
    audit(db, user, "payment.recorded", "payment", p.reference, f"{s.full_name} K{p.amount} via {p.method} (awaiting verification)", client_ip(request))
    if body.verify_now:
        r = fin.verify(db, p, user)
        audit(db, user, "payment.verified", "payment", p.reference, f"receipt {r.receipt_no}", client_ip(request))
    db.commit(); db.refresh(p)
    return payment_out(p)


@router.post("/payments/{payment_id}/verify", response_model=PaymentOut)
def verify_payment(payment_id: str, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Payment, payment_id)
    if not p:
        raise HTTPException(404, "Payment not found.")
    if p.status != "pending":
        raise HTTPException(409, f"This payment is already {p.status}.")
    r = fin.verify(db, p, user)
    audit(db, user, "payment.verified", "payment", p.reference, f"K{p.amount} — receipt {r.receipt_no}", client_ip(request))
    db.commit(); db.refresh(p)
    return payment_out(p)


@router.post("/payments/{payment_id}/reject", response_model=PaymentOut)
def reject_payment(payment_id: str, body: RejectIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    p = db.get(Payment, payment_id)
    if not p or p.status != "pending":
        raise HTTPException(409, "Only payments awaiting verification can be rejected.")
    p.status = "rejected"; p.notes = "; ".join(filter(None, [p.notes, f"Rejected: {body.reason}"]))
    audit(db, user, "payment.rejected", "payment", p.reference, body.reason, client_ip(request)); db.commit()
    return payment_out(p)


@router.get("/payments/{payment_id}/receipt")
def receipt(payment_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = db.get(Payment, payment_id)
    if not p:
        raise HTTPException(404, "Payment not found.")
    s = ensure_student_access(db, user, p.student_id)
    if user.role == "tutor":
        raise HTTPException(403, "Tutors do not have access to fee information.")
    if not p.receipt:
        raise HTTPException(409, "Receipts are issued only for verified payments.")
    return {"receipt_no": p.receipt.receipt_no, "issued_at": p.receipt.issued_at, "issued_by": p.receipt.issued_by, "student": s.full_name,
            "student_no": s.student_no, "payment": payment_out(p)}


@router.get("/balances", response_model=list[BalanceOut])
def balances(owing_only: bool = True, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    out = []
    for s in db.scalars(select(Student).order_by(Student.last_name)):
        b, pd = fin.billed(db, s.id), fin.paid(db, s.id)
        pend = Decimal(db.scalar(select(func.coalesce(func.sum(Payment.amount), 0)).where(Payment.student_id == s.id, Payment.status == "pending")) or 0)
        if owing_only and b - pd <= 0:
            continue
        out.append(BalanceOut(student_id=s.id, student_no=s.student_no, name=s.full_name, billed=b, paid=pd, pending=pend, balance=b - pd))
    return sorted(out, key=lambda x: x.balance, reverse=True)


@router.get("/fee-structures", response_model=list[FeeOut])
def fees(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return list(db.scalars(select(FeeStructure)))


@router.patch("/fee-structures/{fee_id}", response_model=FeeOut)
def update_fee(fee_id: str, body: FeeUpdate, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    f = db.get(FeeStructure, fee_id)
    if not f:
        raise HTTPException(404, "Fee not found.")
    old = f.amount; f.amount = body.amount
    audit(db, user, "fee.updated", "fee_structure", f.id, f"{f.category}: K{old} → K{body.amount} (applies to new charges)", client_ip(request)); db.commit()
    return f


@router.post("/bill-term")
def bill_term(term: str, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    """Raise per-term charges for every active student not yet billed for this term."""
    terms = (db.get(CentreSetting, "terms") or CentreSetting(value={"items": []})).value["items"]
    if not any(t["name"] == term for t in terms):
        raise HTTPException(422, "Unknown term.")
    n = 0
    for s in db.scalars(select(Student).where(Student.status == "active")):
        for f in db.scalars(select(FeeStructure).where(FeeStructure.grade_id == s.grade_id, FeeStructure.frequency == "per term", FeeStructure.amount > 0)):
            if db.scalar(select(Charge.id).where(Charge.student_id == s.id, Charge.term == term, Charge.category == f.category)):
                continue
            db.add(Charge(student_id=s.id, category=f.category, term=term, amount=f.amount, description=f"{term} {f.category.lower()}", issued_on=date.today(), due_date=date.today() + timedelta(days=14)))
            n += 1
    audit(db, user, "billing.run", "charge", term, f"{n} charges raised", client_ip(request)); db.commit()
    return {"charges_created": n}


# ---------------- online payments (parents / students) ----------------
def _payer_can_pay(db: Session, user: User, student_id: str) -> Student:
    if user.role not in ("parent", "student", "admin"):
        raise HTTPException(403, "Only parents and students pay fees online.")
    s = ensure_student_access(db, user, student_id)
    if user.role == "student":
        pol = db.get(CentreSetting, "policies")
        if pol and not pol.value.get("show_fees_to_students", True):
            raise HTTPException(403, "Fees are paid by parents for this centre.")
    return s


def _current_term(db: Session) -> str:
    c = db.get(CentreSetting, "centre")
    return (c.value.get("current_term") if c else None) or str(date.today().year)


@router.post("/pay", response_model=OnlinePayOut, status_code=201)
def pay_online(body: OnlinePayIn, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    s = _payer_can_pay(db, user, body.student_id)
    gateway = pg.get_gateway()
    if gateway is None:
        raise HTTPException(503, "Online payments are not switched on yet. Please pay at the office or by bank transfer.")
    phone = None
    if body.method == "Mobile Money":
        phone = pg.normalise_phone(body.phone or "")
        if not phone:
            raise HTTPException(422, "Enter a Zambian mobile number, e.g. 0977 123 456.")
        if pg.network_for(phone) != body.network:
            raise HTTPException(422, f"{phone} is not a {body.network} number.")
    p = Payment(reference=fin.next_number(db, Payment, Payment.reference, f"PAY-{date.today().year}-"), student_id=s.id, amount=body.amount,
                payment_date=date.today(), method=body.method, network=body.network, payer_phone=phone, category="Tuition", term=_current_term(db),
                channel="online", status="pending", gateway_status="awaiting_customer", recorded_by=f"Parent portal ({user.name})")
    db.add(p); db.flush()
    try:
        res = gateway.initiate(reference=p.reference, amount=float(p.amount), method=p.method, network=p.network, phone=phone, description=f"Breath It fees {s.student_no}")
    except Exception:
        db.rollback()
        raise HTTPException(502, "The payment provider did not respond. No money was taken; please try again.")
    p.gateway_ref = res.gateway_ref
    audit(db, user, "payment.online_started", "payment", p.reference, f"{s.full_name} K{p.amount} via {p.network or 'card'}", client_ip(request))
    db.commit(); db.refresh(p)
    msg = f"Approve K{p.amount} on {phone} with your PIN." if p.method == "Mobile Money" else "Complete the payment on the secure card page."
    return OnlinePayOut(payment=payment_out(p), checkout_url=res.checkout_url, message=msg)


@router.get("/payments/{payment_id}/status", response_model=PaymentOut)
def payment_status(payment_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Polled by the checkout screen while waiting for the payer to approve."""
    p = db.get(Payment, payment_id)
    if not p:
        raise HTTPException(404, "Payment not found.")
    if user.role != "admin":
        _payer_can_pay(db, user, p.student_id)
    return payment_out(p)


@router.post("/bank-transfer", response_model=PaymentOut, status_code=201)
def report_bank_transfer(body: BankTransferIn, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)):
    s = _payer_can_pay(db, user, body.student_id)
    if body.payment_date > date.today():
        raise HTTPException(422, "Payment date cannot be in the future.")
    ref = body.reference.strip()
    if db.scalar(select(Payment.id).where(func.lower(Payment.external_ref) == ref.lower())):
        raise HTTPException(409, "This reference has already been submitted.")
    p = Payment(reference=fin.next_number(db, Payment, Payment.reference, f"PAY-{date.today().year}-"), student_id=s.id, amount=body.amount,
                payment_date=body.payment_date, method="Bank Transfer", category="Tuition", term=_current_term(db), external_ref=ref,
                channel="online", status="pending", recorded_by=f"Parent portal ({user.name})")
    db.add(p); db.flush()
    audit(db, user, "payment.bank_reported", "payment", p.reference, f"{s.full_name} K{p.amount} ref {ref} (awaiting verification)", client_ip(request))
    db.commit(); db.refresh(p)
    return payment_out(p)


@router.post("/gateway/webhook", status_code=200)
async def gateway_webhook(request: Request, x_signature: str | None = Header(default=None), db: Session = Depends(get_db)):
    """Called by the payment aggregator. Authenticated by HMAC signature, not by a user token. Idempotent."""
    raw = await request.body()
    if not pg.signature_valid(raw, x_signature):
        raise HTTPException(401, "Invalid signature.")
    event = GatewayEvent.model_validate_json(raw)
    p = db.scalar(select(Payment).where(Payment.gateway_ref == event.gateway_ref))
    if not p:
        raise HTTPException(404, "Unknown payment reference.")
    if p.status != "pending":
        return {"ok": True, "status": p.status, "duplicate": True}
    system = db.get(User, "system-gateway") or User(id="system-gateway", email="gateway@system.local", name="Payment gateway", role="admin", password_hash="!", is_active=False)
    if event.status == "confirmed":
        if event.amount is not None and Decimal(event.amount) != p.amount:
            p.gateway_status = "amount_mismatch"
            audit(db, system, "payment.gateway_mismatch", "payment", p.reference, f"expected K{p.amount}, gateway reported K{event.amount}")
            db.commit()
            raise HTTPException(409, "Amount does not match the payment request.")
        p.gateway_status = "confirmed"
        r = fin.verify(db, p, system)
        audit(db, system, "payment.gateway_confirmed", "payment", p.reference, f"K{p.amount} — receipt {r.receipt_no}")
    else:
        p.status, p.gateway_status = "rejected", event.status
        audit(db, system, "payment.gateway_failed", "payment", p.reference, event.status)
    db.commit()
    return {"ok": True, "status": p.status}
