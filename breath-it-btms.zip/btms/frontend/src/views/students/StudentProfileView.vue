<script setup lang="ts">
import { methodLabel } from '@/services/payments'
import { computed, ref } from 'vue'
import { useRoute, RouterLink } from 'vue-router'
import type { ChartConfiguration } from 'chart.js'
import { ArrowLeft, Pencil, Wallet, FileDown, Phone } from 'lucide-vue-next'
import Avatar from '@/components/ui/Avatar.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import StatTile from '@/components/ui/StatTile.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import Pager from '@/components/ui/Pager.vue'
import ChartBox from '@/components/charts/ChartBox.vue'
import { series } from '@/components/charts/palette'
import StudentFormModal from '@/components/domain/StudentFormModal.vue'
import PaymentFormModal from '@/components/domain/PaymentFormModal.vue'
import ReceiptModal from '@/components/domain/ReceiptModal.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useScope } from '@/composables/useScope'
import { usePager } from '@/composables/usePager'
import type { Payment } from '@/types'
import { fmtDate, ageFrom, DAY_SHORT, isoWeekday } from '@/services/dates'
import { kwacha, pct, gradeBand } from '@/services/format'
import { attendanceRate, attendanceCounts, average, pctOf } from '@/services/analytics'
import { reportCardPdf } from '@/services/pdf'
import { saveFile } from '@/services/download'

const route = useRoute(); const store = useDb(); const ui = useUi(); const scope = useScope()
const s = computed(() => store.studentMap.get(String(route.params.id)))
const allowed = computed(() => !!s.value && scope.studentIds.value.has(s.value.id))
const isAdmin = computed(() => scope.role.value === 'admin')
const parent = computed(() => (s.value ? store.parentMap.get(s.value.parentId) : undefined))
const siblings = computed(() => (s.value ? store.db.students.filter((x) => x.parentId === s.value!.parentId && x.id !== s.value!.id) : []))
const tab = ref<string>('overview')
const term = computed(() => store.db.settings.currentTerm)

const att = computed(() => (s.value ? store.db.attendance.filter((a) => a.studentId === s.value!.id).sort((a, b) => b.date.localeCompare(a.date)) : []))
const attCounts = computed(() => attendanceCounts(att.value))
const { page: attPage, pages: attPages, rows: attRows, range: attRange } = usePager(att, 15)
const attBySubject = computed(() => s.value!.subjectIds.map((sub) => {
  const r = att.value.filter((a) => store.lessonMap.get(a.lessonId)?.subjectId === sub)
  return { sub, rate: attendanceRate(r), n: r.length }
}))

const results = computed(() => (s.value ? store.db.assessments.filter((a) => a.studentId === s.value!.id).sort((a, b) => b.date.localeCompare(a.date)) : []))
const termAvg = computed(() => average(results.value.filter((r) => r.term === term.value).map(pctOf)))
const resultsCfg = computed<ChartConfiguration>(() => {
  const dates = [...new Set(results.value.map((r) => r.date))].sort()
  const colors = series()
  return { type: 'line', data: { labels: dates.map((d) => fmtDate(d, false)), datasets: s.value!.subjectIds.map((sub, i) => ({
    label: store.subjectName(sub), data: dates.map((d) => { const r = results.value.find((x) => x.subjectId === sub && x.date === d); return r ? +pctOf(r).toFixed(1) : null }),
    borderColor: colors[i % colors.length], backgroundColor: colors[i % colors.length], spanGaps: true, tension: 0.3, pointRadius: 3,
  })) }, options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } }, scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + '%' } }, x: { grid: { display: false } } } } }
})

const charges = computed(() => (s.value ? store.db.charges.filter((c) => c.studentId === s.value!.id).sort((a, b) => b.issuedOn.localeCompare(a.issuedOn)) : []))
const payments = computed(() => (s.value ? store.db.payments.filter((p) => p.studentId === s.value!.id).sort((a, b) => b.date.localeCompare(a.date)) : []))
const termsWithCharges = computed(() => [...new Set(charges.value.map((c) => c.term))].sort())
const events = computed(() => (s.value ? store.db.enrolmentEvents.filter((e) => e.studentId === s.value!.id).sort((a, b) => b.date.localeCompare(a.date)) : []))
const weekLessons = computed(() => store.db.lessons.filter((l) => l.classId === s.value?.classId && s.value?.subjectIds.includes(l.subjectId)).sort((a, b) => a.day - b.day || a.start.localeCompare(b.start)))

const editOpen = ref(false); const payOpen = ref(false); const receipt = ref<Payment | null>(null)
async function setStatus(status: 'active' | 'inactive') {
  const ok = await ui.confirm({ title: status === 'active' ? 'Reactivate student?' : 'Mark student inactive?', body: status === 'active' ? 'The student will appear on registers again.' : 'The student will be removed from future registers. Their records and balance are kept.', confirmLabel: status === 'active' ? 'Reactivate' : 'Mark inactive', tone: status === 'active' ? 'primary' : 'danger' })
  if (!ok) return
  store.setStudentStatus(s.value!.id, status); ui.success(status === 'active' ? 'Student reactivated' : 'Student marked inactive')
}
async function downloadReport() {
  try { if ((await saveFile(`report-${s.value!.studentNo}-${term.value.replace(/\s/g, '-')}.pdf`, reportCardPdf(store.db, s.value!, term.value), 'application/pdf')) === 'saved') ui.success('Report card downloaded') }
  catch (e) { ui.error('Could not download the report', (e as Error).message) }
}
</script>

<template>
  <div v-if="s && allowed">
    <RouterLink to="/students" class="inline-flex items-center gap-1 text-[13px] text-muted hover:text-ink mb-4"><ArrowLeft :size="15" />Students</RouterLink>
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-5">
      <div class="flex items-center gap-3.5">
        <Avatar :name="`${s.firstName} ${s.lastName}`" :size="52" />
        <div>
          <div class="flex items-center gap-2 flex-wrap"><h1 class="text-[22px] font-semibold tracking-[-0.015em]">{{ s.firstName }} {{ s.lastName }}</h1><StatusBadge :status="s.status" /></div>
          <div class="sub tnum">{{ s.studentNo }} · {{ store.gradeName(s.gradeId) }}, {{ store.className(s.classId) }} · enrolled {{ fmtDate(s.enrolmentDate) }}</div>
        </div>
      </div>
      <div class="flex flex-wrap gap-2">
        <button class="btn btn-secondary" @click="downloadReport"><FileDown :size="15" />Report card</button>
        <template v-if="isAdmin">
          <button class="btn btn-secondary" @click="editOpen = true"><Pencil :size="15" />Edit</button>
          <button v-if="s.status === 'active'" class="btn btn-ghost" @click="setStatus('inactive')">Mark inactive</button>
          <button v-else class="btn btn-ghost" @click="setStatus('active')">Reactivate</button>
          <button class="btn btn-primary" @click="payOpen = true"><Wallet :size="15" />Record payment</button>
        </template>
      </div>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
      <StatTile label="Attendance (all records)" :value="att.length ? pct(attendanceRate(att)) : '—'" :hint="`${attCounts.absent} absent · ${attCounts.late} late of ${attCounts.total}`" />
      <StatTile :label="`Average · ${term.replace(' 2026', '')}`" :value="Number.isFinite(termAvg) ? pct(termAvg) : '—'" :hint="Number.isFinite(termAvg) ? gradeBand(termAvg).label : 'No marks yet'" />
      <StatTile label="Subjects" :value="s.subjectIds.length" :hint="`${weekLessons.length} lessons a week`" />
      <StatTile v-if="isAdmin" label="Balance" :value="kwacha(Math.max(0, store.balance(s.id)))" :tone="store.balance(s.id) > 0 ? 'bad' : 'ok'" :hint="store.pendingAmount(s.id) ? `${kwacha(store.pendingAmount(s.id))} awaiting verification` : 'All payments verified'" />
      <StatTile v-else label="Age" :value="ageFrom(s.dob)" :hint="fmtDate(s.dob)" />
    </div>

    <div class="tabs mb-4" role="tablist">
      <button v-for="t in (['overview', 'attendance', 'results', ...(isAdmin ? ['payments'] : []), 'history'] as const)" :key="t" role="tab" :aria-selected="tab === t" :class="['tab capitalize', tab === t && 'tab-active']" @click="tab = t">{{ t }}</button>
    </div>

    <!-- Overview -->
    <div v-if="tab === 'overview'" class="grid lg:grid-cols-3 gap-4">
      <section class="card card-pad">
        <h2 class="h-section mb-3">Personal information</h2>
        <dl class="grid grid-cols-[120px_1fr] gap-y-2 text-[13px]">
          <dt class="text-muted">Date of birth</dt><dd>{{ fmtDate(s.dob) }} ({{ ageFrom(s.dob) }} years)</dd>
          <dt class="text-muted">Gender</dt><dd>{{ s.gender }}</dd>
          <dt class="text-muted">Address</dt><dd>{{ s.address }}</dd>
          <dt class="text-muted">Alt. contact</dt><dd class="tnum">{{ s.altContact ?? '—' }}</dd>
          <template v-if="s.notes"><dt class="text-muted">Notes</dt><dd>{{ s.notes }}</dd></template>
        </dl>
      </section>
      <section class="card card-pad">
        <h2 class="h-section mb-3">Parent or guardian</h2>
        <div v-if="parent" class="text-[13px]">
          <div class="font-medium">{{ parent.name }} <span class="text-muted font-normal">· {{ parent.relationship }}</span></div>
          <a :href="`tel:${parent.phone.replace(/\s/g, '')}`" class="inline-flex items-center gap-1.5 mt-1 text-brand hover:underline tnum"><Phone :size="13" />{{ parent.phone }}</a>
          <div v-if="parent.email" class="text-muted mt-0.5">{{ parent.email }}</div>
          <div class="text-muted mt-0.5">{{ parent.occupation }}</div>
          <div v-if="siblings.length" class="mt-3 pt-3 border-t border-line">
            <div class="text-[12px] text-muted mb-1">Also at Breath It</div>
            <RouterLink v-for="x in siblings" :key="x.id" :to="`/students/${x.id}`" class="block hover:underline">{{ x.firstName }} {{ x.lastName }} · {{ store.gradeName(x.gradeId) }}</RouterLink>
          </div>
        </div>
      </section>
      <section class="card card-pad">
        <h2 class="h-section mb-3">Weekly lessons</h2>
        <ul class="grid gap-1.5 text-[13px]">
          <li v-for="l in weekLessons" :key="l.id" class="flex justify-between gap-2"><span>{{ store.subjectName(l.subjectId) }}</span><span class="text-muted tnum whitespace-nowrap">{{ DAY_SHORT[l.day] }} {{ l.start }}</span></li>
        </ul>
      </section>
    </div>

    <!-- Attendance -->
    <div v-else-if="tab === 'attendance'" class="grid lg:grid-cols-3 gap-4">
      <section class="card card-pad">
        <h2 class="h-section mb-3">By subject</h2>
        <ul class="grid gap-2.5 text-[13px]">
          <li v-for="x in attBySubject" :key="x.sub">
            <div class="flex justify-between"><span>{{ store.subjectName(x.sub) }}</span><span class="tnum text-muted">{{ Number.isFinite(x.rate) ? pct(x.rate) : '—' }}</span></div>
            <div class="h-1.5 rounded-full bg-sunken mt-1 overflow-hidden"><div class="h-full rounded-full" :class="x.rate < store.db.settings.lowAttendanceThreshold ? 'bg-bad' : 'bg-ok'" :style="{ width: (Number.isFinite(x.rate) ? x.rate : 0) + '%' }" /></div>
          </li>
        </ul>
      </section>
      <section class="card lg:col-span-2">
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Date</th><th>Lesson</th><th>Status</th></tr></thead>
          <tbody><tr v-for="a in attRows" :key="a.id">
            <td class="whitespace-nowrap">{{ DAY_SHORT[isoWeekday(a.date)] }} {{ fmtDate(a.date) }}</td>
            <td>{{ store.subjectName(store.lessonMap.get(a.lessonId)?.subjectId ?? '') }} <span class="text-muted">· {{ store.lessonMap.get(a.lessonId)?.start }}</span></td>
            <td><StatusBadge :status="a.status" /></td>
          </tr></tbody>
        </table></div>
        <EmptyState v-if="!att.length" compact title="No attendance recorded yet" />
        <Pager v-else v-model="attPage" :pages="attPages" :range="attRange" />
      </section>
    </div>

    <!-- Results -->
    <div v-else-if="tab === 'results'" class="grid gap-4">
      <section class="card card-pad"><h2 class="h-section mb-3">Improvement by subject</h2><ChartBox :config="resultsCfg" :height="260" label="Marks by subject over time" /></section>
      <section class="card">
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Date</th><th>Subject</th><th>Assessment</th><th>Marks</th><th>%</th><th>Comment</th></tr></thead>
          <tbody><tr v-for="r in results" :key="r.id">
            <td class="whitespace-nowrap">{{ fmtDate(r.date) }}</td><td class="whitespace-nowrap">{{ store.subjectName(r.subjectId) }}</td>
            <td class="whitespace-nowrap">{{ r.title }}<div class="text-[12px] text-muted">{{ r.type }}</div></td>
            <td class="tnum">{{ r.marks }}/{{ r.maxMarks }}</td>
            <td><span :class="['badge tnum', 'badge-' + gradeBand(pctOf(r)).tone]">{{ pct(pctOf(r)) }}</span></td>
            <td class="text-muted min-w-[220px]">{{ r.comment }}</td>
          </tr></tbody>
        </table></div>
        <EmptyState v-if="!results.length" compact title="No assessments recorded yet" />
      </section>
    </div>

    <!-- Payments -->
    <div v-else-if="tab === 'payments'" class="grid gap-4">
      <div class="grid sm:grid-cols-3 gap-3">
        <div v-for="t in termsWithCharges" :key="t" class="card px-4 py-3">
          <div class="text-[12.5px] text-muted">{{ t }}</div>
          <div class="flex items-baseline justify-between mt-1"><span :class="['text-[18px] font-semibold tnum', store.balance(s.id, t) > 0 ? 'text-bad' : 'text-ok']">{{ store.balance(s.id, t) > 0 ? kwacha(store.balance(s.id, t)) + ' due' : 'Paid' }}</span>
            <span class="text-[12px] text-muted tnum">{{ kwacha(store.paid(s.id, t)) }} / {{ kwacha(store.billed(s.id, t)) }}</span></div>
        </div>
      </div>
      <section class="card">
        <h2 class="h-section px-4 sm:px-5 pt-4 pb-2">Payments</h2>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Date</th><th>Reference</th><th>For</th><th>Method</th><th class="text-right">Amount</th><th>Status</th><th></th></tr></thead>
          <tbody><tr v-for="p in payments" :key="p.id">
            <td class="whitespace-nowrap">{{ fmtDate(p.date) }}</td><td class="tnum">{{ p.reference }}</td><td class="whitespace-nowrap">{{ p.category }} · {{ p.term }}</td><td class="whitespace-nowrap">{{ methodLabel(p) }}<span v-if="p.channel === 'online'" class="badge badge-info ml-1.5">Online</span></td>
            <td class="text-right tnum font-medium">{{ kwacha(p.amount) }}</td><td><StatusBadge :status="p.status" /></td>
            <td class="text-right"><button v-if="p.status === 'verified'" class="btn btn-ghost btn-sm" @click="receipt = p">Receipt</button></td>
          </tr></tbody>
        </table></div>
        <EmptyState v-if="!payments.length" compact title="No payments yet" />
      </section>
      <section class="card">
        <h2 class="h-section px-4 sm:px-5 pt-4 pb-2">Fees charged</h2>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Issued</th><th>Description</th><th>Term</th><th>Due</th><th class="text-right">Amount</th></tr></thead>
          <tbody><tr v-for="c in charges" :key="c.id"><td>{{ fmtDate(c.issuedOn) }}</td><td>{{ c.description }}</td><td>{{ c.term }}</td><td>{{ fmtDate(c.dueDate) }}</td><td class="text-right tnum">{{ kwacha(c.amount) }}</td></tr></tbody>
        </table></div>
      </section>
    </div>

    <!-- History -->
    <section v-else class="card card-pad">
      <h2 class="h-section mb-3">Enrolment history</h2>
      <ol class="relative border-l border-line ml-1.5 grid gap-4">
        <li v-for="e in events" :key="e.id" class="pl-5 relative">
          <span class="absolute -left-[5px] top-1.5 h-2.5 w-2.5 rounded-full bg-brand" />
          <div class="text-[13px] font-medium">{{ e.action }} <span class="text-muted font-normal">· {{ fmtDate(e.date) }}</span></div>
          <div class="text-[13px] text-muted">{{ e.detail }}</div>
        </li>
      </ol>
    </section>

    <StudentFormModal :open="editOpen" :student="s" @close="editOpen = false" />
    <PaymentFormModal :open="payOpen" :student-id="s.id" @close="payOpen = false" />
    <ReceiptModal :payment="receipt" @close="receipt = null" />
  </div>
  <EmptyState v-else title="Student not found" body="This record does not exist or is not linked to your account.">
    <RouterLink to="/students" class="btn btn-secondary">Back to students</RouterLink>
  </EmptyState>
</template>
