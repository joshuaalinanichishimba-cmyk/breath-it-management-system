<script setup lang="ts">
import { RouterLink } from 'vue-router'
import PageHeader from '@/components/ui/PageHeader.vue'
import LearnerSummary from '@/components/domain/LearnerSummary.vue'
import ChildSwitcher from '@/components/domain/ChildSwitcher.vue'
import PayNowModal from '@/components/domain/PayNowModal.vue'
import ReferralCard from '@/components/domain/ReferralCard.vue'
import { ref, computed } from 'vue'
import { Wallet } from 'lucide-vue-next'
import { usePortalStudent } from '@/composables/usePortalStudent'
import { useAnnouncements } from '@/composables/useAnnouncements'
import { useAuth } from '@/stores/auth'
import { useDb } from '@/stores/db'
import { kwacha } from '@/services/format'
import { fmtDate } from '@/services/dates'
import { greeting, todayLabel } from './greeting'
const { student, children } = usePortalStudent(); const anns = useAnnouncements(); const auth = useAuth(); const store = useDb()
const payOpen = ref(false)
const owing = computed(() => children.value.reduce((a, c) => a + Math.max(0, store.balance(c.id)), 0))
</script>
<template>
  <div>
    <PageHeader :title="greeting(auth.user?.name ?? '')" :sub="`${todayLabel()} · ${children.length === 1 ? '1 child' : children.length + ' children'} at Breath It`">
      <RouterLink to="/my/payments" class="btn btn-secondary">Fees & receipts</RouterLink>
      <button v-if="store.db.settings.onlinePayments.enabled && owing > 0" class="btn btn-primary" @click="payOpen = true"><Wallet :size="15" />Pay {{ kwacha(owing) }}</button>
    </PageHeader>
    <div v-if="children.length > 1" class="grid sm:grid-cols-2 gap-3 mb-5">
      <div v-for="c in children" :key="c.id" class="card px-4 py-3 flex items-center justify-between gap-3">
        <div><div class="font-medium">{{ c.firstName }} {{ c.lastName }}</div><div class="text-[12px] text-muted">{{ store.gradeName(c.gradeId) }} · {{ c.studentNo }}</div></div>
        <div class="text-right"><div class="text-[12px] text-muted">Balance</div><div :class="['font-semibold tnum', store.balance(c.id) > 0 ? 'text-bad' : 'text-ok']">{{ kwacha(Math.max(0, store.balance(c.id))) }}</div></div>
      </div>
    </div>
    <ChildSwitcher />
    <LearnerSummary v-if="student" :student="student" />
    <div class="grid lg:grid-cols-2 gap-4 mt-4 items-start">
    <ReferralCard />
    <section class="card card-pad">
      <div class="flex items-baseline justify-between mb-2"><h2 class="h-section">From the centre</h2><RouterLink to="/announcements" class="text-[12.5px] text-brand hover:underline">All announcements</RouterLink></div>
      <article v-for="a in anns.slice(0, 3)" :key="a.id" class="py-2.5 border-b border-line last:border-0">
        <div class="flex items-center gap-2 flex-wrap"><span class="text-[13px] font-medium">{{ a.title }}</span><span v-if="a.priority === 'important'" class="badge badge-bad">Important</span><span class="text-[12px] text-faint">{{ fmtDate(a.createdAt.slice(0, 10)) }}</span></div>
        <p class="text-[12.5px] text-muted mt-0.5">{{ a.body }}</p>
      </article>
    </section>
    </div>
    <PayNowModal :open="payOpen" :students="children" :initial-student-id="student?.id" @close="payOpen = false" />
  </div>
</template>
