/** Resolve design tokens to rgb()/rgba() strings for Chart.js datasets. */
export function tok(name: string, alpha = 1): string {
  const raw = getComputedStyle(document.documentElement).getPropertyValue(`--${name}`).trim().split(' ').join(',')
  return alpha === 1 ? `rgb(${raw})` : `rgba(${raw},${alpha})`
}
export const series = () => [tok('brand'), tok('info'), tok('ok'), tok('warn'), tok('bad'), tok('faint')]
