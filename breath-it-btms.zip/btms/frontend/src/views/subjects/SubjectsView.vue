<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { Plus, Pencil } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Modal from '@/components/ui/Modal.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import type { Subject } from '@/types'
import { kwacha } from '@/services/format'

const store = useDb(); const ui = useUi()
const grades = computed(() => [...store.db.grades].sort((a, b) => a.order - b.order))
const filter = ref('')
const subjects = computed(() => store.db.subjects.filter((s) => !filter.value || s.gradeIds.includes(filter.value)))
const enrolledCount = (sid: string) => store.db.students.filter((s) => s.status === 'active' && s.subjectIds.includes(sid)).length

const open = ref(false); const editing = ref<Subject | null>(null); const err = ref('')
const blank = () => ({ name: '', code: '', gradeIds: [] as string[], active: true })
const f = reactive(blank())
function edit(s?: Subject) { editing.value = s ?? null; Object.assign(f, blank(), s ? { ...s, gradeIds: [...s.gradeIds] } : {}); err.value = ''; open.value = true }
function save() {
  if (!f.name.trim() || !f.code.trim()) return (err.value = 'Name and code are required.')
  if (!f.gradeIds.length) return (err.value = 'Choose at least one grade.')
  try { store.saveSubject({ ...f, name: f.name.trim(), code: f.code.trim().toUpperCase(), id: editing.value?.id }); ui.success(editing.value ? 'Subject updated' : 'Subject added'); open.value = false }
  catch (e) { err.value = (e as Error).message }
}
const gOpen = ref(false); const g = reactive({ name: '', examLevel: '', order: 10 })
function saveGrade() {
  if (!g.name.trim()) return ui.error('Enter a grade or programme name.')
  if (store.db.grades.some((x) => x.name.toLowerCase() === g.name.trim().toLowerCase())) return ui.error('That grade already exists.')
  store.addGrade({ name: g.name.trim(), examLevel: g.examLevel.trim() || 'To be confirmed', order: g.order, active: true })
  ui.success('Grade added', 'Set its fees in Finance → Fee structure.'); gOpen.value = false; Object.assign(g, { name: '', examLevel: '', order: 10 })
}
</script>
<template>
  <div>
    <PageHeader title="Grades and subjects" sub="Starting structure taken from the centre’s published subject list. Everything here is editable as programmes change.">
      <button class="btn btn-secondary" @click="gOpen = true"><Plus :size="15" />Add grade</button>
      <button class="btn btn-primary" @click="edit()"><Plus :size="15" />Add subject</button>
    </PageHeader>
    <div class="grid sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-5">
      <button v-for="gr in grades" :key="gr.id" :class="['card px-4 py-3 text-left transition-colors', filter === gr.id ? 'border-brand ring-2 ring-brand/20' : 'hover:border-faint']" @click="filter = filter === gr.id ? '' : gr.id">
        <div class="font-semibold">{{ gr.name }}</div>
        <div class="text-[12px] text-muted leading-snug mt-0.5">{{ gr.examLevel }}</div>
        <div class="text-[12px] mt-2"><span class="tnum font-medium">{{ store.db.subjects.filter((s) => s.gradeIds.includes(gr.id)).length }}</span> subjects · <span class="tnum font-medium">{{ store.db.students.filter((s) => s.gradeId === gr.id && s.status === 'active').length }}</span> students</div>
        <div class="text-[12px] text-muted">Tuition {{ kwacha(store.db.feeStructures.find((f) => f.gradeId === gr.id && f.category === 'Tuition')?.amount ?? 0) }}/term</div>
      </button>
    </div>
    <div class="card">
      <div class="px-4 sm:px-5 pt-4 pb-2 flex items-center justify-between"><h2 class="h-section">{{ filter ? `Subjects for ${store.gradeName(filter)}` : 'All subjects' }}</h2><button v-if="filter" class="btn btn-ghost btn-sm" @click="filter = ''">Show all</button></div>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>Subject</th><th>Code</th><th>Offered in</th><th>Students</th><th>Status</th><th></th></tr></thead>
        <tbody><tr v-for="s in subjects" :key="s.id">
          <td class="font-medium">{{ s.name }}</td><td class="tnum text-muted">{{ s.code }}</td>
          <td><div class="flex flex-wrap gap-1"><span v-for="gid in s.gradeIds" :key="gid" class="badge badge-mute">{{ store.gradeName(gid) }}</span></div></td>
          <td class="tnum">{{ enrolledCount(s.id) }}</td>
          <td><span :class="['badge', s.active ? 'badge-ok' : 'badge-mute']">{{ s.active ? 'Offered' : 'Not offered' }}</span></td>
          <td class="text-right"><button class="icon-btn" :aria-label="`Edit ${s.name}`" @click="edit(s)"><Pencil :size="15" /></button></td>
        </tr></tbody>
      </table></div>
    </div>
    <Modal :open="open" :title="editing ? 'Edit subject' : 'Add subject'" @close="open = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
        <div><label class="label" for="su-n">Subject name</label><input id="su-n" v-model="f.name" class="input" placeholder="e.g. Chemistry" /></div>
        <div><label class="label" for="su-c">Code</label><input id="su-c" v-model="f.code" class="input uppercase" placeholder="e.g. CHEM" /></div>
        <div class="sm:col-span-2"><span class="label">Offered in</span>
          <div class="flex flex-wrap gap-2"><label v-for="gr in grades" :key="gr.id" :class="['flex items-center h-8 px-3 rounded-full border text-[13px] cursor-pointer', f.gradeIds.includes(gr.id) ? 'border-brand bg-brand-soft' : 'border-line']"><input v-model="f.gradeIds" type="checkbox" :value="gr.id" class="sr-only" />{{ gr.name }}</label></div></div>
        <label v-if="editing" class="flex items-center gap-2.5 text-[13px]"><input v-model="f.active" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />Currently offered</label>
        <p v-if="err" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer><button class="btn btn-secondary" @click="open = false">Cancel</button><button class="btn btn-primary" @click="save">{{ editing ? 'Save changes' : 'Add subject' }}</button></template>
    </Modal>
    <Modal :open="gOpen" title="Add grade or programme" sub="For example Grade 10, Grade 11 or a holiday programme" size="sm" @close="gOpen = false">
      <div class="grid gap-4">
        <div><label class="label" for="gr-n">Name</label><input id="gr-n" v-model="g.name" class="input" placeholder="e.g. Grade 10" /></div>
        <div><label class="label" for="gr-e">Level / examination</label><input id="gr-e" v-model="g.examLevel" class="input" placeholder="e.g. Senior secondary" /></div>
        <div><label class="label" for="gr-o">Sort order</label><input id="gr-o" v-model.number="g.order" type="number" class="input" /></div>
      </div>
      <template #footer><button class="btn btn-secondary" @click="gOpen = false">Cancel</button><button class="btn btn-primary" @click="saveGrade">Add grade</button></template>
    </Modal>
  </div>
</template>
