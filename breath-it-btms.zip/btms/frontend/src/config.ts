/**
 * Runtime mode.
 *  DEMO (default): runs fully in the browser on fictional sample data — this is what GitHub Pages serves.
 *  CONNECTED: VITE_DEMO_MODE=false — authentication goes to the FastAPI backend at VITE_API_URL.
 */
export const DEMO_MODE = import.meta.env.VITE_DEMO_MODE !== 'false'
export const API_URL = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '')
export const ROUTER_MODE = import.meta.env.VITE_ROUTER_MODE ?? 'hash'
export const STORAGE_KEY = 'btms-demo-db'
export const SESSION_KEY = 'btms-session'
