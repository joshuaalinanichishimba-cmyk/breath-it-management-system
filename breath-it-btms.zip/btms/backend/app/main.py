from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .core.config import get_settings
from .api.v1 import academics, auth, comms, finance, growth, people, records, reports

settings = get_settings()
app = FastAPI(
    title="Breath It Tuition Centre Management System API",
    version="1.0.0",
    description="Role-based API for Breath It Tuition Centre: students, tutors, timetable, attendance, assessments, finance and communication.",
    docs_url=None if settings.is_production else "/docs",
)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_list, allow_credentials=False, allow_methods=["*"], allow_headers=["Authorization", "Content-Type"])  # the gateway webhook is server-to-server, so CORS does not apply to it

for r in (auth.router, people.router, academics.router, records.router, finance.router, comms.router, reports.router, growth.router):
    app.include_router(r, prefix="/api/v1")


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}
