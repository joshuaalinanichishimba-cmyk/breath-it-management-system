/**
 * DEMONSTRATION DATA GENERATOR
 * Every person, phone number, payment and mark produced here is fictional.
 * Data is generated deterministically (seeded PRNG) relative to "today" so the demo always looks current.
 */
import type {
  Announcement, Assessment, AssessmentType, AttendanceRecord, AuditEntry, Charge, ClassGroup, DemoDatabase,
  EnrolmentEvent, FeeStructure, Grade, Lesson, Material, Parent, Payment, PaymentMethod, Student, Subject, Tutor,
} from '@/types'
import { addDays, iso, isoWeekday } from '@/services/dates'
import { networkFromPhone, normalisePhone } from '@/services/payments'
import type { Lead } from '@/types'

export const SEED_VERSION = 7

function mulberry32(a: number) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export const TERMS_2026 = [
  { name: 'Term 1 2026', start: '2026-01-12', end: '2026-04-10' },
  { name: 'Term 2 2026', start: '2026-05-11', end: '2026-08-07' },
  { name: 'Term 3 2026', start: '2026-09-07', end: '2026-12-04' },
]

export function termFor(date: string): string {
  const t = TERMS_2026.find((x) => date >= x.start && date <= x.end)
  if (t) return t.name
  const past = TERMS_2026.filter((x) => x.start <= date)
  return (past[past.length - 1] ?? TERMS_2026[0]).name
}

const grades: Grade[] = [
  { id: 'g7', name: 'Grade 7', order: 7, examLevel: 'Primary — Grade 7 composite examination', active: true },
  { id: 'g8', name: 'Grade 8', order: 8, examLevel: 'Junior secondary', active: true },
  { id: 'g9', name: 'Grade 9', order: 9, examLevel: 'Junior secondary — Grade 9 examination', active: true },
  { id: 'g12', name: 'Grade 12', order: 12, examLevel: 'Senior secondary — School Certificate', active: true },
  { id: 'gce', name: 'GCE', order: 13, examLevel: 'GCE — external candidates', active: true },
]
const S = (id: string, name: string, code: string, gradeIds: string[]): Subject => ({ id, name, code, gradeIds, active: true })
const subjects: Subject[] = [
  S('s-math', 'Mathematics', 'MATH', ['g7', 'g8', 'g9', 'g12', 'gce']),
  S('s-eng', 'English', 'ENG', ['g7', 'g8', 'g9', 'g12', 'gce']),
  S('s-isc', 'Integrated Science', 'ISC', ['g7', 'g8', 'g9']),
  S('s-sst', 'Social Studies', 'SST', ['g7', 'g8', 'g9']),
  S('s-cts', 'Creative Technology Studies', 'CTS', ['g7']),
  S('s-sp1', 'Special Paper 1', 'SP1', ['g7']),
  S('s-sp2', 'Special Paper 2', 'SP2', ['g7']),
  S('s-re', 'Religious Education', 'RE', ['g8', 'g9', 'g12', 'gce']),
  S('s-bs', 'Business Studies', 'BST', ['g8', 'g9']),
  S('s-cs', 'Computer Studies', 'CST', ['g8', 'g9', 'g12', 'gce']),
  S('s-sci', 'Science', 'SCI', ['g12', 'gce']),
  S('s-bio', 'Biology', 'BIO', ['g12', 'gce']),
  S('s-civ', 'Civic Education', 'CVE', ['g12', 'gce']),
  S('s-his', 'History', 'HIS', ['g12', 'gce']),
  S('s-com', 'Commerce', 'COM', ['g12', 'gce']),
  S('s-acc', 'Accounts', 'ACC', ['g12', 'gce']),
]

const tutors: Tutor[] = [
  { id: 't1', staffNo: 'BIT-T-001', firstName: 'Chanda', lastName: 'Mwila', gender: 'Male', phone: '0977 410 225', email: 'c.mwila@breathit.demo', qualification: 'BSc Mathematics Education (UNZA)', subjectIds: ['s-math'], hireDate: '2021-01-18', status: 'active' },
  { id: 't2', staffNo: 'BIT-T-002', firstName: 'Mercy', lastName: 'Sakala', gender: 'Female', phone: '0966 301 784', email: 'm.sakala@breathit.demo', qualification: 'BA Ed. English & Literature', subjectIds: ['s-eng'], hireDate: '2021-05-03', status: 'active' },
  { id: 't3', staffNo: 'BIT-T-003', firstName: 'Kelvin', lastName: 'Tembo', gender: 'Male', phone: '0955 872 106', email: 'k.tembo@breathit.demo', qualification: 'BSc Ed. Biology & Chemistry', subjectIds: ['s-isc', 's-sci', 's-bio'], hireDate: '2022-02-07', status: 'active' },
  { id: 't4', staffNo: 'BIT-T-004', firstName: 'Ruth', lastName: 'Nkhoma', gender: 'Female', phone: '0976 554 019', email: 'r.nkhoma@breathit.demo', qualification: 'BA Ed. History & Religious Studies', subjectIds: ['s-sst', 's-re', 's-civ', 's-his'], hireDate: '2022-09-12', status: 'active' },
  { id: 't5', staffNo: 'BIT-T-005', firstName: 'Brian', lastName: 'Mulenga', gender: 'Male', phone: '0779 213 640', email: 'b.mulenga@breathit.demo', qualification: 'Diploma in ICT; BBA', subjectIds: ['s-cs', 's-cts', 's-bs'], hireDate: '2023-01-16', status: 'active' },
  { id: 't6', staffNo: 'BIT-T-006', firstName: 'Grace', lastName: 'Lungu', gender: 'Female', phone: '0968 117 392', email: 'g.lungu@breathit.demo', qualification: 'BAcc; Diploma in Primary Education', subjectIds: ['s-math', 's-com', 's-acc', 's-sp1', 's-sp2'], hireDate: '2023-08-21', status: 'active' },
]

const classes: ClassGroup[] = [
  { id: 'c-g7a', name: 'Grade 7 A', gradeId: 'g7', classTutorId: 't6', room: 'Room 1', capacity: 8, active: true },
  { id: 'c-g8a', name: 'Grade 8 A', gradeId: 'g8', classTutorId: 't1', room: 'Room 2', capacity: 10, active: true },
  { id: 'c-g9a', name: 'Grade 9 A', gradeId: 'g9', classTutorId: 't4', room: 'Room 3', capacity: 10, active: true },
  { id: 'c-g12a', name: 'Grade 12 A', gradeId: 'g12', classTutorId: 't3', room: 'Room 4', capacity: 12, active: true },
  { id: 'c-gcea', name: 'GCE A', gradeId: 'gce', classTutorId: 't5', room: 'Room 5', capacity: 8, active: true },
]
const classByGrade: Record<string, string> = { g7: 'c-g7a', g8: 'c-g8a', g9: 'c-g9a', g12: 'c-g12a', gce: 'c-gcea' }

const P = (id: string, name: string, relationship: Parent['relationship'], phone: string, address: string, occupation: string, email?: string): Parent =>
  ({ id, name, relationship, phone, address, occupation, email, portalAccess: true })
const parents: Parent[] = [
  P('p01', 'Mutale Banda', 'Mother', '0977 112 408', 'House 14, Kaunda Square Stage 2', 'Nurse', 'mutale.banda@parent.demo'),
  P('p02', 'Joseph Mwansa', 'Father', '0966 245 117', 'Plot 220, Mtendere East', 'Electrician'),
  P('p03', 'Esther Phiri', 'Mother', '0955 380 662', 'House 7, Kaunda Square Stage 1', 'Teacher'),
  P('p04', 'Rabecca Nyirenda', 'Mother', '0978 902 154', 'Chainda, near the market', 'Trader'),
  P('p05', 'Moses Hamweemba', 'Father', '0969 631 270', 'Plot 51, Chelstone', 'Accountant'),
  P('p06', 'Charity Ngoma', 'Mother', '0776 418 993', 'Kalingalinga', 'Tailor'),
  P('p07', 'Elias Daka', 'Father', '0977 655 031', 'House 102, Kaunda Square Stage 2', 'Driver'),
  P('p08', 'Beatrice Kabwe', 'Mother', '0962 784 450', 'Mtendere', 'Civil servant'),
  P('p09', 'Gilbert Mbewe', 'Father', '0954 220 816', 'Chelstone Extension', 'Mechanic'),
  P('p10', 'Namakau Simasiku', 'Mother', '0975 337 902', 'Avondale', 'Banker'),
  P('p11', 'Mukela Mubita', 'Father', '0967 049 581', 'Kaunda Square Stage 2', 'Police officer'),
  P('p12', 'Florence Musonda', 'Mother', '0779 560 247', 'Chainda South', 'Hairdresser'),
  P('p13', 'Victor Chanda', 'Father', '0977 801 336', 'Plot 9, Mtendere East', 'Businessman'),
  P('p14', 'Mubiana Lewanika', 'Mother', '0965 193 744', 'Avondale', 'Pharmacist'),
  P('p15', 'Samuel Zimba', 'Father', '0956 612 085', 'Chelstone', 'Farmer'),
  P('p16', 'Loveness Chirwa', 'Mother', '0974 288 519', 'Kaunda Square Stage 1', 'Caterer'),
  P('p17', 'Harriet Siame', 'Guardian', '0961 875 302', 'Mtendere', 'Shop owner'),
  P('p18', 'Steven Mumba', 'Uncle', '0778 330 641', 'Kalingalinga', 'Carpenter'),
  P('p19', 'Edith Kapambwe', 'Mother', '0977 046 873', 'Chainda', 'Secretary'),
  P('p20', 'Kennedy Nkonde', 'Father', '0968 517 220', 'Chelstone', 'Bus operator'),
]

type Spec = [id: string, first: string, last: string, g: 'Female' | 'Male', grade: string, parent: string, enrol: string, dob: string, status?: Student['status']]
const specs: Spec[] = [
  ['s01', 'Natasha', 'Banda', 'Female', 'g12', 'p01', '2025-02-03', '2008-06-14'],
  ['s02', 'John', 'Banda', 'Male', 'g8', 'p01', '2026-01-12', '2012-09-02'],
  ['s03', 'Bwalya', 'Mwansa', 'Male', 'g9', 'p02', '2025-05-12', '2011-03-21'],
  ['s04', 'Chipo', 'Mwansa', 'Female', 'g7', 'p02', '2026-01-19', '2013-11-08'],
  ['s05', 'Thandiwe', 'Phiri', 'Female', 'g12', 'p03', '2025-01-20', '2008-02-27'],
  ['s06', 'Mapalo', 'Nyirenda', 'Male', 'g7', 'p04', '2026-02-02', '2014-01-15'],
  ['s07', 'Taonga', 'Nyirenda', 'Female', 'g8', 'p04', '2026-02-02', '2012-07-30'],
  ['s08', 'Luyando', 'Hamweemba', 'Female', 'g7', 'p05', '2026-01-12', '2013-05-19'],
  ['s09', 'Mutinta', 'Hamweemba', 'Female', 'g8', 'p05', '2025-09-08', '2012-04-04'],
  ['s10', 'Kondwani', 'Ngoma', 'Male', 'g7', 'p06', '2026-05-11', '2013-12-01', 'inactive'],
  ['s11', 'Chisomo', 'Daka', 'Female', 'g8', 'p07', '2026-05-18', '2012-10-22'],
  ['s12', 'Mwenya', 'Kabwe', 'Male', 'g8', 'p08', '2026-09-07', '2012-08-13'],
  ['s13', 'Precious', 'Mbewe', 'Female', 'g9', 'p09', '2025-01-13', '2011-06-06'],
  ['s14', 'Lubinda', 'Simasiku', 'Male', 'g9', 'p10', '2026-01-12', '2011-09-17'],
  ['s15', 'Nalukui', 'Mubita', 'Female', 'g9', 'p11', '2026-03-02', '2011-01-29'],
  ['s16', 'Chileshe', 'Musonda', 'Male', 'g9', 'p12', '2026-09-14', '2011-12-10'],
  ['s17', 'Kalaba', 'Chanda', 'Male', 'g12', 'p13', '2025-08-04', '2008-10-03'],
  ['s18', 'Inonge', 'Lewanika', 'Female', 'g12', 'p14', '2026-01-12', '2008-05-25'],
  ['s19', 'Emmanuel', 'Zimba', 'Male', 'g12', 'p15', '2026-05-11', '2009-01-12'],
  ['s20', 'Faith', 'Chirwa', 'Female', 'g12', 'p16', '2026-10-05', '2008-08-18'],
  ['s21', 'Brenda', 'Siame', 'Female', 'gce', 'p17', '2025-10-06', '2003-04-09'],
  ['s22', 'Davies', 'Mumba', 'Male', 'gce', 'p18', '2026-01-26', '2001-07-21', 'inactive'],
  ['s23', 'Agness', 'Kapambwe', 'Female', 'gce', 'p19', '2026-05-11', '2005-02-14'],
  ['s24', 'Peter', 'Nkonde', 'Male', 'gce', 'p20', '2026-09-07', '2004-11-30'],
]

const fixedSubjects: Record<string, string[]> = {
  s01: ['s-math', 's-eng', 's-bio', 's-civ', 's-cs'],
  s02: ['s-math', 's-eng', 's-isc', 's-bs'],
}

const COMMENTS = {
  high: ['Excellent work — keep this standard.', 'Very good understanding of the topic.', 'Consistent and well presented.', 'Strong performance, ready for exam-level questions.'],
  mid: ['Good effort. Revise the weaker sections.', 'Steady progress; practise more past paper questions.', 'Fair work — show all working clearly.', 'Improving. Pay attention to time management.'],
  low: ['Needs more practice on basic concepts.', 'Please attend the Saturday revision session.', 'Work is incomplete — see me after class.', 'Below expected level; extra support recommended.'],
}

export function buildSeed(today: string = iso()): DemoDatabase {
  const r = mulberry32(20260916)
  const pick = <T,>(arr: T[]): T => arr[Math.floor(r() * arr.length)]
  const between = (a: number, b: number) => a + r() * (b - a)
  const counters: Record<string, number> = {}
  const next = (k: string) => (counters[k] = (counters[k] ?? 0) + 1)

  // ---------- students ----------
  const students: Student[] = []
  const enrolmentEvents: EnrolmentEvent[] = []
  const sortedSpecs = [...specs].sort((a, b) => a[6].localeCompare(b[6]))
  for (const [id, first, last, gender, grade, parent, enrol, dob, status] of sortedSpecs) {
    const gradeSubjects = subjects.filter((s) => s.gradeIds.includes(grade)).map((s) => s.id)
    let chosen: string[]
    if (fixedSubjects[id]) chosen = fixedSubjects[id]
    else if (grade === 'g7') chosen = gradeSubjects
    else if (grade === 'g8' || grade === 'g9') {
      const extras = ['s-sst', 's-re', 's-bs', 's-cs'].sort(() => r() - 0.5).slice(0, 1 + Math.floor(r() * 2))
      chosen = ['s-math', 's-eng', 's-isc', ...extras]
    } else if (grade === 'g12') {
      const extras = ['s-sci', 's-bio', 's-civ', 's-his', 's-re', 's-cs', 's-com', 's-acc'].sort(() => r() - 0.5).slice(0, 2 + Math.floor(r() * 2))
      chosen = ['s-math', 's-eng', ...extras]
    } else {
      const pool = ['s-math', 's-eng', 's-sci', 's-bio', 's-civ', 's-com', 's-acc']
      chosen = ['s-math', ...pool.slice(1).sort(() => r() - 0.5).slice(0, 1 + Math.floor(r() * 2))]
    }
    const seq = next('student')
    const p = parents.find((x) => x.id === parent)!
    students.push({
      id, studentNo: `BIT-${enrol.slice(0, 4)}-${String(seq).padStart(3, '0')}`,
      firstName: first, lastName: last, gender, dob, gradeId: grade, classId: classByGrade[grade], parentId: parent,
      altContact: r() > 0.5 ? `09${pick(['77', '66', '55', '76'])} ${Math.floor(between(100, 999))} ${Math.floor(between(100, 999))}` : undefined,
      address: p.address, enrolmentDate: enrol, subjectIds: chosen, status: status ?? 'active',
    })
    enrolmentEvents.push({ id: `ev${next('event')}`, studentId: id, date: enrol, action: 'Registered', detail: `Enrolled in ${grades.find((g) => g.id === grade)!.name}` })
    if (status === 'inactive') enrolmentEvents.push({ id: `ev${next('event')}`, studentId: id, date: '2026-08-07', action: 'Status changed', detail: 'Marked inactive at end of Term 2 (did not return)' })
  }
  students.sort((a, b) => a.id.localeCompare(b.id))

  // ---------- timetable ----------
  const slots: { day: number; start: string; end: string }[] = []
  for (let d = 1; d <= 5; d++) for (const [s, e] of [['14:00', '15:00'], ['15:00', '16:00'], ['16:00', '17:00'], ['17:00', '18:00']]) slots.push({ day: d, start: s, end: e })
  for (const [s, e] of [['08:00', '09:00'], ['09:00', '10:00'], ['10:00', '11:00'], ['11:00', '12:00']]) slots.push({ day: 6, start: s, end: e })
  const lessons: Lesson[] = []
  const busy = new Set<string>()
  const tutorFor = (classId: string, subjectId: string) => {
    const g = classes.find((c) => c.id === classId)!.gradeId
    if (subjectId === 's-math') return g === 'g7' || g === 'gce' ? 't6' : 't1'
    return tutors.find((t) => t.subjectIds.includes(subjectId))!.id
  }
  classes.forEach((c, ci) => {
    const offered = subjects.filter((s) => s.gradeIds.includes(c.gradeId) && students.some((st) => st.classId === c.id && st.subjectIds.includes(s.id)))
    const items: string[] = []
    for (const s of offered) { items.push(s.id); if (s.id === 's-math' || s.id === 's-eng') items.push(s.id) }
    let cursor = ci * 2
    for (const subjectId of items) {
      const tutorId = tutorFor(c.id, subjectId)
      for (let k = 0; k < slots.length; k++) {
        const slot = slots[(cursor + k) % slots.length]
        const key = `${slot.day}|${slot.start}`
        const sameDaySame = lessons.some((l) => l.classId === c.id && l.day === slot.day && l.subjectId === subjectId)
        if (busy.has(`c:${c.id}|${key}`) || busy.has(`t:${tutorId}|${key}`) || busy.has(`r:${c.room}|${key}`) || sameDaySame) continue
        busy.add(`c:${c.id}|${key}`); busy.add(`t:${tutorId}|${key}`); busy.add(`r:${c.room}|${key}`)
        lessons.push({ id: `l${next('lesson')}`, classId: c.id, subjectId, tutorId, day: slot.day, start: slot.start, end: slot.end, room: c.room })
        cursor = (cursor + k + 5) % slots.length
        break
      }
    }
  })

  // ---------- attendance (last 6 weeks; today's first two sessions already marked) ----------
  const attendance: AttendanceRecord[] = []
  const absenteeism: Record<string, number> = {}
  for (const s of students) absenteeism[s.id] = ['s14', 's19', 's09'].includes(s.id) ? 0.24 : between(0.02, 0.11)
  for (let d = addDays(today, -42); d <= today; d = addDays(d, 1)) {
    const wd = isoWeekday(d)
    if (wd === 7) continue
    for (const l of lessons.filter((x) => x.day === wd)) {
      if (d === today && !['14:00', '15:00', '08:00', '09:00'].includes(l.start)) continue
      const roster = students.filter((s) => s.classId === l.classId && s.status === 'active' && s.subjectIds.includes(l.subjectId) && s.enrolmentDate <= d)
      for (const s of roster) {
        const x = r()
        const status = x < absenteeism[s.id] ? 'absent' : x < absenteeism[s.id] + 0.07 ? 'late' : 'present'
        attendance.push({ id: `a${next('att')}`, studentId: s.id, lessonId: l.id, date: d, status, recordedBy: l.tutorId, recordedAt: `${d}T${l.end}:00` })
      }
    }
  }

  // ---------- assessments ----------
  const sessions: { date: string; type: AssessmentType; title: string; max: number; grades?: string[] }[] = [
    { date: '2026-04-02', type: 'End of Term Exam', title: 'Term 1 examination', max: 100 },
    { date: '2026-05-29', type: 'Test', title: 'Term 2 test 1', max: 50 },
    { date: '2026-06-19', type: 'Assignment', title: 'Term 2 assignment', max: 20 },
    { date: '2026-07-31', type: 'End of Term Exam', title: 'Term 2 examination', max: 100 },
    { date: '2026-09-25', type: 'Test', title: 'Term 3 test 1', max: 50 },
    { date: '2026-10-16', type: 'Assignment', title: 'Term 3 assignment', max: 20 },
    { date: '2026-10-30', type: 'Mock Exam', title: 'Mock examination', max: 100, grades: ['g7', 'g9', 'g12', 'gce'] },
    { date: '2026-10-30', type: 'Test', title: 'Term 3 test 2', max: 50, grades: ['g8'] },
  ]
  const assessments: Assessment[] = []
  const ability: Record<string, number> = { s01: 70, s02: 52 }
  for (const s of students) {
    const base = ability[s.id] ?? between(42, 80)
    const offsets: Record<string, number> = {}
    s.subjectIds.forEach((sub) => (offsets[sub] = between(-9, 9)))
    let idx = 0
    for (const se of sessions) {
      if (se.date > today || se.date < s.enrolmentDate) continue
      if (se.grades && !se.grades.includes(s.gradeId)) continue
      if (s.status === 'inactive' && se.date > '2026-08-07') continue
      for (const sub of s.subjectIds) {
        const p = Math.max(18, Math.min(97, base + offsets[sub] + idx * 2.1 + between(-6, 6)))
        const marks = Math.round((p / 100) * se.max)
        const pctv = (marks / se.max) * 100
        assessments.push({
          id: `x${next('assess')}`, studentId: s.id, subjectId: sub, type: se.type, title: se.title, maxMarks: se.max, marks,
          date: se.date, term: termFor(se.date), tutorId: tutorFor(s.classId, sub),
          comment: pick(pctv >= 70 ? COMMENTS.high : pctv >= 50 ? COMMENTS.mid : COMMENTS.low),
        })
      }
      idx++
    }
  }

  // ---------- fees ----------
  const tuition: Record<string, number> = { g7: 850, g8: 1000, g9: 1000, g12: 1250, gce: 1400 }
  const feeStructures: FeeStructure[] = []
  for (const g of grades) {
    feeStructures.push({ id: `f-${g.id}-tui`, gradeId: g.id, category: 'Tuition', amount: tuition[g.id], frequency: 'per term', description: `${g.name} tuition (all enrolled subjects)` })
    feeStructures.push({ id: `f-${g.id}-reg`, gradeId: g.id, category: 'Registration', amount: 150, frequency: 'once', description: 'One-off registration fee' })
    if (['g9', 'g12', 'gce'].includes(g.id)) feeStructures.push({ id: `f-${g.id}-exm`, gradeId: g.id, category: 'Examination', amount: 100, frequency: 'per term', description: 'Mock examination fee (Term 3)' })
  }
  const charges: Charge[] = []
  for (const s of students) {
    if (s.enrolmentDate >= '2026-01-01')
      charges.push({ id: `ch${next('charge')}`, studentId: s.id, category: 'Registration', term: termFor(s.enrolmentDate), amount: 150, description: 'Registration fee', issuedOn: s.enrolmentDate, dueDate: s.enrolmentDate })
    for (const t of TERMS_2026) {
      if (t.start > today || t.end < s.enrolmentDate) continue
      if (s.status === 'inactive' && t.start > '2026-08-07') continue
      const issued = s.enrolmentDate > t.start ? s.enrolmentDate : t.start
      charges.push({ id: `ch${next('charge')}`, studentId: s.id, category: 'Tuition', term: t.name, amount: tuition[s.gradeId], description: `${t.name} tuition`, issuedOn: issued, dueDate: addDays(issued, 14) })
      if (t.name === 'Term 3 2026' && ['g9', 'g12', 'gce'].includes(s.gradeId))
        charges.push({ id: `ch${next('charge')}`, studentId: s.id, category: 'Examination', term: t.name, amount: 100, description: 'Mock examination fee', issuedOn: '2026-10-01', dueDate: '2026-10-23' })
    }
  }

  // ---------- payments ----------
  type Draft = Omit<Payment, 'reference' | 'receiptNo' | 'balanceAfter'>
  const drafts: Draft[] = []
  const methods: PaymentMethod[] = ['Mobile Money', 'Mobile Money', 'Mobile Money', 'Cash', 'Cash', 'Bank Transfer']
  const momoRef = () => `MP${Math.floor(between(10000000, 99999999))}.${Math.floor(between(1000, 9999))}`
  const pay = (s: Student, amount: number, date: string, category: Payment['category'], term: string, status: Payment['status'] = 'verified', method?: PaymentMethod) => {
    if (date > today || amount <= 0) return
    const m = method ?? pick(methods)
    const parentPhone = parents.find((x) => x.id === s.parentId)!.phone
    const online = m === 'Mobile Money' && status === 'verified' && date >= '2026-05-01' && r() < 0.55
    drafts.push({
      channel: online ? 'online' : 'office',
      network: m === 'Mobile Money' ? networkFromPhone(parentPhone) ?? 'Airtel' : undefined,
      payerPhone: m === 'Mobile Money' ? normalisePhone(parentPhone) ?? undefined : undefined,
      gatewayRef: online ? `GW-${Math.floor(between(10000000, 99999999))}` : undefined,
      gatewayStatus: online ? 'confirmed' : undefined,
      id: `pm${next('pm')}`, studentId: s.id, amount, date, method: m, category, term,
      externalRef: m === 'Mobile Money' ? momoRef() : m === 'Bank Transfer' ? `ZANACO-${Math.floor(between(100000, 999999))}` : undefined,
      recordedBy: online ? 'Parent portal' : m === 'Cash' ? 'Centre Administrator' : 'Accounts Office', recordedAt: `${date}T${String(Math.floor(between(8, 17))).padStart(2, '0')}:${String(Math.floor(between(0, 59))).padStart(2, '0')}:00`,
      status, verifiedBy: status === 'verified' ? (online ? 'Payment gateway' : 'Centre Administrator') : undefined,
      verifiedAt: status === 'verified' ? `${date}T17:30:00` : undefined,
    })
  }
  for (const s of students) {
    for (const c of charges.filter((x) => x.studentId === s.id)) {
      if (c.category === 'Registration') { pay(s, c.amount, c.issuedOn, 'Registration', c.term, 'verified', pick(['Cash', 'Mobile Money'])); continue }
      if (s.id === 's02' && c.term === 'Term 3 2026') { pay(s, 400, '2026-09-14', 'Tuition', c.term, 'verified', 'Mobile Money'); pay(s, 200, '2026-10-09', 'Tuition', c.term, 'verified', 'Cash'); continue }
      if (s.id === 's01' && c.category === 'Examination') continue
      if (s.id === 's01' && c.term === 'Term 3 2026') { pay(s, 1250, '2026-09-10', 'Tuition', c.term, 'verified', 'Bank Transfer'); continue }
      const isT3 = c.term === 'Term 3 2026'
      const roll = r()
      if (!isT3 || roll < 0.45) {
        if (c.category !== 'Tuition' || r() < 0.7) pay(s, c.amount, addDays(c.issuedOn, Math.floor(between(0, 20))), c.category, c.term)
        else {
          const first = Math.round((c.amount * 0.6) / 50) * 50
          pay(s, first, addDays(c.issuedOn, Math.floor(between(0, 10))), c.category, c.term)
          pay(s, c.amount - first, addDays(c.issuedOn, Math.floor(between(25, 45))), c.category, c.term)
        }
      } else if (roll < 0.8) {
        const part = Math.round((c.amount * between(0.4, 0.75)) / 50) * 50
        pay(s, part, addDays(c.issuedOn, Math.floor(between(2, 25))), c.category, c.term)
      }
    }
  }
  // payments awaiting verification (mobile money reported by parents, not yet confirmed against the statement)
  const pendingFor = ['s13', 's18', 's23']
  pendingFor.forEach((sid, i) => {
    const s = students.find((x) => x.id === sid)!
    pay(s, [300, 500, 400][i], addDays(today, -(i + 1)), 'Tuition', 'Term 3 2026', 'pending', 'Mobile Money')
  })
  drafts.sort((a, b) => (a.date + a.recordedAt).localeCompare(b.date + b.recordedAt))
  const paidSoFar: Record<string, number> = {}
  const payments: Payment[] = drafts.map((d) => {
    const ref = `PAY-2026-${String(next('payref')).padStart(4, '0')}`
    if (d.status !== 'verified') return { ...d, reference: ref, balanceAfter: 0 }
    paidSoFar[d.studentId] = (paidSoFar[d.studentId] ?? 0) + d.amount
    const billed = charges.filter((c) => c.studentId === d.studentId && c.issuedOn <= d.date).reduce((a, c) => a + c.amount, 0)
    return { ...d, reference: ref, receiptNo: `RCT-2026-${String(next('receipt')).padStart(4, '0')}`, balanceAfter: Math.max(0, billed - paidSoFar[d.studentId]) }
  })
  for (const p of payments.filter((x) => x.status === 'pending')) {
    const billed = charges.filter((c) => c.studentId === p.studentId).reduce((a, c) => a + c.amount, 0)
    p.balanceAfter = Math.max(0, billed - (paidSoFar[p.studentId] ?? 0) - p.amount)
  }

  // ---------- announcements, materials, audit ----------
  const ann = (title: string, body: string, audience: Announcement['audience'], daysAgo: number, authorId: string, authorName: string, priority: Announcement['priority'] = 'normal', classId?: string, sms = false): Announcement =>
    ({ id: `an${next('ann')}`, title, body, audience, classId, priority, authorId, authorName, createdAt: `${addDays(today, -daysAgo)}T09:${String(10 + daysAgo).padStart(2, '0')}:00`, channels: { inApp: true, sms, whatsapp: false } })
  const announcements: Announcement[] = [
    ann('Term 3 fee balances', 'Parents with outstanding Term 3 balances are kindly asked to clear them before the end-of-term examinations. Mobile Money payments must quote the student number as the reference.', 'parents', 2, 'admin', 'Centre Administrator', 'important', undefined, true),
    ann('Saturday revision sessions', 'Revision sessions for Grade 9, Grade 12 and GCE candidates run every Saturday from 08:00 until the national examinations. Bring your past papers.', 'students', 4, 'admin', 'Centre Administrator'),
    ann('Mock examination results released', 'Mock examination marks have been uploaded. Parents can view results and tutor comments in the parent portal.', 'everyone', 9, 'admin', 'Centre Administrator', 'important'),
    ann('Grade 12 A — Biology practical', 'Please revise the topics on nutrition in plants and transport in mammals before Thursday. We will work through past paper practical questions.', 'class', 3, 't3', 'Kelvin Tembo', 'normal', 'c-g12a'),
    ann('Tutor meeting on Friday', 'All tutors: short staff meeting on Friday at 18:15 to review Term 3 attendance and the examination timetable.', 'tutors', 5, 'admin', 'Centre Administrator'),
    ann('Parents meeting', 'A parents meeting will be held at the centre on the last Saturday of the month at 10:00. We will discuss progress reports and next year’s enrolment.', 'parents', 12, 'admin', 'Centre Administrator'),
  ]
  const mat = (title: string, description: string, kind: Material['kind'], subjectId: string, classId: string, tutorId: string, daysAgo: number, content?: string): Material =>
    ({ id: `m${next('mat')}`, title, description, kind, subjectId, classId, tutorId, content, createdAt: `${addDays(today, -daysAgo)}T16:00:00` })
  const materials: Material[] = [
    mat('Quadratic equations — summary notes', 'Factorisation, completing the square and the quadratic formula with worked examples.', 'Notes', 's-math', 'c-g12a', 't1', 6,
      'QUADRATIC EQUATIONS\n\n1. Standard form: ax² + bx + c = 0\n2. Factorisation: find two numbers that multiply to ac and add to b.\n3. Completing the square: x² + bx = (x + b/2)² − (b/2)²\n4. Quadratic formula: x = (−b ± √(b² − 4ac)) / 2a\n5. Discriminant: b² − 4ac > 0 two real roots; = 0 one root; < 0 no real roots.\n\nPractice: solve 2x² − 7x + 3 = 0 using all three methods.'),
    mat('Algebra worksheet 4', 'Simplifying expressions and linear equations. Answers will be discussed on Monday.', 'Worksheet', 's-math', 'c-g8a', 't1', 3,
      'ALGEBRA WORKSHEET 4\n\n1. Simplify 3a + 5b − a + 2b\n2. Expand 4(2x − 3)\n3. Solve 5x − 7 = 18\n4. Solve 3(x + 2) = 2x + 11\n5. A number is doubled and 9 is added. The result is 31. Find the number.'),
    mat('Comprehension practice — Grade 9', 'Reading passage with questions in the Grade 9 examination format.', 'Worksheet', 's-eng', 'c-g9a', 't2', 8,
      'Read the passage carefully and answer all questions in full sentences. Underline the key words in each question before you answer.'),
    mat('Photosynthesis revision notes', 'Key definitions, word equation and limiting factors.', 'Notes', 's-bio', 'c-g12a', 't3', 10,
      'PHOTOSYNTHESIS\n\nWord equation: carbon dioxide + water → glucose + oxygen (in the presence of light and chlorophyll)\nLimiting factors: light intensity, carbon dioxide concentration, temperature.\nTest for starch: iodine solution turns blue-black.'),
    mat('Civic Education — the Constitution of Zambia', 'Summary of the structure of government and the Bill of Rights.', 'Notes', 's-civ', 'c-g12a', 't4', 14,
      'Three arms of government: the Executive, the Legislature and the Judiciary.\nThe Bill of Rights (Part III) protects fundamental rights and freedoms.\nRevise: separation of powers and checks and balances.'),
    mat('Spreadsheet basics', 'Cells, formulas and charts for Computer Studies practicals.', 'Notes', 's-cs', 'c-gcea', 't5', 7,
      'SPREADSHEETS\n\nA cell reference combines a column letter and a row number, e.g. B4.\nFormulas start with = e.g. =SUM(B2:B10), =AVERAGE(C2:C10).\nAbsolute references use $, e.g. =$B$1*C2.'),
    mat('Fractions and decimals practice', 'Grade 7 practice set for the composite examination.', 'Worksheet', 's-math', 'c-g7a', 't6', 5,
      '1. Convert 3/8 to a decimal.\n2. Add 2/3 + 1/4.\n3. Write 0.45 as a fraction in its simplest form.\n4. A bag holds 2.5 kg of sugar. How many 250 g packets can be filled?'),
    mat('Double-entry bookkeeping', 'The ledger, trial balance and common errors.', 'Notes', 's-acc', 'c-g12a', 't6', 11,
      'Every transaction has two entries: a debit and a credit of equal value.\nThe trial balance checks arithmetical accuracy but does not reveal errors of omission, commission, principle or compensating errors.'),
  ]
  const audit: AuditEntry[] = [
    { id: `au${next('audit')}`, at: `${addDays(today, -1)}T17:31:00`, actorId: 'admin', actorName: 'Centre Administrator', action: 'payment.verified', entity: 'payment', entityId: payments.filter((p) => p.status === 'verified').slice(-1)[0]?.reference ?? '', detail: 'Verified against Mobile Money statement' },
    { id: `au${next('audit')}`, at: `${addDays(today, -2)}T10:05:00`, actorId: 'admin', actorName: 'Centre Administrator', action: 'announcement.created', entity: 'announcement', entityId: announcements[0].id, detail: 'Term 3 fee balances (parents)' },
    { id: `au${next('audit')}`, at: `${addDays(today, -6)}T15:12:00`, actorId: 'admin', actorName: 'Centre Administrator', action: 'student.updated', entity: 'student', entityId: 's16', detail: 'Updated subjects for Chileshe Musonda' },
  ]

  // ---------- admissions pipeline (enquiries) ----------
  const L = (childName: string, gradeId: string, subjectIds: string[], parentName: string, phone: string, source: Lead['source'], daysAgo: number, stage: Lead['stage'], extra: Partial<Lead> = {}): Lead =>
    ({ id: `ld${next('lead')}`, childName, gradeId, subjectIds, parentName, phone, source, stage, createdAt: `${addDays(today, -daysAgo)}T10:00:00`, notes: '', ...extra })
  const leads: Lead[] = [
    L('Faith Chirwa', 'g12', ['s-math', 's-bio'], 'Loveness Chirwa', '0974 288 519', 'Referral', 48, 'enrolled', { referredByParentId: 'p03', studentId: 's20', notes: 'Referred by Esther Phiri.' }),
    L('Peter Nkonde', 'gce', ['s-math'], 'Kennedy Nkonde', '0968 517 220', 'Facebook', 75, 'enrolled', { studentId: 's24' }),
    L('Chileshe Musonda', 'g9', ['s-math', 's-isc'], 'Florence Musonda', '0779 560 247', 'Walk-in', 70, 'enrolled', { studentId: 's16' }),
    L('Mwenya Kabwe', 'g8', ['s-math', 's-eng'], 'Beatrice Kabwe', '0962 784 450', 'Flyer', 77, 'enrolled', { studentId: 's12' }),
    L('Bupe Mwale', 'g12', ['s-math', 's-sci', 's-acc'], 'Grace Mwale', '0977 334 120', 'WhatsApp', 2, 'new', { notes: 'Asked about evening classes.' }),
    L('Kasonde Zulu', 'g9', ['s-math', 's-eng', 's-isc'], 'Rose Zulu', '0966 902 113', 'Facebook', 4, 'new'),
    L('Joseph Tembo', 'g7', ['s-math', 's-eng'], 'Agnes Tembo', '0955 610 247', 'Referral', 6, 'contacted', { referredByParentId: 'p01', followUpOn: addDays(today, 1), notes: 'Mutale Banda’s neighbour. Wants Grade 7 exam preparation.' }),
    L('Lweendo Hachinga', 'g12', ['s-math', 's-civ', 's-his'], 'Mary Hachinga', '0976 225 801', 'School visit', 9, 'contacted', { followUpOn: addDays(today, -1) }),
    L('Thoko Banda', 'g8', ['s-math', 's-eng', 's-cs'], 'Jane Banda', '0977 508 330', 'Walk-in', 11, 'trial', { followUpOn: addDays(today, 2), notes: 'Trial Mathematics lesson booked.' }),
    L('Nchimunya Moonga', 'gce', ['s-eng', 's-com'], 'Nchimunya Moonga', '0965 120 774', 'Facebook', 13, 'trial', { followUpOn: today }),
    L('Daliso Phiri', 'g9', ['s-math'], 'Martha Phiri', '0954 731 902', 'Flyer', 18, 'lost', { lostReason: 'Fees too high' }),
    L('Kabwe Sichone', 'g12', ['s-math', 's-bio'], 'Ruth Sichone', '0978 341 660', 'WhatsApp', 25, 'lost', { lostReason: 'Chose another centre' }),
    L('Natasha Mumba', 'g7', ['s-math', 's-eng', 's-isc'], 'Peter Mumba', '0966 455 118', 'Referral', 30, 'contacted', { referredByParentId: 'p05' }),
    L('Isaac Chola', 'g8', ['s-math', 's-isc'], 'Ireen Chola', '0955 003 816', 'Website', 1, 'new'),
  ]
  const referralCodes: Record<string, string> = {}
  parents.forEach((p, i) => (referralCodes[p.id] = `BI-${p.name.split(' ').slice(-1)[0].slice(0, 3).toUpperCase()}${String(i + 11).padStart(2, '0')}`))

  return {
    version: SEED_VERSION,
    generatedAt: new Date().toISOString(),
    settings: {
      centreName: 'Breath It Tuition Centre',
      tagline: 'Helping every learner become the best they can be',
      address: 'Kaunda Square Stage Two, Lusaka, Zambia',
      phone: '0971 207 948',
      email: 'breathittuitions@gmail.com',
      currency: 'ZMW',
      currentTerm: termFor(today),
      terms: TERMS_2026,
      receiptFooter: 'Thank you for your payment. Please keep this receipt as proof of payment.',
      smsProvider: null,
      whatsappProvider: null,
      lowAttendanceThreshold: 80,
      showFeesToStudents: true,
      brand: { primary: '#493a8f', logoDataUrl: null },
      onlinePayments: {
        enabled: true, gateway: null,
        methods: { airtel: true, mtn: true, zamtel: true, card: true, bank: true },
        passFeeToPayer: false, feePercent: 2.5,
        bank: { bankName: 'To be confirmed', accountName: 'Breath It Tuition Centre', accountNumber: 'To be confirmed', branch: 'To be confirmed' },
      },
      referralReward: 100,
      reminderTemplate: 'Good day {parent}. This is a friendly reminder from Breath It Tuition Centre that {child} has a balance of {balance} for {term}. You can pay with Airtel Money, MTN MoMo, Zamtel Kwacha or bank in the parent portal, or at the office. Thank you.',
    },
    grades, subjects, parents, tutors, classes, students, enrolmentEvents, lessons, attendance, assessments,
    feeStructures, charges, payments, announcements, materials, audit, leads, reminders: [], referralCodes, counters,
  }
}
