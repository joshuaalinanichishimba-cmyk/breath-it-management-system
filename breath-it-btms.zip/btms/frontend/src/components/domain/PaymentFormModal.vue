<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import Modal from '@/components/ui/Modal.vue'
import StudentPicker from './StudentPicker.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import type { FeeCategory, MobileNetwork, Payment, PaymentMethod } from '@/types'
import { iso } from '@/services/dates'
import { kwacha, round2 } from '@/services/format'

const props = defineProps<{ open: boolean; studentId?: string }>()
const emit = defineEmits<{ close: []; saved: [p: Payment] }>()
const store = useDb(); const ui = useUi()
const blank = () => ({ studentId: props.studentId ?? '', term: store.db.settings.currentTerm, category: 'Tuition' as FeeCategory, amount: null as number | null, date: iso(), method: 'Mobile Money' as PaymentMethod, network: 'Airtel' as MobileNetwork, externalRef: '', notes: '', verifyNow: false })
const f = reactive(blank())
const error = ref('')
watch(() => props.open, (o) => { if (o) { Object.assign(f, blank()); error.value = '' } })

const termBalance = computed(() => (f.studentId ? store.balance(f.studentId, f.term) : 0))
const totalBalance = computed(() => (f.studentId ? store.balance(f.studentId) : 0))
const after = computed(() => round2(termBalance.value - (Number(f.amount) || 0)))
const pending = computed(() => (f.studentId ? store.pendingAmount(f.studentId) : 0))
const activeStudents = computed(() => store.db.students.filter((s) => s.status !== 'completed'))

function save() {
  error.value = ''
  if (!f.studentId) return (error.value = 'Choose a student.')
  if (!f.amount || f.amount <= 0) return (error.value = 'Enter an amount greater than zero.')
  if (f.date > iso()) return (error.value = 'Payment date cannot be in the future.')
  try {
    const p = store.recordPayment({ studentId: f.studentId, amount: round2(Number(f.amount)), date: f.date, method: f.method, category: f.category, term: f.term, externalRef: f.externalRef, notes: f.notes, network: f.method === 'Mobile Money' ? f.network : undefined }, f.verifyNow)
    ui.success(p.status === 'verified' ? 'Payment recorded and verified' : 'Payment recorded', p.status === 'verified' ? `Receipt ${p.receiptNo} is ready.` : 'It will count toward the balance once verified.')
    emit('saved', p); emit('close')
  } catch (e) { error.value = (e as Error).message }
}
</script>
<template>
  <Modal :open="open" title="Record a payment" sub="Payments only reduce a balance once the money is confirmed as received." size="lg" @close="emit('close')">
    <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
      <div class="sm:col-span-2">
        <label class="label">Student</label>
        <StudentPicker v-if="!studentId" v-model="f.studentId" :students="activeStudents" />
        <div v-else class="input flex items-center bg-sunken">{{ store.studentName(studentId) }}</div>
      </div>
      <div><label class="label" for="pm-term">Term</label>
        <select id="pm-term" v-model="f.term" class="select"><option v-for="t in store.db.settings.terms" :key="t.name">{{ t.name }}</option></select></div>
      <div><label class="label" for="pm-cat">Fee category</label>
        <select id="pm-cat" v-model="f.category" class="select"><option>Tuition</option><option>Registration</option><option>Examination</option><option>Materials</option></select></div>
      <div><label class="label" for="pm-amt">Amount (K)</label><input id="pm-amt" v-model.number="f.amount" type="number" min="0" step="0.01" class="input tnum" placeholder="0.00" /></div>
      <div><label class="label" for="pm-date">Payment date</label><input id="pm-date" v-model="f.date" type="date" :max="iso()" class="input" /></div>
      <div><label class="label" for="pm-method">Method</label>
        <select id="pm-method" v-model="f.method" class="select"><option>Mobile Money</option><option>Cash</option><option>Bank Transfer</option><option value="Card">Bank card (POS)</option></select></div>
      <div v-if="f.method === 'Mobile Money'"><label class="label" for="pm-net">Network</label>
        <select id="pm-net" v-model="f.network" class="select"><option value="Airtel">Airtel Money</option><option value="MTN">MTN MoMo</option><option value="Zamtel">Zamtel Kwacha</option></select></div>
      <div v-if="f.method !== 'Cash'"><label class="label" for="pm-ref">{{ f.method === 'Mobile Money' ? 'Transaction ID' : 'Bank reference' }}</label>
        <input id="pm-ref" v-model="f.externalRef" class="input" :placeholder="f.method === 'Mobile Money' ? 'e.g. MP26111.1532.A41820' : 'e.g. deposit slip number'" /></div>
      <div class="sm:col-span-2"><label class="label" for="pm-notes">Notes (optional)</label><input id="pm-notes" v-model="f.notes" class="input" placeholder="e.g. paid by grandmother" /></div>

      <div v-if="f.studentId" class="sm:col-span-2 rounded-lg bg-sunken/70 border border-line p-3 grid grid-cols-3 gap-3 text-[12.5px]">
        <div><div class="text-muted">{{ f.term }} balance</div><div class="font-semibold text-[15px] tnum">{{ kwacha(termBalance) }}</div></div>
        <div><div class="text-muted">After this payment</div><div :class="['font-semibold text-[15px] tnum', after < 0 ? 'text-warn' : '']">{{ kwacha(after) }}</div></div>
        <div><div class="text-muted">Whole account</div><div class="font-semibold text-[15px] tnum">{{ kwacha(totalBalance) }}</div></div>
        <p v-if="after < 0" class="col-span-3 text-warn">This is more than the term balance; the extra will show as credit on the account.</p>
        <p v-if="pending" class="col-span-3 text-muted">{{ kwacha(pending) }} from earlier payments is still awaiting verification.</p>
      </div>

      <label class="sm:col-span-2 flex items-start gap-2.5 text-[13px] cursor-pointer">
        <input v-model="f.verifyNow" type="checkbox" class="mt-0.5 h-4 w-4 accent-[rgb(var(--brand))]" />
        <span><span class="font-medium">I have confirmed the money was received</span><br />
          <span class="text-muted">{{ f.method === 'Cash' ? 'Cash counted and in the cash box.' : f.method === 'Mobile Money' ? 'Transaction ID matched on the Mobile Money statement.' : 'Deposit visible on the bank statement.' }} A receipt is issued only for verified payments.</span></span>
      </label>
      <p v-if="error" class="sm:col-span-2 field-error text-[13px]">{{ error }}</p>
      <button type="submit" class="hidden" />
    </form>
    <template #footer>
      <button class="btn btn-secondary" @click="emit('close')">Cancel</button>
      <button class="btn btn-primary" @click="save">{{ f.verifyNow ? 'Record and verify' : 'Record payment' }}</button>
    </template>
  </Modal>
</template>
