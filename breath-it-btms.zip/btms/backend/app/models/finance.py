from datetime import date, datetime
from decimal import Decimal
from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db import Base, new_id
from .users import utcnow


class FeeStructure(Base):
    __tablename__ = "fee_structures"
    id: Mapped[str] = mapped_column(String(60), primary_key=True, default=lambda: new_id("f-"))
    grade_id: Mapped[str] = mapped_column(ForeignKey("grades.id", ondelete="CASCADE"), index=True)
    category: Mapped[str] = mapped_column(String(20))  # Tuition | Registration | Examination | Materials
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    frequency: Mapped[str] = mapped_column(String(10))  # per term | once
    description: Mapped[str] = mapped_column(String(160), default="")
    __table_args__ = (UniqueConstraint("grade_id", "category", name="uq_fee_grade_category"), CheckConstraint("amount >= 0", name="ck_fee_amount"))


class Charge(Base):
    """An amount billed to a student's account (the 'invoice' side of the ledger)."""
    __tablename__ = "charges"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("ch-"))
    student_id: Mapped[str] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    category: Mapped[str] = mapped_column(String(20))
    term: Mapped[str] = mapped_column(String(30), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    description: Mapped[str] = mapped_column(String(160))
    issued_on: Mapped[date] = mapped_column(Date)
    due_date: Mapped[date] = mapped_column(Date)
    # Discounts (e.g. referral rewards) are negative charges; everything else must be positive
    __table_args__ = (CheckConstraint("(category = 'Discount' AND amount < 0) OR (category <> 'Discount' AND amount > 0)", name="ck_charge_amount"),)


class Payment(Base):
    """A payment record. It reduces the balance ONLY once status = 'verified'."""
    __tablename__ = "payments"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("pm-"))
    reference: Mapped[str] = mapped_column(String(20), unique=True)
    student_id: Mapped[str] = mapped_column(ForeignKey("students.id"), index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2))
    payment_date: Mapped[date] = mapped_column(Date, index=True)
    method: Mapped[str] = mapped_column(String(20))  # Cash | Mobile Money | Bank Transfer | Card
    channel: Mapped[str] = mapped_column(String(8), default="office")  # office | online (paid by the parent through the gateway)
    network: Mapped[str | None] = mapped_column(String(8), nullable=True)  # Airtel | MTN | Zamtel
    payer_phone: Mapped[str | None] = mapped_column(String(15), nullable=True)
    gateway_ref: Mapped[str | None] = mapped_column(String(80), nullable=True, unique=True)
    gateway_status: Mapped[str | None] = mapped_column(String(20), nullable=True)  # awaiting_customer | confirmed | declined | timed_out
    category: Mapped[str] = mapped_column(String(20))
    term: Mapped[str] = mapped_column(String(30), index=True)
    external_ref: Mapped[str | None] = mapped_column(String(60), nullable=True, unique=True)
    status: Mapped[str] = mapped_column(String(10), default="pending", index=True)  # pending | verified | rejected
    recorded_by: Mapped[str] = mapped_column(String(120))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    verified_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    balance_after: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=0)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    receipt: Mapped["Receipt | None"] = relationship(back_populates="payment", uselist=False)
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_payment_amount"),
        CheckConstraint("status IN ('pending','verified','rejected')", name="ck_payment_status"),
        CheckConstraint("method IN ('Cash','Mobile Money','Bank Transfer','Card')", name="ck_payment_method"),
        CheckConstraint("network IS NULL OR network IN ('Airtel','MTN','Zamtel')", name="ck_payment_network"),
    )


class Receipt(Base):
    __tablename__ = "receipts"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("rc-"))
    receipt_no: Mapped[str] = mapped_column(String(20), unique=True)
    payment_id: Mapped[str] = mapped_column(ForeignKey("payments.id", ondelete="CASCADE"), unique=True)
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    issued_by: Mapped[str] = mapped_column(String(120))
    payment: Mapped[Payment] = relationship(back_populates="receipt")
