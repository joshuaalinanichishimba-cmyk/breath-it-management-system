/**
 * Saves a generated file.
 *  - Normal browsers (GitHub Pages, local dev): standard Blob download.
 *  - Inside the claude.ai hosted preview: uses the viewer's "downloads" capability, which asks the viewer to confirm.
 */
interface DownloadsCap { save: (r: { filename: string; data: Blob | string }) => Promise<unknown> }
type ClaudeHost = { claude?: { use: (name: string) => Promise<unknown> } }

let cap: Promise<DownloadsCap | null> | null = null
function hostDownloads(): Promise<DownloadsCap | null> {
  const w = window as unknown as ClaudeHost
  if (!w.claude?.use) return Promise.resolve(null)
  cap ??= w.claude.use('downloads').then((x) => (x as DownloadsCap) ?? null).catch(() => null)
  return cap
}

export async function saveFile(filename: string, data: Blob | string, mime = 'text/plain'): Promise<'saved' | 'declined'> {
  const host = await hostDownloads()
  if (host) {
    try { await host.save({ filename, data }); return 'saved' }
    catch (e) {
      const code = (e as { code?: string })?.code
      if (code === 'declined') return 'declined'
      throw new Error('Downloads are not available in this view. Open the GitHub Pages version to download files.')
    }
  }
  const blob = typeof data === 'string' ? new Blob([data], { type: mime }) : data
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.rel = 'noopener'
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 4000)
  return 'saved'
}

export function toCsv(headers: string[], rows: (string | number | null | undefined)[][]): string {
  const esc = (v: string | number | null | undefined) => {
    const s = v === null || v === undefined ? '' : String(v)
    return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
  }
  return '\uFEFF' + [headers, ...rows].map((r) => r.map(esc).join(',')).join('\r\n')
}
