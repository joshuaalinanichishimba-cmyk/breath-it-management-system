from datetime import date, timedelta
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ...db import get_db
from ...deps import current_user, require_roles, client_ip
from ...models import Assessment, AttendanceRecord, ClassGroup, ExaminationResult, Student, Subject, TimetableSlot, User, student_subjects
from ...schemas.records import AssessmentIn, AttendanceOut, RegisterIn, RegisterResult, ResultOut, ResultUpdate
from ...services.access import ensure_tutor_teaches, visible_student_ids
from ...services.audit import audit
from .people import term_for
from .serializers import result_out

router = APIRouter(tags=["attendance & assessments"])
staff = require_roles("admin", "tutor")


def roster(db: Session, slot: TimetableSlot, on: date) -> list[Student]:
    return list(db.scalars(
        select(Student).join(student_subjects, student_subjects.c.student_id == Student.id)
        .where(Student.class_id == slot.class_id, Student.status == "active", Student.enrolment_date <= on, student_subjects.c.subject_id == slot.subject_id)
        .order_by(Student.last_name, Student.first_name)
    ))


@router.get("/attendance/register")
def get_register(slot_id: str, lesson_date: date, user: User = Depends(staff), db: Session = Depends(get_db)):
    slot = db.get(TimetableSlot, slot_id)
    if not slot:
        raise HTTPException(404, "Lesson not found.")
    ensure_tutor_teaches(db, user, slot)
    existing = {r.student_id: r.status for r in db.scalars(select(AttendanceRecord).where(AttendanceRecord.slot_id == slot_id, AttendanceRecord.lesson_date == lesson_date))}
    return {"submitted": bool(existing), "students": [{"id": s.id, "name": s.full_name, "status": existing.get(s.id)} for s in roster(db, slot, lesson_date)]}


@router.post("/attendance/register", response_model=RegisterResult)
def submit_register(body: RegisterIn, request: Request, user: User = Depends(staff), db: Session = Depends(get_db)):
    """Upsert: the unique (student, lesson, date) constraint makes duplicate attendance impossible; resubmitting corrects marks."""
    slot = db.get(TimetableSlot, body.slot_id)
    if not slot:
        raise HTTPException(404, "Lesson not found.")
    ensure_tutor_teaches(db, user, slot)
    if body.lesson_date > date.today():
        raise HTTPException(422, "You cannot take a register for a future date.")
    if body.lesson_date.isoweekday() != slot.day_of_week:
        raise HTTPException(422, "That date is not a day this lesson runs.")
    allowed = {s.id for s in roster(db, slot, body.lesson_date)}
    unknown = [m.student_id for m in body.marks if m.student_id not in allowed]
    if unknown:
        raise HTTPException(422, f"{len(unknown)} student(s) are not on this lesson's register.")
    created = updated = 0
    for m in body.marks:
        rec = db.scalar(select(AttendanceRecord).where(AttendanceRecord.slot_id == slot.id, AttendanceRecord.lesson_date == body.lesson_date, AttendanceRecord.student_id == m.student_id))
        if rec:
            if rec.status != m.status:
                rec.status = m.status; rec.recorded_by = user.id; updated += 1
        else:
            db.add(AttendanceRecord(student_id=m.student_id, slot_id=slot.id, lesson_date=body.lesson_date, status=m.status, recorded_by=user.id)); created += 1
    audit(db, user, "attendance.submitted" if created else "attendance.corrected", "register", slot.id, f"{body.lesson_date}: {created} new, {updated} changed", client_ip(request))
    db.commit()
    return RegisterResult(created=created, updated=updated)


@router.get("/attendance/summary")
def attendance_summary(date_from: date, date_to: date, user: User = Depends(staff), db: Session = Depends(get_db)):
    q = select(AttendanceRecord.student_id, AttendanceRecord.status, func.count()).where(AttendanceRecord.lesson_date.between(date_from, date_to))
    if user.role == "tutor":
        q = q.join(TimetableSlot, TimetableSlot.id == AttendanceRecord.slot_id).where(TimetableSlot.tutor_id == user.tutor_id)
    per: dict[str, dict[str, int]] = {}
    for sid, st, n in db.execute(q.group_by(AttendanceRecord.student_id, AttendanceRecord.status)):
        per.setdefault(sid, {"present": 0, "late": 0, "absent": 0})[st] = n
    rows = []
    for sid, c in per.items():
        total = sum(c.values())
        rows.append({"student_id": sid, **c, "total": total, "rate": round((c["present"] + c["late"]) / total * 100, 1)})
    rows.sort(key=lambda r: r["rate"])
    total = sum(r["total"] for r in rows)
    attended = sum(r["present"] + r["late"] for r in rows)
    return {"rate": round(attended / total * 100, 1) if total else None, "records": total, "students": rows}


# ---------------- assessments ----------------
@router.post("/assessments", response_model=list[ResultOut], status_code=201)
def record_assessment(body: AssessmentIn, request: Request, user: User = Depends(staff), db: Session = Depends(get_db)):
    if body.assessment_date > date.today():
        raise HTTPException(422, "The assessment date cannot be in the future.")
    slot = db.scalar(select(TimetableSlot).where(TimetableSlot.class_id == body.class_id, TimetableSlot.subject_id == body.subject_id,
                                                 *( [TimetableSlot.tutor_id == user.tutor_id] if user.role == "tutor" else [] )).limit(1))
    if not slot:
        raise HTTPException(403 if user.role == "tutor" else 422, "This subject is not taught to this class" + (" by you." if user.role == "tutor" else "."))
    if db.scalar(select(Assessment.id).where(Assessment.class_id == body.class_id, Assessment.subject_id == body.subject_id, Assessment.title == body.title.strip(), Assessment.assessment_date == body.assessment_date)):
        raise HTTPException(409, "Marks for this assessment already exist. Edit the existing results instead.")
    eligible = {s.id for s in db.scalars(select(Student).join(student_subjects, student_subjects.c.student_id == Student.id).where(Student.class_id == body.class_id, student_subjects.c.subject_id == body.subject_id))}
    for r in body.results:
        if r.student_id not in eligible:
            raise HTTPException(422, "A student in the list does not take this subject in this class.")
        if r.marks > body.max_marks:
            raise HTTPException(422, f"Marks cannot exceed the maximum of {body.max_marks}.")
    a = Assessment(class_id=body.class_id, subject_id=body.subject_id, tutor_id=slot.tutor_id, assessment_type=body.assessment_type, title=body.title.strip(),
                   max_marks=body.max_marks, assessment_date=body.assessment_date, term=term_for(db, body.assessment_date))
    a.results = [ExaminationResult(student_id=r.student_id, marks=r.marks, comment=r.comment.strip()) for r in body.results]
    db.add(a); db.flush()
    subj = db.get(Subject, body.subject_id)
    audit(db, user, "assessment.recorded", "assessment", a.id, f"{a.title} — {subj.name} ({len(a.results)} students)", client_ip(request))
    db.commit()
    return [result_out(r) for r in a.results]


@router.get("/assessments/results", response_model=list[ResultOut])
def list_results(class_id: str | None = None, subject_id: str | None = None, term: str | None = None, user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(ExaminationResult).join(Assessment)
    allowed = visible_student_ids(db, user)
    if allowed is not None:
        q = q.where(ExaminationResult.student_id.in_(allowed or {""}))
    if user.role == "tutor":
        q = q.where(Assessment.tutor_id == user.tutor_id)
    if class_id: q = q.where(Assessment.class_id == class_id)
    if subject_id: q = q.where(Assessment.subject_id == subject_id)
    if term: q = q.where(Assessment.term == term)
    return [result_out(r) for r in db.scalars(q.order_by(Assessment.assessment_date.desc()))]


def _own_result(db: Session, user: User, result_id: str) -> ExaminationResult:
    r = db.get(ExaminationResult, result_id)
    if not r or (user.role == "tutor" and r.assessment.tutor_id != user.tutor_id):
        raise HTTPException(404, "Result not found.")
    return r


@router.patch("/assessments/results/{result_id}", response_model=ResultOut)
def update_result(result_id: str, body: ResultUpdate, request: Request, user: User = Depends(staff), db: Session = Depends(get_db)):
    r = _own_result(db, user, result_id)
    if body.marks is not None:
        if body.marks > r.assessment.max_marks:
            raise HTTPException(422, "Marks exceed the maximum for this assessment.")
        r.marks = body.marks
    if body.comment is not None:
        r.comment = body.comment
    audit(db, user, "assessment.updated", "result", r.id, r.assessment.title, client_ip(request)); db.commit()
    return result_out(r)


@router.delete("/assessments/results/{result_id}", status_code=204)
def delete_result(result_id: str, request: Request, user: User = Depends(staff), db: Session = Depends(get_db)):
    r = _own_result(db, user, result_id)
    audit(db, user, "assessment.deleted", "result", r.id, r.assessment.title, client_ip(request))
    db.delete(r); db.commit()
