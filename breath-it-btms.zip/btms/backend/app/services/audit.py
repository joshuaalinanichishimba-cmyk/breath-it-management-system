from sqlalchemy.orm import Session
from ..models import AuditLog, User


def audit(db: Session, user: User, action: str, entity: str, entity_id: str = "", detail: str = "", ip: str | None = None) -> None:
    """Adds an audit entry to the current transaction (committed together with the change it describes)."""
    db.add(AuditLog(actor_id=user.id, actor_name=user.name, action=action, entity=entity, entity_id=entity_id, detail=detail, ip_address=ip))
