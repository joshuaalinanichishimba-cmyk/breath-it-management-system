from ...models import ExaminationResult, Payment
from ...schemas.records import ResultOut
from ...schemas.finance import PaymentOut


def result_out(r: ExaminationResult) -> ResultOut:
    a = r.assessment
    return ResultOut(id=r.id, assessment_id=a.id, student_id=r.student_id, subject_id=a.subject_id, assessment_type=a.assessment_type,
                     title=a.title, assessment_date=a.assessment_date, term=a.term, marks=float(r.marks), max_marks=float(a.max_marks),
                     percentage=r.percentage, comment=r.comment)


def payment_out(p: Payment) -> PaymentOut:
    out = PaymentOut.model_validate(p)
    out.receipt_no = p.receipt.receipt_no if p.receipt else None
    return out
