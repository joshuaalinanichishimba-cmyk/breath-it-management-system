/**
 * HTTP client for the FastAPI backend (connected mode).
 * The static GitHub Pages build does not call this; it is here so the frontend can be switched to the
 * real API module by module. Endpoints mirror backend/app/api/v1/*.
 */
import { API_URL, SESSION_KEY } from '@/config'

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message) }
}

function token(): string | null {
  try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) ?? 'null')?.token ?? null } catch { return null }
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (!API_URL) throw new ApiError(0, 'VITE_API_URL is not configured')
  const headers = new Headers(init.headers)
  headers.set('Accept', 'application/json')
  if (init.body && !(init.body instanceof FormData)) headers.set('Content-Type', 'application/json')
  const t = token()
  if (t) headers.set('Authorization', `Bearer ${t}`)
  const res = await fetch(`${API_URL}/api/v1${path}`, { ...init, headers })
  if (!res.ok) {
    let msg = res.statusText
    try { const body = await res.json(); msg = typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail) } catch { /* ignore */ }
    throw new ApiError(res.status, msg)
  }
  return res.status === 204 ? (undefined as T) : res.json()
}

export const endpoints = {
  login: (email: string, password: string) => {
    const body = new URLSearchParams({ username: email, password })
    return api<{ access_token: string; user: { id: string; name: string; email: string; role: string; linked_id?: string } }>('/auth/login', { method: 'POST', body, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
  },
  me: () => api('/auth/me'),
  students: (q = '') => api(`/students?q=${encodeURIComponent(q)}`),
  student: (id: string) => api(`/students/${id}`),
  createStudent: (body: unknown) => api('/students', { method: 'POST', body: JSON.stringify(body) }),
  payments: (params = '') => api(`/finance/payments${params}`),
  recordPayment: (body: unknown) => api('/finance/payments', { method: 'POST', body: JSON.stringify(body) }),
  verifyPayment: (id: string) => api(`/finance/payments/${id}/verify`, { method: 'POST' }),
  balances: () => api('/finance/balances'),
  submitAttendance: (body: unknown) => api('/attendance/register', { method: 'POST', body: JSON.stringify(body) }),
  recordAssessment: (body: unknown) => api('/assessments', { method: 'POST', body: JSON.stringify(body) }),
  timetable: () => api('/timetable'),
  dashboard: () => api('/dashboard/summary'),
  payOnline: (body: { student_id: string; amount: number; method: 'Mobile Money' | 'Card'; network?: string; phone?: string }) => api('/finance/pay', { method: 'POST', body: JSON.stringify(body) }),
  paymentStatus: (id: string) => api(`/finance/payments/${id}/status`),
  reportBankTransfer: (body: unknown) => api('/finance/bank-transfer', { method: 'POST', body: JSON.stringify(body) }),
  enquire: (body: unknown) => api('/enquiries', { method: 'POST', body: JSON.stringify(body) }),
  leads: () => api('/leads'),
  updateLead: (id: string, body: unknown) => api(`/leads/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  rewardReferral: (id: string) => api(`/leads/${id}/reward`, { method: 'POST' }),
  myReferral: () => api('/parents/me/referral'),
}
