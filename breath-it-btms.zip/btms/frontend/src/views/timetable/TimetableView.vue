<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import { Plus, AlertTriangle, Trash2 } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Modal from '@/components/ui/Modal.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import ChildSwitcher from '@/components/domain/ChildSwitcher.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useScope } from '@/composables/useScope'
import { usePortalStudent } from '@/composables/usePortalStudent'
import type { Lesson } from '@/types'
import { DAY_NAMES, DAY_SHORT, iso, isoWeekday } from '@/services/dates'

const store = useDb(); const ui = useUi(); const scope = useScope(); const route = useRoute()
const { student } = usePortalStudent()
const isAdmin = computed(() => scope.role.value === 'admin')
const isFamily = computed(() => scope.role.value === 'student' || scope.role.value === 'parent')
const classFilter = ref(typeof route.query.class === 'string' ? route.query.class : '')
const tutorFilter = ref('')

const visible = computed(() => {
  let ls = scope.lessons.value
  if (isFamily.value && student.value) ls = ls.filter((l) => l.classId === student.value!.classId && student.value!.subjectIds.includes(l.subjectId))
  if (classFilter.value) ls = ls.filter((l) => l.classId === classFilter.value)
  if (tutorFilter.value) ls = ls.filter((l) => l.tutorId === tutorFilter.value)
  return ls
})
const days = computed(() => [1, 2, 3, 4, 5, 6].filter((d) => d <= 5 || visible.value.some((l) => l.day === 6) || isAdmin.value))
const times = computed(() => [...new Set(visible.value.map((l) => l.start))].sort())
const cell = (d: number, t: string) => visible.value.filter((l) => l.day === d && l.start === t).sort((a, b) => store.className(a.classId).localeCompare(store.className(b.classId)))
const mobileDay = ref(Math.min(isoWeekday(iso()), 6))
const classOptions = computed(() => store.db.classes.filter((c) => scope.classIds.value.has(c.id)))

// editor
const open = ref(false); const editing = ref<Lesson | null>(null); const err = ref('')
const f = reactive({ classId: '', subjectId: '', tutorId: '', day: 1, start: '14:00', end: '15:00', room: '' })
function edit(l?: Lesson, day?: number, start?: string) {
  if (!isAdmin.value) return
  editing.value = l ?? null; err.value = ''
  const c = classFilter.value || store.db.classes[0].id
  Object.assign(f, l ? { ...l } : { classId: c, subjectId: '', tutorId: '', day: day ?? 1, start: start ?? '14:00', end: start ? `${String(+start.slice(0, 2) + 1).padStart(2, '0')}:${start.slice(3)}` : '15:00', room: store.classMap.get(c)?.room ?? '' })
  open.value = true
}
const classSubjects = computed(() => store.db.subjects.filter((s) => s.active && s.gradeIds.includes(store.classMap.get(f.classId)?.gradeId ?? '')))
const subjectTutors = computed(() => store.db.tutors.filter((t) => t.status === 'active' && t.subjectIds.includes(f.subjectId)))
watch(() => f.classId, (c, old) => { if (old && c !== old) { f.room = store.classMap.get(c)?.room ?? f.room; if (!classSubjects.value.some((s) => s.id === f.subjectId)) f.subjectId = '' } })
watch(() => f.subjectId, () => { if (!subjectTutors.value.some((t) => t.id === f.tutorId)) f.tutorId = subjectTutors.value[0]?.id ?? '' })
const conflicts = computed(() => (open.value && f.classId && f.subjectId && f.tutorId && f.room ? store.lessonConflicts({ ...f }, editing.value?.id) : []))
function save() {
  if (!f.classId || !f.subjectId || !f.tutorId || !f.room.trim()) return (err.value = 'Choose a class, subject, tutor and room.')
  try { store.saveLesson({ ...f, room: f.room.trim(), id: editing.value?.id }); ui.success(editing.value ? 'Lesson updated' : 'Lesson added to the timetable'); open.value = false }
  catch (e) { err.value = (e as Error).message }
}
async function remove() {
  if (!editing.value) return
  if (!(await ui.confirm({ title: 'Remove lesson?', body: 'It will disappear from the timetable for tutors, students and parents.', confirmLabel: 'Remove', tone: 'danger' }))) return
  try { store.deleteLesson(editing.value.id); ui.success('Lesson removed'); open.value = false } catch (e) { err.value = (e as Error).message }
}
</script>
<template>
  <div>
    <PageHeader title="Timetable" :sub="isFamily ? 'Weekly lessons at the centre' : 'Weekday sessions run in the afternoon after school; Saturday sessions run in the morning.'">
      <button v-if="isAdmin" class="btn btn-primary" @click="edit()"><Plus :size="15" />Add lesson</button>
    </PageHeader>
    <ChildSwitcher />
    <div v-if="!isFamily" class="flex flex-wrap gap-2 mb-4">
      <select v-model="classFilter" class="select w-auto min-w-[160px]" aria-label="Class"><option value="">All classes</option><option v-for="c in classOptions" :key="c.id" :value="c.id">{{ c.name }}</option></select>
      <select v-if="isAdmin" v-model="tutorFilter" class="select w-auto min-w-[160px]" aria-label="Tutor"><option value="">All tutors</option><option v-for="t in store.db.tutors" :key="t.id" :value="t.id">{{ t.firstName }} {{ t.lastName }}</option></select>
    </div>

    <EmptyState v-if="!visible.length" title="No lessons to show" :body="isAdmin ? 'Add a lesson or clear the filters.' : 'Your timetable will appear here once lessons are scheduled.'" />
    <template v-else>
      <!-- Desktop grid -->
      <div class="hidden md:block card overflow-x-auto">
        <table class="w-full text-[12.5px] border-collapse min-w-[760px]">
          <thead><tr>
            <th class="w-[64px] border-b border-line bg-sunken/60" />
            <th v-for="d in days" :key="d" :class="['px-2 py-2.5 text-left font-medium border-b border-l border-line bg-sunken/60', d === isoWeekday(iso()) ? 'text-brand' : 'text-muted']">{{ DAY_NAMES[d] }}</th>
          </tr></thead>
          <tbody>
            <tr v-for="t in times" :key="t">
              <td class="px-2 py-2 align-top text-muted tnum border-b border-line font-medium">{{ t }}</td>
              <td v-for="d in days" :key="d" :class="['p-1.5 align-top border-b border-l border-line', isAdmin && 'cursor-copy']" @click.self="edit(undefined, d, t)">
                <button v-for="l in cell(d, t)" :key="l.id" type="button" :class="['w-full text-left rounded-md bg-brand-soft/70 border border-brand/15 px-2 py-1.5 mb-1 last:mb-0', isAdmin ? 'hover:border-brand' : 'cursor-default']" @click="edit(l)">
                  <div class="font-medium text-ink truncate">{{ store.subjectName(l.subjectId) }}</div>
                  <div class="text-muted truncate">{{ classFilter || isFamily ? store.tutorName(l.tutorId) : store.className(l.classId) }}</div>
                  <div class="text-faint truncate">{{ l.start }}–{{ l.end }} · {{ l.room }}</div>
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- Mobile: day by day -->
      <div class="md:hidden">
        <div class="seg w-full mb-3 overflow-x-auto">
          <button v-for="d in days" :key="d" :class="['flex-1', { on: mobileDay === d }]" @click="mobileDay = d">{{ DAY_SHORT[d] }}</button>
        </div>
        <div class="grid gap-2">
          <button v-for="l in visible.filter((x) => x.day === mobileDay).sort((a, b) => a.start.localeCompare(b.start))" :key="l.id" class="card px-3.5 py-3 flex gap-3 text-left" @click="edit(l)">
            <div class="w-[52px] shrink-0 tnum font-semibold">{{ l.start }}<div class="text-[11.5px] text-muted font-normal">{{ l.end }}</div></div>
            <div class="min-w-0"><div class="font-medium">{{ store.subjectName(l.subjectId) }}</div><div class="text-[12.5px] text-muted">{{ store.className(l.classId) }} · {{ store.tutorName(l.tutorId) }} · {{ l.room }}</div></div>
          </button>
          <EmptyState v-if="!visible.some((x) => x.day === mobileDay)" compact :title="`No lessons on ${DAY_NAMES[mobileDay]}`" />
        </div>
      </div>
      <p v-if="isAdmin" class="text-[12px] text-muted mt-2">Click an empty cell to add a lesson at that time, or a lesson to move it.</p>
    </template>

    <Modal :open="open" :title="editing ? 'Edit lesson' : 'Add lesson'" sub="Clashes for the same tutor, room or class are blocked." @close="open = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
        <div><label class="label" for="ls-c">Class</label><select id="ls-c" v-model="f.classId" class="select"><option v-for="c in store.db.classes.filter((x) => x.active)" :key="c.id" :value="c.id">{{ c.name }}</option></select></div>
        <div><label class="label" for="ls-s">Subject</label><select id="ls-s" v-model="f.subjectId" class="select"><option value="" disabled>Choose…</option><option v-for="s in classSubjects" :key="s.id" :value="s.id">{{ s.name }}</option></select></div>
        <div><label class="label" for="ls-t">Tutor</label><select id="ls-t" v-model="f.tutorId" class="select"><option value="" disabled>{{ f.subjectId ? 'No tutor teaches this subject' : 'Choose a subject first' }}</option><option v-for="t in subjectTutors" :key="t.id" :value="t.id">{{ t.firstName }} {{ t.lastName }}</option></select></div>
        <div><label class="label" for="ls-d">Day</label><select id="ls-d" v-model.number="f.day" class="select"><option v-for="d in [1, 2, 3, 4, 5, 6]" :key="d" :value="d">{{ DAY_NAMES[d] }}</option></select></div>
        <div><label class="label" for="ls-st">Start</label><input id="ls-st" v-model="f.start" type="time" class="input" /></div>
        <div><label class="label" for="ls-en">End</label><input id="ls-en" v-model="f.end" type="time" class="input" /></div>
        <div><label class="label" for="ls-r">Room</label><input id="ls-r" v-model="f.room" class="input" /></div>
        <div v-if="conflicts.length" class="sm:col-span-2 rounded-md bg-bad-soft text-bad px-3 py-2.5 text-[13px] flex gap-2"><AlertTriangle :size="16" class="shrink-0 mt-0.5" /><ul><li v-for="c in conflicts" :key="c">{{ c }}</li></ul></div>
        <p v-if="err && !conflicts.length" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer>
        <button v-if="editing" class="btn btn-ghost text-bad mr-auto" @click="remove"><Trash2 :size="15" />Remove</button>
        <button class="btn btn-secondary" @click="open = false">Cancel</button>
        <button class="btn btn-primary" :disabled="conflicts.length > 0" @click="save">{{ editing ? 'Save changes' : 'Add lesson' }}</button>
      </template>
    </Modal>
  </div>
</template>
