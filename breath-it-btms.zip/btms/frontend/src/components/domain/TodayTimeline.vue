<script setup lang="ts">
/** Signature element: the centre's afternoon, lesson by lesson, with register status. */
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useDb } from '@/stores/db'
import type { Lesson } from '@/types'
import { iso, isoWeekday, nowTime, DAY_NAMES } from '@/services/dates'
import EmptyState from '@/components/ui/EmptyState.vue'

const props = defineProps<{ lessons: Lesson[]; canTakeRegister?: boolean }>()
const store = useDb(); const router = useRouter()
const today = iso()
const todays = computed(() => props.lessons.filter((l) => l.day === isoWeekday(today)).sort((a, b) => a.start.localeCompare(b.start) || store.className(a.classId).localeCompare(store.className(b.classId))))
const slots = computed(() => [...new Set(todays.value.map((l) => l.start))])
const now = nowTime()
function state(l: Lesson) {
  const recorded = store.registerFor(l.id, today).length > 0
  if (recorded) return { label: 'Register taken', cls: 'badge-ok' }
  if (now >= l.end) return { label: 'Register missing', cls: 'badge-bad' }
  if (now >= l.start) return { label: 'In session', cls: 'badge-warn' }
  return { label: 'Upcoming', cls: 'badge-mute' }
}
function open(l: Lesson) { if (props.canTakeRegister) router.push({ path: '/attendance', query: { lesson: l.id, date: today } }) }
</script>
<template>
  <div>
    <EmptyState v-if="!todays.length" compact :title="`No lessons on ${DAY_NAMES[isoWeekday(today)]}`" body="Lessons run Monday to Friday afternoons and Saturday mornings." />
    <div v-else class="overflow-x-auto -mx-1 px-1 pb-1">
      <div class="flex gap-3 min-w-max">
        <div v-for="t in slots" :key="t" class="w-[228px] shrink-0">
          <div class="flex items-center gap-2 mb-2">
            <span class="text-[13px] font-semibold tnum">{{ t }}</span>
            <span class="h-px flex-1 bg-line" />
          </div>
          <div class="grid gap-2">
            <button v-for="l in todays.filter((x) => x.start === t)" :key="l.id" type="button"
              :class="['text-left rounded-md border border-line bg-surface px-3 py-2.5 transition-colors', canTakeRegister ? 'hover:border-brand' : 'cursor-default']" @click="open(l)">
              <div class="flex items-start justify-between gap-2">
                <div class="min-w-0">
                  <div class="text-[13px] font-medium truncate">{{ store.subjectName(l.subjectId) }}</div>
                  <div class="text-[12px] text-muted truncate">{{ store.className(l.classId) }} · {{ l.room }}</div>
                </div>
              </div>
              <div class="mt-2 flex items-center justify-between gap-2">
                <span class="text-[12px] text-muted truncate">{{ store.tutorName(l.tutorId) }}</span>
                <span :class="['badge', state(l).cls]">{{ state(l).label }}</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
