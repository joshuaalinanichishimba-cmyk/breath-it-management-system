// Exports the frontend demo data generator to JSON for the backend seed script, so both show identical data.
// Usage: npm run export-seed   (writes ../backend/app/seed_data/demo_seed.json)
import { build } from 'esbuild'
import { writeFileSync, mkdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
const out = path.join(here, '.seed.bundle.mjs')
await build({
  entryPoints: [path.join(here, '../src/services/demo/seed.ts')],
  bundle: true, format: 'esm', platform: 'node', outfile: out,
  alias: { '@': path.join(here, '../src') }, logLevel: 'error',
})
const { buildSeed } = await import(out + '?t=' + Date.now())
const today = process.argv[2] ?? new Date().toISOString().slice(0, 10)
const data = buildSeed(today)
const dest = path.join(here, '../../backend/app/seed_data')
mkdirSync(dest, { recursive: true })
writeFileSync(path.join(dest, 'demo_seed.json'), JSON.stringify(data))
console.log(`Seed for ${today}: ${data.students.length} students, ${data.payments.length} payments, ${data.attendance.length} attendance records`)
