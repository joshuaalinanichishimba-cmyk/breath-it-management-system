from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field, HttpUrl, model_validator
from .common import ORM


class AnnouncementIn(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    body: str = Field(min_length=2)
    audience: Literal["everyone", "parents", "students", "tutors", "class"]
    class_id: str | None = None
    priority: Literal["normal", "important"] = "normal"
    send_sms: bool = False
    send_whatsapp: bool = False

    @model_validator(mode="after")
    def _cls(self):
        if self.audience == "class" and not self.class_id:
            raise ValueError("class_id is required for a class announcement")
        return self


class AnnouncementOut(ORM):
    id: str
    title: str
    body: str
    audience: str
    class_id: str | None
    priority: str
    author_name: str
    created_at: datetime
    sms_status: str
    whatsapp_status: str


class MaterialIn(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    description: str = ""
    kind: Literal["Notes", "Worksheet", "Past paper", "Link"]
    class_id: str
    subject_id: str
    content: str | None = None
    link: HttpUrl | None = None

    @model_validator(mode="after")
    def _body(self):
        if self.kind == "Link" and not self.link:
            raise ValueError("A link is required")
        if self.kind != "Link" and not (self.content or "").strip():
            raise ValueError("Content is required")
        return self


class MaterialOut(ORM):
    id: str
    title: str
    description: str
    kind: str
    class_id: str
    subject_id: str
    tutor_id: str | None
    content: str | None
    link: str | None
    created_at: datetime


class AuditOut(ORM):
    id: str
    at: datetime
    actor_name: str
    action: str
    entity: str
    entity_id: str
    detail: str
