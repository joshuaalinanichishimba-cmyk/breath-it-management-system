# Breath It Tuition Centre Management System (BTMS)

A management system designed for **Breath It Tuition Centre**, Kaunda Square Stage Two, Lusaka.
One platform for owners and management, tutors, students and parents: registration, timetable, attendance,
marks and comments, tuition fees and receipts, announcements and reports.

> **This repository is a demonstration.** Every student, parent, tutor, payment and mark in it is fictional.
> The live demo runs entirely in the browser; nothing is sent to a server and changes stay in that browser only.

**Live demo:** https://joshuaalinanichishimba-cmyk.github.io/breath-it-btms/ (after the first GitHub Pages deploy — see below)

## Demo accounts

All passwords: `demo1234` (also shown on the sign-in page; you can switch role from the user menu at any time).

| Role | Email | Who |
|---|---|---|
| Administrator | admin@breathit.demo | Owner / management view |
| Tutor | tutor@breathit.demo | Chanda Mwila — Mathematics (Grades 8, 9, 12) |
| Student | student@breathit.demo | Natasha Banda — Grade 12 |
| Parent | parent@breathit.demo | Mutale Banda — parent of Natasha (Grade 12) and John (Grade 8) |

These accounts exist only in the demo build and in the `--demo` database seed. They are never created in production.

## Suggested 12-minute walkthrough

0. **Admin → Settings → Brand.** Upload the Breath It logo: the system detects its main colour; click *Use it* and the whole app, receipts and report cards switch to Breath It’s colours.

1. **Admin → Dashboard.** “Today at the centre” shows every lesson today and whether its register has been taken.
2. **Finance → Verify.** Three Mobile Money payments are waiting to be checked. Verify one: a receipt is issued and the balance drops. Record a new payment without ticking “I have confirmed…” and see that the balance does *not* change.
3. **Students → John Banda.** K1,000 tuition, K600 paid, K400 outstanding. Download his report card (PDF).
4. **Switch to Tutor.** Take a register (Present/Late/Absent), then enter marks for a test — percentages calculate as you type.
5. **Switch to Parent.** Both children on one account: results with tutor comments, attendance calendar, fee balances, receipts.
6. **Admin → Timetable.** Try adding a lesson that clashes with an existing one: it is blocked with the reason.
7. **Admin → Reports.** Export collections or outstanding balances as CSV or branded PDF.
8. **Parent → Pay.** Pay John’s K400 with Airtel Money, MTN MoMo, Zamtel Kwacha, card or bank transfer. Try an MTN number on Airtel (it is caught), approve or decline the simulated PIN prompt, then open the instant receipt.
9. **Admin → Growth.** This week’s opportunities: enquiries to follow up, families to remind, learners at risk of leaving, empty seats and what they are worth.
10. **Admin → Enquiries.** Move a family from enquiry to trial to enrolled; *Enrol* opens registration pre-filled. Copy the public enquiry form link for Facebook/WhatsApp.
11. **Finance → Reminders.** One tap opens WhatsApp with a polite fee reminder for that family, amount filled in.

## What is implemented

**Brand:** logo upload with automatic colour detection, or any exact colour; the theme is generated for light and dark mode with readable contrast and is used on every screen, receipt and report card.

**Paying in the app (parents and, if allowed, students):** Airtel Money, MTN MoMo and Zamtel Kwacha (PIN prompt on the payer’s phone, number checked against the network’s prefixes), bank card via the provider’s hosted page (card numbers never touch BTMS), and bank transfer with reference. Pay the term balance, everything owed, or a part payment; per-child for families with several children. Gateway-confirmed payments verify themselves and issue a receipt instantly; declined or expired prompts change nothing; bank transfers wait for the office. Optional pass-through of the transaction fee.

**Growth tools:** Growth dashboard (retention from last term, collection rate, share paid online, seat fill and the tuition value of empty seats, revenue by term, admissions funnel, subject demand, learners at risk of leaving with a one-tap parent check-in, students who did not return with a win-back message) · Admissions pipeline (enquiry → contacted → trial → enrolled / lost with reasons, follow-up dates, source performance, WhatsApp templates per stage, one-click enrolment) · public enquiry form to share on Facebook, WhatsApp status and flyers (spam honeypot + rate limit on the API) · referral codes for every family with a configurable fee credit when a referred child enrols · fee reminders that open WhatsApp or SMS with an editable, pre-filled message and log who was reminded when.

**Administration:** dashboard (students, tutors, classes, collections, outstanding fees, today’s attendance, upcoming lessons, recent payments and registrations, frequently absent students; charts for monthly revenue, enrolment, weekly attendance and performance by subject) · student registration with automatic student numbers, editing, status changes and enrolment history · parents (one account, many children) · tutors with activity metrics · classes with capacity · configurable grades and subjects · timetable with tutor/room/class clash detection · attendance summaries (daily, weekly, monthly) · performance analytics · finance · announcements · reports · settings · audit trail.

**Finance:** charges per term from a fee structure (Tuition, Registration, Examination) · payments by Cash, Mobile Money or Bank Transfer · partial payments and automatic balances per term and overall · **payments only reduce a balance once verified** (transaction ID checked against the statement) · reject with reason · duplicate transaction IDs blocked · receipts (PDF) for verified payments only · balances list · CSV/PDF exports · “raise this term’s charges” billing run.

**Tutors:** only their own classes, students and lessons · registers (one record per student per lesson per date; resubmitting corrects instead of duplicating) · marks for tests, assignments, mock and end-of-term exams with comments · learning materials · class announcements. No access to finance.

**Students:** profile, subjects, timetable, attendance, results and progress chart, materials, announcements, own payments (can be switched off in Settings).

**Parents:** every linked child, attendance calendar, results and tutor comments, report card PDF, fee balances, payment history, receipt download, timetable, announcements.

**Quality:** responsive (desktop, tablet, phone), light and dark mode, keyboard focus states, confirmation dialogs, toasts, empty and error states, validation on every form (including Zambian phone numbers).

## Needs real integrations (not simulated)

| Feature | Status in the demo | What is needed |
|---|---|---|
| In-app mobile money and card payments | Full checkout; the PIN prompt and the provider’s confirmation are **simulated** and labelled as such | Merchant account with an aggregator that covers Airtel, MTN and Zamtel (e.g. pawaPay, DPO Pay, MoneyUnify, Bila — compare fees and settlement times), an adapter in `backend/app/services/payment_gateway.py`, `PAYMENT_GATEWAY` + `PAYMENT_WEBHOOK_SECRET`. The webhook, signature check, idempotency and amount check are already built and tested with the sandbox adapter |
| SMS / WhatsApp announcements | Ticking the box records the request and clearly shows “not sent (no provider)”. Nothing is sent. | Bulk-SMS gateway and/or WhatsApp Business API account; adapter in `backend/app/services/notifications.py` |
| Office-recorded Mobile Money | Staff verify transaction IDs manually | Statement import, or encourage parents to pay in the app (verified automatically) |
| File uploads for materials | Tutors type or paste notes; students download as text; links supported | Object storage (e.g. S3-compatible) + upload endpoint |
| Email receipts and report cards | Downloaded as PDF only | Transactional email provider |
| Persistent multi-user data | Demo data lives in each browser’s local storage | The FastAPI backend + PostgreSQL in this repo, deployed |

## To confirm with management

The structure is based on the centre’s published subject list. These details are sample values and are editable:
the exact brand colour or logo file · bank account details and which gateway to use · whether the centre or parents pay transaction fees · the referral reward amount · fee amounts and whether fees are per term or per month · registration and exam fees · term dates · whether Grades 10–11 or other programmes are offered · lesson times and room names · class groupings · grading bands used on report cards · who may verify payments · whether students should see fees · Mobile Money merchant/till details for parents.

## Repository layout

```
frontend/   Vue 3 + Vite + TypeScript + Tailwind + Pinia + Chart.js (the demo)
  src/views/        one folder per module (students, finance, attendance…)
  src/components/   ui/ (generic), domain/ (forms, receipt, timeline), charts/
  src/stores/       auth, ui, db (demo repository with all domain actions + audit)
  src/services/     dates, formatting, analytics, PDF, CSV/download, API client, demo seed
  src/composables/  role scoping (useScope), portal child selection, pagination
backend/    FastAPI + SQLAlchemy 2 + PostgreSQL
  app/models/       26 tables (users, roles, students, parents, tutors, classes, subjects, timetable_slots, leads, reminder_logs,
                    attendance, assessments, examination_results, fee_structures, charges, payments, receipts,
                    announcements, learning_materials, audit_logs, …)
  app/api/v1/       auth, people, academics/timetable, attendance & assessments, finance (incl. online pay + gateway webhook),
                    communication, reports, growth (public enquiries, leads, referrals, reminders)
  app/services/     access scoping, finance (verified-only balances), timetable clashes, audit, notifications
  app/seed.py       demo data loader / production bootstrap
  schema.sql        generated PostgreSQL DDL
  tests/            API tests (roles, finance rules, attendance, clashes, validation)
```

## Run locally (Windows PowerShell)

Frontend:
```powershell
cd frontend
npm install
npm run dev          # http://localhost:5173
```

Backend (from the `backend` folder so `.env` loads):
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
Copy-Item .env.example .env       # then edit DATABASE_URL and JWT_SECRET
python -m app.seed --demo         # tables + fictional demo data
uvicorn app.main:app --reload     # http://localhost:8000/docs
python -m pytest -q tests         # 21 API tests
```
Without PostgreSQL installed, set `DATABASE_URL=sqlite:///./btms.db` in `.env` for local testing.

## Deploy the demo to GitHub Pages

1. Create an empty public repository named **breath-it-btms** on GitHub (no README).
2. From the project folder:
   ```powershell
   git init
   git add .
   git commit -m "Breath It BTMS demo"
   git branch -M main
   git remote add origin https://github.com/joshuaalinanichishimba-cmyk/breath-it-btms.git
   git push -u origin main
   ```
3. On GitHub: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. Open the **Actions** tab; when “Deploy demo to GitHub Pages” finishes (≈2 minutes) the demo is live at
   `https://joshuaalinanichishimba-cmyk.github.io/breath-it-btms/`.

Every push to `main` rebuilds and redeploys automatically, and runs the backend tests.
The build uses hash routing (`#/students`) because GitHub Pages cannot serve SPA fallbacks.

## Deploy the API (Render + PostgreSQL)

1. Render → **New → Blueprint** → select this repository. `backend/render.yaml` creates the web service and a PostgreSQL database and generates `JWT_SECRET`.
2. After the first deploy, open the service **Shell** and run either
   `python -m app.seed --demo` (demo environment, not allowed when `ENVIRONMENT=production`) or
   `ADMIN_EMAIL=… ADMIN_PASSWORD=… python -m app.seed` (real deployment: creates the first administrator).
3. Supabase or any PostgreSQL also works: set `DATABASE_URL=postgresql+psycopg://…`.
4. On Render’s free tier, use **Manual Deploy → Clear build cache & deploy** if a change does not appear.

**Connecting the frontend:** build with `VITE_DEMO_MODE=false` and `VITE_API_URL=https://<your-api>.onrender.com`.
Sign-in then goes through the API (bcrypt-hashed passwords, signed JWT). The typed client in `frontend/src/services/api.ts`
mirrors the API; moving each module’s store actions from the in-browser demo repository to these endpoints is the next
development stage. Until then, connected mode authenticates against the API but module data still comes from the demo repository.

## Security

Role-based access is enforced **on the server** for every endpoint (parents only see linked children, tutors only their
lessons and students, students only themselves; unknown or out-of-scope student IDs return 404). Passwords are bcrypt-hashed;
tokens are signed JWTs with expiry; production refuses to start with a weak `JWT_SECRET` and refuses to load demo accounts;
API docs are hidden in production; inputs are validated with Pydantic; the database enforces uniqueness (one attendance mark per
student per lesson per date, one result per student per assessment, unique transaction references and receipt numbers) and
check constraints (positive amounts, valid statuses, end time after start time). Student records, payments, verifications,
fee changes, marks and registers are written to `audit_logs` in the same transaction as the change.
Not yet included: login rate limiting, password reset by email, and database migrations (add Alembic before the first real deployment).

---
Built for Breath It Tuition Centre by Joshua Chishimba (Altiora Technologies). Demonstration data only.
