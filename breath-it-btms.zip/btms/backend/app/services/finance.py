from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from ..models import Charge, Payment, Receipt, User


def billed(db: Session, student_id: str, term: str | None = None) -> Decimal:
    q = select(func.coalesce(func.sum(Charge.amount), 0)).where(Charge.student_id == student_id)
    if term:
        q = q.where(Charge.term == term)
    return Decimal(db.scalar(q) or 0)


def paid(db: Session, student_id: str, term: str | None = None) -> Decimal:
    """Only VERIFIED payments count. A recorded payment is not proof that money arrived."""
    q = select(func.coalesce(func.sum(Payment.amount), 0)).where(Payment.student_id == student_id, Payment.status == "verified")
    if term:
        q = q.where(Payment.term == term)
    return Decimal(db.scalar(q) or 0)


def balance(db: Session, student_id: str, term: str | None = None) -> Decimal:
    return billed(db, student_id, term) - paid(db, student_id, term)


def next_number(db: Session, model, column, prefix: str) -> str:
    """Sequential human-readable numbers, e.g. PAY-2026-0042 / RCT-2026-0042."""
    last = db.scalar(select(func.max(column)).where(column.like(f"{prefix}%")))
    n = int(last.rsplit("-", 1)[1]) + 1 if last else 1
    return f"{prefix}{n:04d}"


def verify(db: Session, payment: Payment, user: User) -> Receipt:
    payment.status = "verified"
    payment.verified_by = user.name
    payment.verified_at = datetime.now(timezone.utc)
    db.flush()
    payment.balance_after = balance(db, payment.student_id)
    receipt = Receipt(receipt_no=next_number(db, Receipt, Receipt.receipt_no, f"RCT-{payment.payment_date.year}-"), payment_id=payment.id, issued_by=user.name)
    db.add(receipt)
    return receipt
