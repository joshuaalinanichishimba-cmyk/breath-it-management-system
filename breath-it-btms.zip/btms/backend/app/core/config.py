from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8-sig", extra="ignore")

    environment: str = "development"
    database_url: str = "sqlite:///./btms.db"
    jwt_secret: str = "dev-only-secret-change-me"
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 480
    cors_origins: str = "http://localhost:5173"
    demo_password: str = "demo1234"
    sms_provider: str | None = None
    # Online payments: '' (off), 'sandbox' (local testing), or the name of an implemented aggregator adapter
    payment_gateway: str = ""
    payment_webhook_secret: str = ""
    public_app_url: str = "https://joshuaalinanichishimba-cmyk.github.io/breath-it-btms/"
    whatsapp_provider: str | None = None

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    if s.is_production and (s.jwt_secret.startswith("dev-only") or s.jwt_secret == "change-me" or len(s.jwt_secret) < 32):
        raise RuntimeError("Set a strong JWT_SECRET (32+ characters) before running in production.")
    return s
