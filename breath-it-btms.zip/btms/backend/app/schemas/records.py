from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from pydantic import BaseModel, Field
from .common import ORM

AttendanceStatus = Literal["present", "absent", "late"]
AssessmentType = Literal["Test", "Assignment", "Mock Exam", "End of Term Exam"]


class RegisterMark(BaseModel):
    student_id: str
    status: AttendanceStatus


class RegisterIn(BaseModel):
    slot_id: str
    lesson_date: date
    marks: list[RegisterMark] = Field(min_length=1)


class RegisterResult(BaseModel):
    created: int
    updated: int


class AttendanceOut(ORM):
    id: str
    student_id: str
    slot_id: str
    lesson_date: date
    status: str
    recorded_at: datetime


class ResultIn(BaseModel):
    student_id: str
    marks: Decimal = Field(ge=0)
    comment: str = ""


class AssessmentIn(BaseModel):
    class_id: str
    subject_id: str
    assessment_type: AssessmentType
    title: str = Field(min_length=1, max_length=120)
    max_marks: Decimal = Field(gt=0)
    assessment_date: date
    results: list[ResultIn] = Field(min_length=1)


class ResultUpdate(BaseModel):
    marks: Decimal | None = Field(default=None, ge=0)
    comment: str | None = None


class ResultOut(BaseModel):
    id: str
    assessment_id: str
    student_id: str
    subject_id: str
    assessment_type: str
    title: str
    assessment_date: date
    term: str
    marks: float
    max_marks: float
    percentage: float
    comment: str
