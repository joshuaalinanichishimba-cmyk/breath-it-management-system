<script setup lang="ts">
import { methodLabel } from '@/services/payments'
import { computed, ref } from 'vue'
import { useRoute, RouterLink } from 'vue-router'
import { Wallet, Download, FileDown, Check, X, Search } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatTile from '@/components/ui/StatTile.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import Pager from '@/components/ui/Pager.vue'
import Modal from '@/components/ui/Modal.vue'
import PaymentFormModal from '@/components/domain/PaymentFormModal.vue'
import ReceiptModal from '@/components/domain/ReceiptModal.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { usePager } from '@/composables/usePager'
import type { Payment } from '@/types'
import { iso, fmtDate } from '@/services/dates'
import { kwacha, pct } from '@/services/format'
import { saveFile, toCsv } from '@/services/download'
import { tablePdf } from '@/services/pdf'
import { waLink, smsLink, fillTemplate } from '@/services/whatsapp'
import { MessageCircle, MessageSquareText } from 'lucide-vue-next'

const store = useDb(); const ui = useUi(); const route = useRoute()
const tab = ref<'payments' | 'balances' | 'verify' | 'reminders' | 'fees'>(route.query.tab === 'verify' ? 'verify' : route.query.tab === 'reminders' ? 'reminders' : 'payments')
const term = computed(() => store.db.settings.currentTerm)
const collected = computed(() => store.db.payments.filter((p) => p.status === 'verified' && p.term === term.value).reduce((a, p) => a + p.amount, 0))
const billedT = computed(() => store.db.charges.filter((c) => c.term === term.value).reduce((a, c) => a + c.amount, 0))
const outstanding = computed(() => store.db.students.reduce((a, s) => a + Math.max(0, store.balance(s.id)), 0))
const pending = computed(() => store.db.payments.filter((p) => p.status === 'pending').sort((a, b) => b.date.localeCompare(a.date)))

// payments
const q = ref(''); const method = ref(''); const channel = ref(''); const status = ref(''); const from = ref(''); const to = ref(''); const fterm = ref('')
const payments = computed(() => store.db.payments.filter((p) => {
  const t = q.value.trim().toLowerCase()
  return (!t || `${store.studentName(p.studentId)} ${p.reference} ${p.receiptNo ?? ''} ${p.externalRef ?? ''} ${store.studentMap.get(p.studentId)?.studentNo}`.toLowerCase().includes(t)) &&
    (!method.value || p.method === method.value) && (!channel.value || p.channel === channel.value) && (!status.value || p.status === status.value) && (!fterm.value || p.term === fterm.value) &&
    (!from.value || p.date >= from.value) && (!to.value || p.date <= to.value)
}).sort((a, b) => b.date.localeCompare(a.date) || b.reference.localeCompare(a.reference)))
const { page, pages, rows, range } = usePager(payments, 15)
const filteredTotal = computed(() => payments.value.filter((p) => p.status === 'verified').reduce((a, p) => a + p.amount, 0))

// balances
const owingOnly = ref(true)
const balances = computed(() => store.db.students.map((s) => {
  const last = store.db.payments.filter((p) => p.studentId === s.id && p.status === 'verified').sort((a, b) => b.date.localeCompare(a.date))[0]
  const tb = store.billed(s.id, term.value), tp = store.paid(s.id, term.value)
  return { s, billed: store.billed(s.id), paid: store.paid(s.id), bal: store.balance(s.id), last, termState: tb === 0 ? 'none' : tp >= tb ? 'paid' : tp > 0 ? 'partial' : 'unpaid' }
}).filter((x) => !owingOnly.value || x.bal > 0).sort((a, b) => b.bal - a.bal))

// verification
const rejecting = ref<Payment | null>(null); const reason = ref('')
async function verify(p: Payment) {
  if (!(await ui.confirm({ title: 'Verify this payment?', body: `Confirm ${kwacha(p.amount)} from ${store.studentName(p.studentId)}${p.externalRef ? ` (ref ${p.externalRef})` : ''} appears on the ${p.method === 'Bank Transfer' ? 'bank' : 'Mobile Money'} statement. A receipt will be issued and the balance reduced.`, confirmLabel: 'Verify payment' }))) return
  store.verifyPayment(p.id); ui.success('Payment verified', `Receipt ${store.db.payments.find((x) => x.id === p.id)?.receiptNo} issued`)
}
function reject() {
  if (!reason.value.trim()) return ui.error('Give a reason so the office can follow up with the parent.')
  store.rejectPayment(rejecting.value!.id, reason.value.trim()); ui.info('Payment rejected', 'It does not affect the balance.'); rejecting.value = null; reason.value = ''
}

// fees
const feeGrades = computed(() => [...store.db.grades].sort((a, b) => a.order - b.order))
const feeFor = (g: string, c: string) => store.db.feeStructures.find((f) => f.gradeId === g && f.category === c)
function setFee(id: string, e: Event) {
  const v = Number((e.target as HTMLInputElement).value)
  try { store.updateFee(id, v); ui.success('Fee updated', 'New amount applies to charges raised from now on.') } catch (err) { ui.error((err as Error).message) }
}
function addFee(gradeId: string, category: 'Tuition' | 'Registration' | 'Examination') {
  store.db.feeStructures.push({ id: `f-${gradeId}-${category}-${Date.now()}`, gradeId, category, amount: 0, frequency: category === 'Registration' ? 'once' : 'per term', description: `${store.gradeName(gradeId)} ${category.toLowerCase()}` })
}
async function billTerm() {
  if (!(await ui.confirm({ title: `Raise ${term.value} charges?`, body: 'Adds this term’s tuition and examination fees for every active student who has not yet been charged. Students already billed are skipped.', confirmLabel: 'Raise charges' }))) return
  const n = store.billTerm(term.value); ui.success(n ? `${n} charges raised` : 'Everyone is already billed for this term')
}

// reminders (WhatsApp / SMS links open the parent's chat with the message ready; nothing is sent automatically)
const families = computed(() => {
  const m = new Map<string, { pid: string; kids: { name: string; bal: number }[]; total: number }>()
  for (const s of store.db.students) {
    const b = store.balance(s.id); if (b <= 0) continue
    const x = m.get(s.parentId) ?? { pid: s.parentId, kids: [], total: 0 }
    x.kids.push({ name: s.firstName, bal: b }); x.total += b; m.set(s.parentId, x)
  }
  return [...m.values()].sort((a, b) => b.total - a.total)
})
const lastReminder = (pid: string) => store.db.reminders.find((r) => r.parentId === pid)
function reminderText(f: { pid: string; kids: { name: string; bal: number }[]; total: number }) {
  const p = store.parentMap.get(f.pid)
  return fillTemplate(store.db.settings.reminderTemplate, { parent: p?.name.split(' ')[0] ?? 'Parent', child: f.kids.map((k) => k.name).join(' and '), balance: kwacha(f.total), term: term.value })
}
function remind(f: { pid: string; total: number }, ch: 'WhatsApp' | 'SMS') { store.logReminder(f.pid, ch, f.total) }

// exports
async function exportPayments(kind: 'csv' | 'pdf') {
  const head = ['Date', 'Reference', 'Receipt', 'Student', 'Student no.', 'Category', 'Term', 'Method', 'External ref', 'Amount (K)', 'Status', 'Recorded by']
  const body = payments.value.map((p) => [p.date, p.reference, p.receiptNo ?? '', store.studentName(p.studentId), store.studentMap.get(p.studentId)?.studentNo ?? '', p.category, p.term, p.method, p.externalRef ?? '', p.amount.toFixed(2), p.status, p.recordedBy])
  try {
    const r = kind === 'csv' ? await saveFile(`payments-${iso()}.csv`, toCsv(head, body), 'text/csv')
      : await saveFile(`payments-${iso()}.pdf`, tablePdf(store.db, 'Payments report', `${payments.value.length} payments · filters applied as shown on screen`, ['Date', 'Ref', 'Student', 'For', 'Method', 'Amount', 'Status'], payments.value.map((p) => [fmtDate(p.date), p.reference, store.studentName(p.studentId), `${p.category} ${p.term}`, p.method, kwacha(p.amount, { decimals: true }), p.status]), [['Verified total', kwacha(filteredTotal.value, { decimals: true })]], true), 'application/pdf')
    if (r === 'saved') ui.success(`Payments exported as ${kind.toUpperCase()}`)
  } catch (e) { ui.error('Export failed', (e as Error).message) }
}
async function exportBalances() {
  const head = ['Student no.', 'Student', 'Grade', 'Parent', 'Parent phone', 'Billed (K)', 'Paid (K)', 'Balance (K)', 'Last payment']
  const body = balances.value.map((x) => { const p = store.parentMap.get(x.s.parentId); return [x.s.studentNo, `${x.s.firstName} ${x.s.lastName}`, store.gradeName(x.s.gradeId), p?.name ?? '', p?.phone ?? '', x.billed.toFixed(2), x.paid.toFixed(2), x.bal.toFixed(2), x.last?.date ?? ''] })
  try { if ((await saveFile(`balances-${iso()}.csv`, toCsv(head, body), 'text/csv')) === 'saved') ui.success('Balances exported') } catch (e) { ui.error('Export failed', (e as Error).message) }
}
const payOpen = ref(false); const receipt = ref<Payment | null>(null)
</script>

<template>
  <div>
    <PageHeader title="Finance" sub="All amounts in Zambian Kwacha. Only verified payments count toward balances and revenue.">
      <button class="btn btn-primary" @click="payOpen = true"><Wallet :size="15" />Record payment</button>
    </PageHeader>
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5">
      <StatTile :label="`Collected · ${term}`" :value="kwacha(collected)" tone="ok" />
      <StatTile :label="`Billed · ${term}`" :value="kwacha(billedT)" />
      <StatTile label="Collection rate" :value="billedT ? pct((collected / billedT) * 100) : '—'" hint="This term" />
      <StatTile label="Outstanding (all terms)" :value="kwacha(outstanding)" tone="bad" :hint="`${store.db.students.filter((s) => store.balance(s.id) > 0).length} students`" />
      <StatTile label="Awaiting verification" :value="pending.length" :tone="pending.length ? 'warn' : undefined" :hint="kwacha(pending.reduce((a, p) => a + p.amount, 0))" />
    </div>
    <div class="tabs mb-4" role="tablist">
      <button role="tab" :aria-selected="tab === 'payments'" :class="['tab', tab === 'payments' && 'tab-active']" @click="tab = 'payments'">Payments</button>
      <button role="tab" :aria-selected="tab === 'balances'" :class="['tab', tab === 'balances' && 'tab-active']" @click="tab = 'balances'">Balances</button>
      <button role="tab" :aria-selected="tab === 'verify'" :class="['tab', tab === 'verify' && 'tab-active']" @click="tab = 'verify'">Verify <span v-if="pending.length" class="badge badge-warn ml-1">{{ pending.length }}</span></button>
      <button role="tab" :aria-selected="tab === 'reminders'" :class="['tab', tab === 'reminders' && 'tab-active']" @click="tab = 'reminders'">Reminders <span class="badge badge-mute ml-1">{{ families.length }}</span></button>
      <button role="tab" :aria-selected="tab === 'fees'" :class="['tab', tab === 'fees' && 'tab-active']" @click="tab = 'fees'">Fee structure</button>
    </div>

    <div v-if="tab === 'payments'" class="card">
      <div class="p-3 sm:p-4 grid gap-2 sm:grid-cols-3 lg:grid-cols-[1fr_130px_150px_150px_130px_130px_130px] border-b border-line">
        <div class="relative sm:col-span-3 lg:col-span-1"><Search :size="15" class="absolute left-3 top-1/2 -translate-y-1/2 text-faint" /><input v-model="q" class="input pl-9" placeholder="Student, reference or transaction ID" aria-label="Search payments" /></div>
        <select v-model="method" class="select" aria-label="Method"><option value="">All methods</option><option>Cash</option><option>Mobile Money</option><option>Bank Transfer</option><option value="Card">Bank card</option></select>
        <select v-model="channel" class="select" aria-label="Channel"><option value="">Office and online</option><option value="online">Paid online</option><option value="office">At the office</option></select>
        <select v-model="status" class="select" aria-label="Status"><option value="">Any status</option><option value="verified">Verified</option><option value="pending">Awaiting verification</option><option value="rejected">Rejected</option></select>
        <select v-model="fterm" class="select" aria-label="Term"><option value="">All terms</option><option v-for="t in store.db.settings.terms" :key="t.name">{{ t.name }}</option></select>
        <input v-model="from" type="date" class="input" aria-label="From date" />
        <input v-model="to" type="date" class="input" aria-label="To date" />
      </div>
      <div class="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-line text-[13px]">
        <span class="text-muted">Verified total for this selection: <b class="text-ink tnum">{{ kwacha(filteredTotal, { decimals: true }) }}</b></span>
        <div class="flex gap-2"><button class="btn btn-secondary btn-sm" @click="exportPayments('csv')"><Download :size="14" />CSV</button><button class="btn btn-secondary btn-sm" @click="exportPayments('pdf')"><FileDown :size="14" />PDF</button></div>
      </div>
      <div v-if="payments.length" class="table-wrap"><table class="tbl">
        <thead><tr><th>Date</th><th>Reference</th><th>Student</th><th>For</th><th>Method</th><th class="text-right">Amount</th><th class="text-right">Balance after</th><th>Status</th><th></th></tr></thead>
        <tbody><tr v-for="p in rows" :key="p.id">
          <td class="whitespace-nowrap">{{ fmtDate(p.date) }}</td>
          <td class="tnum whitespace-nowrap">{{ p.reference }}<div v-if="p.externalRef" class="text-[12px] text-muted">{{ p.externalRef }}</div></td>
          <td class="whitespace-nowrap"><RouterLink :to="`/students/${p.studentId}`" class="hover:underline">{{ store.studentName(p.studentId) }}</RouterLink></td>
          <td class="whitespace-nowrap">{{ p.category }}<div class="text-[12px] text-muted">{{ p.term }}</div></td>
          <td class="whitespace-nowrap">{{ methodLabel(p) }}<span v-if="p.channel === 'online'" class="badge badge-info ml-1.5">Online</span></td>
          <td class="text-right tnum font-medium">{{ kwacha(p.amount) }}</td>
          <td class="text-right tnum text-muted">{{ p.status === 'verified' ? kwacha(p.balanceAfter) : '—' }}</td>
          <td><StatusBadge :status="p.status" /></td>
          <td class="text-right whitespace-nowrap">
            <button v-if="p.status === 'verified'" class="btn btn-ghost btn-sm" @click="receipt = p">Receipt</button>
            <button v-else-if="p.status === 'pending'" class="btn btn-ghost btn-sm" @click="tab = 'verify'">Review</button>
          </td>
        </tr></tbody>
      </table></div>
      <EmptyState v-else title="No payments match these filters" />
      <Pager v-if="payments.length" v-model="page" :pages="pages" :range="range" />
    </div>

    <div v-else-if="tab === 'balances'" class="card">
      <div class="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-line">
        <label class="flex items-center gap-2 text-[13px]"><input v-model="owingOnly" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />Only students with a balance</label>
        <button class="btn btn-secondary btn-sm" @click="exportBalances"><Download :size="14" />CSV</button>
      </div>
      <div v-if="balances.length" class="table-wrap"><table class="tbl">
        <thead><tr><th>Student</th><th>Parent</th><th>{{ term }}</th><th class="text-right">Billed</th><th class="text-right">Paid</th><th class="text-right">Balance</th><th>Last payment</th></tr></thead>
        <tbody><tr v-for="x in balances" :key="x.s.id">
          <td class="whitespace-nowrap"><RouterLink :to="`/students/${x.s.id}`" class="font-medium hover:underline">{{ x.s.firstName }} {{ x.s.lastName }}</RouterLink><div class="text-[12px] text-muted">{{ store.gradeName(x.s.gradeId) }}</div></td>
          <td class="whitespace-nowrap">{{ store.parentMap.get(x.s.parentId)?.name }}<div class="text-[12px] text-muted tnum">{{ store.parentMap.get(x.s.parentId)?.phone }}</div></td>
          <td><StatusBadge v-if="x.termState !== 'none'" :status="x.termState" /><span v-else class="text-faint">Not billed</span></td>
          <td class="text-right tnum">{{ kwacha(x.billed) }}</td><td class="text-right tnum">{{ kwacha(x.paid) }}</td>
          <td :class="['text-right tnum font-semibold', x.bal > 0 ? 'text-bad' : 'text-ok']">{{ kwacha(x.bal) }}</td>
          <td class="whitespace-nowrap text-muted">{{ x.last ? fmtDate(x.last.date) : '—' }}</td>
        </tr></tbody>
      </table></div>
      <EmptyState v-else title="No outstanding balances" body="Every student’s account is fully paid." />
    </div>

    <div v-else-if="tab === 'verify'" class="card">
      <div class="px-4 sm:px-5 pt-4 pb-3 border-b border-line"><h2 class="h-section">Payments awaiting verification</h2>
        <p class="sub">Check each transaction ID against the Mobile Money or bank statement before verifying. A recorded payment is not proof that money arrived.</p></div>
      <ul v-if="pending.length" class="divide-y divide-line">
        <li v-for="p in pending" :key="p.id" class="px-4 sm:px-5 py-3 flex flex-wrap items-center gap-3">
          <div class="flex-1 min-w-[220px]">
            <div class="font-medium">{{ kwacha(p.amount) }} · {{ store.studentName(p.studentId) }} <span v-if="p.channel === 'online'" class="badge badge-info">Reported in parent portal</span></div>
            <div class="text-[12.5px] text-muted">{{ methodLabel(p) }}<template v-if="p.externalRef"> · ref <span class="tnum text-ink">{{ p.externalRef }}</span></template> · {{ fmtDate(p.date) }} · {{ p.category }} {{ p.term }} · recorded by {{ p.recordedBy }}</div>
          </div>
          <button class="btn btn-secondary btn-sm" @click="rejecting = p; reason = ''"><X :size="14" />Reject</button>
          <button class="btn btn-primary btn-sm" @click="verify(p)"><Check :size="14" />Verify</button>
        </li>
      </ul>
      <EmptyState v-else title="Nothing to verify" body="New Mobile Money and bank payments will appear here until someone confirms them." />
    </div>

    <div v-else-if="tab === 'reminders'" class="grid lg:grid-cols-[1fr_340px] gap-4 items-start">
      <section class="card">
        <div class="px-4 sm:px-5 pt-4 pb-3 border-b border-line"><h2 class="h-section">Families with a balance</h2>
          <p class="sub">Each button opens WhatsApp or SMS with the message ready to send from the centre’s phone. Automatic bulk sending needs an SMS/WhatsApp provider (see Settings).</p></div>
        <ul v-if="families.length" class="divide-y divide-line">
          <li v-for="f in families" :key="f.pid" class="px-4 sm:px-5 py-3 flex flex-wrap items-center gap-3">
            <div class="flex-1 min-w-[220px]">
              <div class="font-medium">{{ store.parentMap.get(f.pid)?.name }} <span class="text-muted font-normal tnum">· {{ store.parentMap.get(f.pid)?.phone }}</span></div>
              <div class="text-[12.5px] text-muted">{{ f.kids.map((k) => `${k.name} ${kwacha(k.bal)}`).join(' · ') }}<template v-if="lastReminder(f.pid)"> · last reminded {{ fmtDate(lastReminder(f.pid)!.at.slice(0, 10)) }} by {{ lastReminder(f.pid)!.channel }}</template></div>
            </div>
            <span class="font-semibold tnum text-bad">{{ kwacha(f.total) }}</span>
            <a :href="waLink(store.parentMap.get(f.pid)?.phone ?? '', reminderText(f))" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm" @click="remind(f, 'WhatsApp')"><MessageCircle :size="14" />WhatsApp</a>
            <a :href="smsLink(store.parentMap.get(f.pid)?.phone ?? '', reminderText(f))" class="btn btn-secondary btn-sm" @click="remind(f, 'SMS')"><MessageSquareText :size="14" />SMS</a>
          </li>
        </ul>
        <EmptyState v-else title="No balances to chase" body="Every family is fully paid." />
      </section>
      <section class="card card-pad">
        <h2 class="h-section">Message template</h2>
        <p class="sub mb-2">Placeholders: {parent}, {child}, {balance}, {term}</p>
        <textarea v-model="store.db.settings.reminderTemplate" class="textarea min-h-[180px] text-[13px]" aria-label="Reminder message template" />
        <p class="text-[12px] text-muted mt-2">Preview for {{ families[0] ? store.parentMap.get(families[0].pid)?.name : 'a family' }}:</p>
        <p v-if="families[0]" class="text-[12.5px] mt-1 rounded-md bg-sunken p-2.5">{{ reminderText(families[0]) }}</p>
      </section>
    </div>

    <div v-else class="grid gap-4">
      <div class="card">
        <div class="flex flex-wrap items-center justify-between gap-2 px-4 sm:px-5 pt-4 pb-3 border-b border-line">
          <div><h2 class="h-section">Fee structure</h2><p class="sub">Sample amounts for the demonstration — confirm actual fees with management. Changes apply to new charges only.</p></div>
          <button class="btn btn-secondary" @click="billTerm">Raise {{ term }} charges</button>
        </div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Grade</th><th>Tuition (per term)</th><th>Registration (once)</th><th>Examination (per term)</th></tr></thead>
          <tbody><tr v-for="g in feeGrades" :key="g.id">
            <td class="font-medium">{{ g.name }}</td>
            <td v-for="cat in (['Tuition', 'Registration', 'Examination'] as const)" :key="cat">
              <div v-if="feeFor(g.id, cat)" class="relative max-w-[140px]"><span class="absolute left-3 top-1/2 -translate-y-1/2 text-muted text-[13px]">K</span>
                <input :value="feeFor(g.id, cat)!.amount" type="number" min="0" step="10" class="input pl-7 tnum h-8" :aria-label="`${g.name} ${cat} fee`" @change="setFee(feeFor(g.id, cat)!.id, $event)" /></div>
              <button v-else class="text-[12.5px] text-brand hover:underline" @click="addFee(g.id, cat)">Add fee</button>
            </td>
          </tr></tbody>
        </table></div>
      </div>
    </div>

    <PaymentFormModal :open="payOpen" @close="payOpen = false" />
    <ReceiptModal :payment="receipt" @close="receipt = null" />
    <Modal :open="!!rejecting" title="Reject payment" :sub="rejecting ? `${kwacha(rejecting.amount)} · ${store.studentName(rejecting.studentId)}` : ''" size="sm" @close="rejecting = null">
      <label class="label" for="rj">Reason</label>
      <textarea id="rj" v-model="reason" class="textarea" placeholder="e.g. Transaction ID not found on the Mobile Money statement" />
      <template #footer><button class="btn btn-secondary" @click="rejecting = null">Cancel</button><button class="btn btn-danger" @click="reject">Reject payment</button></template>
    </Modal>
  </div>
</template>
