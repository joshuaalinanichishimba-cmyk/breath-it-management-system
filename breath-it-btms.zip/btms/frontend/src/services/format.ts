export function kwacha(n: number, opts: { decimals?: boolean } = {}): string {
  const decimals = opts.decimals ?? !Number.isInteger(Math.round(n * 100) / 100)
  const sign = n < 0 ? '-' : ''
  return `${sign}K${Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: decimals ? 2 : 0, maximumFractionDigits: 2 })}`
}
export function pct(n: number, digits = 0): string {
  if (!Number.isFinite(n)) return '—'
  return `${n.toFixed(digits)}%`
}
export function round2(n: number): number { return Math.round(n * 100) / 100 }
export function initials(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]!.toUpperCase()).join('')
}
export function fullName(p: { firstName: string; lastName: string }): string { return `${p.firstName} ${p.lastName}` }
export function plural(n: number, word: string, pl = word + 's'): string { return `${n} ${n === 1 ? word : pl}` }
export function gradeBand(p: number): { label: string; tone: 'ok' | 'info' | 'warn' | 'bad' } {
  if (p >= 75) return { label: 'Distinction', tone: 'ok' }
  if (p >= 60) return { label: 'Merit', tone: 'info' }
  if (p >= 50) return { label: 'Credit', tone: 'warn' }
  if (p >= 40) return { label: 'Pass', tone: 'warn' }
  return { label: 'Below pass', tone: 'bad' }
}
