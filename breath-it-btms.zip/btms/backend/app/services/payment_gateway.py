"""
Online payment gateway (Airtel Money, MTN MoMo, Zamtel Kwacha and cards via an aggregator).

Flow
  1. POST /finance/pay creates a pending online Payment and calls `gateway.initiate(...)`.
     Mobile money: the aggregator pushes a USSD/PIN prompt to the payer's phone.
     Card: the aggregator returns a hosted checkout URL (card numbers never touch this system).
  2. The aggregator calls POST /finance/gateway/webhook when the payer approves, declines or the prompt expires.
     The webhook is authenticated with an HMAC-SHA256 signature over the raw body (header X-Signature).
  3. A confirmed event verifies the payment and issues the receipt. Events are idempotent.

Adapters
  - SandboxGateway: no network calls; for local development and automated tests (PAYMENT_GATEWAY=sandbox).
  - Real aggregators (e.g. pawaPay, DPO Pay, MoneyUnify, Bila) each need a small adapter implementing `Gateway`
    with their API keys from environment variables. None is enabled until the centre opens a merchant account.
"""
import hashlib, hmac, uuid
from dataclasses import dataclass
from typing import Protocol
from ..core.config import get_settings

NETWORK_PREFIXES = {"97": "Airtel", "77": "Airtel", "96": "MTN", "76": "MTN", "95": "Zamtel", "75": "Zamtel"}


def normalise_phone(raw: str) -> str | None:
    digits = "".join(c for c in raw if c.isdigit())
    if digits.startswith("260"):
        digits = digits[3:]
    digits = digits.lstrip("0")
    return f"0{digits}" if len(digits) == 9 and digits[0] in "79" else None


def network_for(phone: str) -> str | None:
    n = normalise_phone(phone)
    return NETWORK_PREFIXES.get(n[1:3]) if n else None


@dataclass
class InitiateResult:
    gateway_ref: str
    checkout_url: str | None = None


class Gateway(Protocol):
    name: str
    def initiate(self, *, reference: str, amount: float, method: str, network: str | None, phone: str | None, description: str) -> InitiateResult: ...


class SandboxGateway:
    name = "sandbox"
    def initiate(self, *, reference, amount, method, network, phone, description) -> InitiateResult:
        ref = f"SBX-{uuid.uuid4().hex[:12].upper()}"
        return InitiateResult(gateway_ref=ref, checkout_url=f"https://sandbox.invalid/checkout/{ref}" if method == "Card" else None)


def get_gateway() -> Gateway | None:
    name = get_settings().payment_gateway.strip().lower()
    if not name:
        return None
    if name == "sandbox":
        return SandboxGateway()
    raise NotImplementedError(f"No adapter written yet for payment gateway '{name}'.")


def sign(body: bytes) -> str:
    return hmac.new(get_settings().payment_webhook_secret.encode(), body, hashlib.sha256).hexdigest()


def signature_valid(body: bytes, signature: str | None) -> bool:
    secret = get_settings().payment_webhook_secret
    return bool(secret and signature and hmac.compare_digest(sign(body), signature))
