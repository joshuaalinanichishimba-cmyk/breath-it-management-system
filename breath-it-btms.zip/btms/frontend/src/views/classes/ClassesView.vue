<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { Plus, Pencil, Users } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Modal from '@/components/ui/Modal.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useScope } from '@/composables/useScope'
import type { ClassGroup } from '@/types'
import { DAY_SHORT } from '@/services/dates'

const store = useDb(); const ui = useUi(); const scope = useScope()
const isAdmin = computed(() => scope.role.value === 'admin')
const cards = computed(() => store.db.classes.filter((c) => scope.classIds.value.has(c.id)).map((c) => {
  const lessons = store.db.lessons.filter((l) => l.classId === c.id)
  const mine = scope.role.value === 'tutor' ? lessons.filter((l) => l.tutorId === scope.tutorId.value) : lessons
  const enrolled = store.db.students.filter((s) => s.classId === c.id && s.status === 'active')
  return { c, lessons, mine, enrolled, subjects: [...new Set(lessons.map((l) => l.subjectId))] }
}).sort((a, b) => (store.gradeMap.get(a.c.gradeId)?.order ?? 0) - (store.gradeMap.get(b.c.gradeId)?.order ?? 0)))

const rosterFor = ref<string | null>(null)
const roster = computed(() => store.db.students.filter((s) => s.classId === rosterFor.value && s.status === 'active' && scope.studentIds.value.has(s.id)).sort((a, b) => a.lastName.localeCompare(b.lastName)))

const open = ref(false); const editing = ref<ClassGroup | null>(null); const err = ref('')
const blank = () => ({ name: '', gradeId: store.db.grades[0]?.id ?? '', classTutorId: store.db.tutors[0]?.id ?? '', room: '', capacity: 20, active: true })
const f = reactive(blank())
function edit(c?: ClassGroup) { editing.value = c ?? null; Object.assign(f, blank(), c ?? {}); err.value = ''; open.value = true }
function save() {
  if (!f.name.trim() || !f.room.trim()) return (err.value = 'Class name and room are required.')
  if (!(f.capacity > 0)) return (err.value = 'Capacity must be at least 1.')
  try { store.saveClass({ ...f, name: f.name.trim(), id: editing.value?.id }); ui.success(editing.value ? 'Class updated' : 'Class created', editing.value ? undefined : 'Add its lessons on the Timetable page.'); open.value = false }
  catch (e) { err.value = (e as Error).message }
}
</script>
<template>
  <div>
    <PageHeader :title="isAdmin ? 'Classes' : 'My classes'" :sub="isAdmin ? 'Class groups, class tutors, rooms and capacity' : 'Classes where you teach at least one subject'">
      <button v-if="isAdmin" class="btn btn-primary" @click="edit()"><Plus :size="15" />New class</button>
    </PageHeader>
    <EmptyState v-if="!cards.length" title="No classes yet" body="Create a class, then add its lessons on the timetable." />
    <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
      <article v-for="x in cards" :key="x.c.id" class="card card-pad flex flex-col">
        <div class="flex items-start justify-between gap-2">
          <div><h2 class="text-[16px] font-semibold">{{ x.c.name }}</h2><div class="text-[12.5px] text-muted">{{ store.gradeName(x.c.gradeId) }} · {{ x.c.room }}</div></div>
          <span v-if="!x.c.active" class="badge badge-mute">Inactive</span>
        </div>
        <div class="mt-3">
          <div class="flex justify-between text-[12.5px]"><span class="text-muted">Enrolled</span><span class="tnum font-medium">{{ x.enrolled.length }} / {{ x.c.capacity }}</span></div>
          <div class="h-1.5 rounded-full bg-sunken mt-1 overflow-hidden"><div class="h-full rounded-full bg-brand" :style="{ width: Math.min(100, (x.enrolled.length / x.c.capacity) * 100) + '%' }" /></div>
        </div>
        <div class="text-[12.5px] mt-3"><span class="text-muted">Class tutor:</span> {{ store.tutorName(x.c.classTutorId) }}</div>
        <div class="flex flex-wrap gap-1.5 mt-3"><span v-for="s in x.subjects" :key="s" class="badge badge-mute">{{ store.subjectName(s) }}</span></div>
        <div v-if="!isAdmin" class="mt-3 text-[12.5px]"><span class="text-muted">You teach:</span>
          <span v-for="(l, i) in x.mine" :key="l.id">{{ i ? ', ' : ' ' }}{{ store.subjectName(l.subjectId) }} ({{ DAY_SHORT[l.day] }} {{ l.start }})</span></div>
        <div class="flex gap-2 mt-auto pt-4">
          <button class="btn btn-secondary btn-sm" @click="rosterFor = x.c.id"><Users :size="14" />Students</button>
          <RouterLink :to="{ path: '/timetable', query: { class: x.c.id } }" class="btn btn-ghost btn-sm">Timetable</RouterLink>
          <button v-if="isAdmin" class="btn btn-ghost btn-sm ml-auto" @click="edit(x.c)"><Pencil :size="14" />Edit</button>
        </div>
      </article>
    </div>
    <Modal :open="!!rosterFor" :title="`${store.className(rosterFor ?? '')} — students`" :sub="`${roster.length} active`" @close="rosterFor = null">
      <ul class="divide-y divide-line -my-2">
        <li v-for="s in roster" :key="s.id" class="py-2.5 flex justify-between gap-3">
          <RouterLink :to="`/students/${s.id}`" class="font-medium hover:underline">{{ s.firstName }} {{ s.lastName }}</RouterLink>
          <span class="text-[12px] text-muted text-right">{{ s.subjectIds.map(store.subjectName).join(', ') }}</span>
        </li>
      </ul>
      <EmptyState v-if="!roster.length" compact title="No active students in this class" />
    </Modal>
    <Modal :open="open" :title="editing ? 'Edit class' : 'New class'" @close="open = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
        <div><label class="label" for="cl-n">Class name</label><input id="cl-n" v-model="f.name" class="input" placeholder="e.g. Grade 9 B" /></div>
        <div><label class="label" for="cl-g">Grade</label><select id="cl-g" v-model="f.gradeId" class="select"><option v-for="g in store.db.grades" :key="g.id" :value="g.id">{{ g.name }}</option></select></div>
        <div><label class="label" for="cl-t">Class tutor</label><select id="cl-t" v-model="f.classTutorId" class="select"><option v-for="t in store.db.tutors.filter((x) => x.status === 'active')" :key="t.id" :value="t.id">{{ t.firstName }} {{ t.lastName }}</option></select></div>
        <div><label class="label" for="cl-r">Room</label><input id="cl-r" v-model="f.room" class="input" placeholder="e.g. Room 6" /></div>
        <div><label class="label" for="cl-c">Capacity</label><input id="cl-c" v-model.number="f.capacity" type="number" min="1" class="input" /></div>
        <label v-if="editing" class="flex items-center gap-2.5 text-[13px] mt-6"><input v-model="f.active" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />Class is active</label>
        <p v-if="err" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer><button class="btn btn-secondary" @click="open = false">Cancel</button><button class="btn btn-primary" @click="save">{{ editing ? 'Save changes' : 'Create class' }}</button></template>
    </Modal>
  </div>
</template>
