from datetime import date
from sqlalchemy import Boolean, Column, Date, ForeignKey, String, Table, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db import Base, new_id

tutor_subjects = Table(
    "tutor_subjects", Base.metadata,
    Column("tutor_id", ForeignKey("tutors.id", ondelete="CASCADE"), primary_key=True),
    Column("subject_id", ForeignKey("subjects.id", ondelete="CASCADE"), primary_key=True),
)
student_subjects = Table(
    "student_subjects", Base.metadata,
    Column("student_id", ForeignKey("students.id", ondelete="CASCADE"), primary_key=True),
    Column("subject_id", ForeignKey("subjects.id", ondelete="CASCADE"), primary_key=True),
)


class Parent(Base):
    __tablename__ = "parents"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("p-"))
    name: Mapped[str] = mapped_column(String(120), index=True)
    relationship_to_student: Mapped[str] = mapped_column(String(30), default="Guardian")
    phone: Mapped[str] = mapped_column(String(20), index=True)
    alt_phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    email: Mapped[str | None] = mapped_column(String(254), nullable=True)
    address: Mapped[str] = mapped_column(String(200), default="")
    occupation: Mapped[str | None] = mapped_column(String(80), nullable=True)
    portal_access: Mapped[bool] = mapped_column(Boolean, default=True)
    referral_code: Mapped[str | None] = mapped_column(String(20), unique=True, nullable=True)
    children: Mapped[list["Student"]] = relationship(back_populates="parent")


class Tutor(Base):
    __tablename__ = "tutors"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("t-"))
    staff_no: Mapped[str] = mapped_column(String(20), unique=True)
    first_name: Mapped[str] = mapped_column(String(60))
    last_name: Mapped[str] = mapped_column(String(60))
    gender: Mapped[str] = mapped_column(String(10))
    phone: Mapped[str] = mapped_column(String(20))
    email: Mapped[str] = mapped_column(String(254), unique=True)
    qualification: Mapped[str] = mapped_column(String(160), default="")
    hire_date: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(12), default="active")  # active | on_leave | inactive
    subjects: Mapped[list["Subject"]] = relationship("Subject", secondary=tutor_subjects)  # noqa: F821


class Student(Base):
    __tablename__ = "students"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("st-"))
    student_no: Mapped[str] = mapped_column(String(20), unique=True, index=True)
    first_name: Mapped[str] = mapped_column(String(60), index=True)
    last_name: Mapped[str] = mapped_column(String(60), index=True)
    date_of_birth: Mapped[date] = mapped_column(Date)
    gender: Mapped[str] = mapped_column(String(10))
    grade_id: Mapped[str] = mapped_column(ForeignKey("grades.id"), index=True)
    class_id: Mapped[str] = mapped_column(ForeignKey("classes.id"), index=True)
    parent_id: Mapped[str] = mapped_column(ForeignKey("parents.id"), index=True)
    alt_contact: Mapped[str | None] = mapped_column(String(20), nullable=True)
    address: Mapped[str] = mapped_column(String(200), default="")
    enrolment_date: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(12), default="active", index=True)  # active | inactive | suspended | completed
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    parent: Mapped[Parent] = relationship(back_populates="children")
    subjects: Mapped[list["Subject"]] = relationship("Subject", secondary=student_subjects)  # noqa: F821

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"


class Enrolment(Base):
    """Enrolment history: registration, class/grade moves, status changes."""
    __tablename__ = "enrolments"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("ev-"))
    student_id: Mapped[str] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    event_date: Mapped[date] = mapped_column(Date)
    action: Mapped[str] = mapped_column(String(40))
    detail: Mapped[str] = mapped_column(String(300), default="")
