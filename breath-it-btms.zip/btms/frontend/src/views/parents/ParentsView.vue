<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { Plus, Search, Pencil } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Pager from '@/components/ui/Pager.vue'
import Modal from '@/components/ui/Modal.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import Avatar from '@/components/ui/Avatar.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { usePager } from '@/composables/usePager'
import type { Parent } from '@/types'
import { kwacha } from '@/services/format'

const store = useDb(); const ui = useUi()
const q = ref('')
const rows = computed(() => store.db.parents.map((p) => {
  const kids = store.db.students.filter((s) => s.parentId === p.id)
  return { p, kids, bal: kids.reduce((a, k) => a + Math.max(0, store.balance(k.id)), 0) }
}).filter(({ p, kids }) => {
  const t = q.value.trim().toLowerCase()
  return !t || `${p.name} ${p.phone} ${p.email ?? ''} ${kids.map((k) => k.firstName + ' ' + k.lastName).join(' ')}`.toLowerCase().includes(t)
}).sort((a, b) => a.p.name.localeCompare(b.p.name)))
const { page, pages, rows: pageRows, range } = usePager(rows, 12)

const open = ref(false); const editing = ref<Parent | null>(null); const err = ref('')
const blank = () => ({ name: '', relationship: 'Mother' as Parent['relationship'], phone: '', altPhone: '', email: '', address: '', occupation: '', portalAccess: true })
const f = reactive(blank())
function edit(p?: Parent) { editing.value = p ?? null; Object.assign(f, blank(), p ? { ...p, altPhone: p.altPhone ?? '', email: p.email ?? '', occupation: p.occupation ?? '' } : {}); err.value = ''; open.value = true }
const phoneOk = (p: string) => /^(\+?260|0)[79]\d{8}$/.test(p.replace(/[\s-]/g, ''))
function save() {
  if (!f.name.trim() || !f.address.trim()) return (err.value = 'Name and address are required.')
  if (!phoneOk(f.phone)) return (err.value = 'Enter a valid Zambian phone number, e.g. 0977 123 456.')
  if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) return (err.value = 'Enter a valid email address or leave it blank.')
  const data = { ...f, altPhone: f.altPhone || undefined, email: f.email || undefined, occupation: f.occupation || undefined }
  if (editing.value) { store.updateParent(editing.value.id, data); ui.success('Parent updated') }
  else { store.addParent(data); ui.success('Parent added', 'Link them to a child when registering the student.') }
  open.value = false
}
</script>
<template>
  <div>
    <PageHeader title="Parents and guardians" :sub="`${store.db.parents.length} families · one account can follow several children`">
      <button class="btn btn-primary" @click="edit()"><Plus :size="15" />Add parent</button>
    </PageHeader>
    <div class="card">
      <div class="p-3 sm:p-4 border-b border-line"><div class="relative max-w-md"><Search :size="15" class="absolute left-3 top-1/2 -translate-y-1/2 text-faint" /><input v-model="q" class="input pl-9" placeholder="Search parent, phone or child" aria-label="Search parents" /></div></div>
      <div v-if="rows.length" class="table-wrap"><table class="tbl">
        <thead><tr><th>Parent / guardian</th><th>Contact</th><th>Children</th><th class="text-right">Family balance</th><th>Portal</th><th></th></tr></thead>
        <tbody><tr v-for="{ p, kids, bal } in pageRows" :key="p.id">
          <td><div class="flex items-center gap-2.5"><Avatar :name="p.name" :size="30" /><div><div class="font-medium">{{ p.name }}</div><div class="text-[12px] text-muted">{{ p.relationship }}{{ p.occupation ? ' · ' + p.occupation : '' }}</div></div></div></td>
          <td class="whitespace-nowrap tnum">{{ p.phone }}<div class="text-[12px] text-muted">{{ p.email ?? p.address }}</div></td>
          <td><RouterLink v-for="k in kids" :key="k.id" :to="`/students/${k.id}`" class="block hover:underline whitespace-nowrap">{{ k.firstName }} {{ k.lastName }} <span class="text-muted">· {{ store.gradeName(k.gradeId) }}</span></RouterLink><span v-if="!kids.length" class="text-faint">None linked</span></td>
          <td :class="['text-right tnum font-medium', bal > 0 ? 'text-bad' : 'text-muted']">{{ bal > 0 ? kwacha(bal) : 'Paid' }}</td>
          <td><span :class="['badge', p.portalAccess ? 'badge-ok' : 'badge-mute']">{{ p.portalAccess ? 'Enabled' : 'Off' }}</span></td>
          <td class="text-right"><button class="icon-btn" :aria-label="`Edit ${p.name}`" @click="edit(p)"><Pencil :size="15" /></button></td>
        </tr></tbody>
      </table></div>
      <EmptyState v-else title="No parents match your search" />
      <Pager v-if="rows.length" v-model="page" :pages="pages" :range="range" />
    </div>
    <Modal :open="open" :title="editing ? 'Edit parent' : 'Add parent or guardian'" size="lg" @close="open = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
        <div><label class="label" for="pa-n">Full name</label><input id="pa-n" v-model="f.name" class="input" /></div>
        <div><label class="label" for="pa-r">Relationship</label><select id="pa-r" v-model="f.relationship" class="select"><option>Mother</option><option>Father</option><option>Guardian</option><option>Aunt</option><option>Uncle</option><option>Grandparent</option></select></div>
        <div><label class="label" for="pa-p">Phone</label><input id="pa-p" v-model="f.phone" class="input" placeholder="0977 123 456" /></div>
        <div><label class="label" for="pa-a">Alternative phone</label><input id="pa-a" v-model="f.altPhone" class="input" placeholder="Optional" /></div>
        <div><label class="label" for="pa-e">Email</label><input id="pa-e" v-model="f.email" type="email" class="input" placeholder="Optional" /></div>
        <div><label class="label" for="pa-o">Occupation</label><input id="pa-o" v-model="f.occupation" class="input" placeholder="Optional" /></div>
        <div class="sm:col-span-2"><label class="label" for="pa-ad">Address</label><input id="pa-ad" v-model="f.address" class="input" /></div>
        <label class="sm:col-span-2 flex items-center gap-2.5 text-[13px]"><input v-model="f.portalAccess" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />Allow access to the parent portal</label>
        <p v-if="err" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer><button class="btn btn-secondary" @click="open = false">Cancel</button><button class="btn btn-primary" @click="save">{{ editing ? 'Save changes' : 'Add parent' }}</button></template>
    </Modal>
  </div>
</template>
