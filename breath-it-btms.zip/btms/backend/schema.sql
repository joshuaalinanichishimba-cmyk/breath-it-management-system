-- Breath It Tuition Centre Management System — PostgreSQL schema
-- Generated from backend/app/models. Do not edit by hand; run scripts/export_schema.py.

CREATE TABLE audit_logs (
	id VARCHAR(40) NOT NULL, 
	at TIMESTAMP WITH TIME ZONE NOT NULL, 
	actor_id VARCHAR(40) NOT NULL, 
	actor_name VARCHAR(120) NOT NULL, 
	action VARCHAR(60) NOT NULL, 
	entity VARCHAR(40) NOT NULL, 
	entity_id VARCHAR(60) NOT NULL, 
	detail TEXT NOT NULL, 
	ip_address VARCHAR(45), 
	PRIMARY KEY (id)
);
CREATE INDEX ix_audit_logs_action ON audit_logs (action);
CREATE INDEX ix_audit_logs_actor_id ON audit_logs (actor_id);
CREATE INDEX ix_audit_logs_at ON audit_logs (at);

CREATE TABLE centre_settings (
	key VARCHAR(60) NOT NULL, 
	value JSON NOT NULL, 
	PRIMARY KEY (key)
);

CREATE TABLE grades (
	id VARCHAR(40) NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	sort_order INTEGER NOT NULL, 
	exam_level VARCHAR(120) NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);

CREATE TABLE parents (
	id VARCHAR(40) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	relationship_to_student VARCHAR(30) NOT NULL, 
	phone VARCHAR(20) NOT NULL, 
	alt_phone VARCHAR(20), 
	email VARCHAR(254), 
	address VARCHAR(200) NOT NULL, 
	occupation VARCHAR(80), 
	portal_access BOOLEAN NOT NULL, 
	referral_code VARCHAR(20), 
	PRIMARY KEY (id), 
	UNIQUE (referral_code)
);
CREATE INDEX ix_parents_name ON parents (name);
CREATE INDEX ix_parents_phone ON parents (phone);

CREATE TABLE roles (
	name VARCHAR(20) NOT NULL, 
	description VARCHAR(200) NOT NULL, 
	PRIMARY KEY (name)
);

CREATE TABLE subjects (
	id VARCHAR(40) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	code VARCHAR(12) NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (code)
);

CREATE TABLE tutors (
	id VARCHAR(40) NOT NULL, 
	staff_no VARCHAR(20) NOT NULL, 
	first_name VARCHAR(60) NOT NULL, 
	last_name VARCHAR(60) NOT NULL, 
	gender VARCHAR(10) NOT NULL, 
	phone VARCHAR(20) NOT NULL, 
	email VARCHAR(254) NOT NULL, 
	qualification VARCHAR(160) NOT NULL, 
	hire_date DATE NOT NULL, 
	status VARCHAR(12) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (staff_no), 
	UNIQUE (email)
);

CREATE TABLE classes (
	id VARCHAR(40) NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	grade_id VARCHAR(40) NOT NULL, 
	class_tutor_id VARCHAR(40), 
	room VARCHAR(40) NOT NULL, 
	capacity INTEGER NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_class_capacity CHECK (capacity > 0), 
	UNIQUE (name), 
	FOREIGN KEY(grade_id) REFERENCES grades (id), 
	FOREIGN KEY(class_tutor_id) REFERENCES tutors (id) ON DELETE SET NULL
);
CREATE INDEX ix_classes_grade_id ON classes (grade_id);

CREATE TABLE fee_structures (
	id VARCHAR(60) NOT NULL, 
	grade_id VARCHAR(40) NOT NULL, 
	category VARCHAR(20) NOT NULL, 
	amount NUMERIC(12, 2) NOT NULL, 
	frequency VARCHAR(10) NOT NULL, 
	description VARCHAR(160) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_fee_grade_category UNIQUE (grade_id, category), 
	CONSTRAINT ck_fee_amount CHECK (amount >= 0), 
	FOREIGN KEY(grade_id) REFERENCES grades (id) ON DELETE CASCADE
);
CREATE INDEX ix_fee_structures_grade_id ON fee_structures (grade_id);

CREATE TABLE grade_subjects (
	grade_id VARCHAR(40) NOT NULL, 
	subject_id VARCHAR(40) NOT NULL, 
	PRIMARY KEY (grade_id, subject_id), 
	FOREIGN KEY(grade_id) REFERENCES grades (id) ON DELETE CASCADE, 
	FOREIGN KEY(subject_id) REFERENCES subjects (id) ON DELETE CASCADE
);

CREATE TABLE reminder_logs (
	id VARCHAR(40) NOT NULL, 
	parent_id VARCHAR(40) NOT NULL, 
	at TIMESTAMP WITH TIME ZONE NOT NULL, 
	channel VARCHAR(10) NOT NULL, 
	amount NUMERIC(12, 2) NOT NULL, 
	sent_by VARCHAR(120) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(parent_id) REFERENCES parents (id) ON DELETE CASCADE
);
CREATE INDEX ix_reminder_logs_parent_id ON reminder_logs (parent_id);

CREATE TABLE tutor_subjects (
	tutor_id VARCHAR(40) NOT NULL, 
	subject_id VARCHAR(40) NOT NULL, 
	PRIMARY KEY (tutor_id, subject_id), 
	FOREIGN KEY(tutor_id) REFERENCES tutors (id) ON DELETE CASCADE, 
	FOREIGN KEY(subject_id) REFERENCES subjects (id) ON DELETE CASCADE
);

CREATE TABLE announcements (
	id VARCHAR(40) NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	body TEXT NOT NULL, 
	audience VARCHAR(12) NOT NULL, 
	class_id VARCHAR(40), 
	priority VARCHAR(10) NOT NULL, 
	author_id VARCHAR(40) NOT NULL, 
	author_name VARCHAR(120) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	sms_status VARCHAR(16) NOT NULL, 
	whatsapp_status VARCHAR(16) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id) ON DELETE CASCADE
);
CREATE INDEX ix_announcements_audience ON announcements (audience);
CREATE INDEX ix_announcements_created_at ON announcements (created_at);

CREATE TABLE assessments (
	id VARCHAR(40) NOT NULL, 
	class_id VARCHAR(40) NOT NULL, 
	subject_id VARCHAR(40) NOT NULL, 
	tutor_id VARCHAR(40), 
	assessment_type VARCHAR(20) NOT NULL, 
	title VARCHAR(120) NOT NULL, 
	max_marks NUMERIC(6, 2) NOT NULL, 
	assessment_date DATE NOT NULL, 
	term VARCHAR(30) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_assessment_max CHECK (max_marks > 0), 
	CONSTRAINT uq_assessment_sitting UNIQUE (class_id, subject_id, title, assessment_date), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(tutor_id) REFERENCES tutors (id) ON DELETE SET NULL
);
CREATE INDEX ix_assessments_assessment_date ON assessments (assessment_date);
CREATE INDEX ix_assessments_class_id ON assessments (class_id);
CREATE INDEX ix_assessments_subject_id ON assessments (subject_id);
CREATE INDEX ix_assessments_term ON assessments (term);

CREATE TABLE learning_materials (
	id VARCHAR(40) NOT NULL, 
	title VARCHAR(160) NOT NULL, 
	description VARCHAR(400) NOT NULL, 
	kind VARCHAR(20) NOT NULL, 
	subject_id VARCHAR(40) NOT NULL, 
	class_id VARCHAR(40) NOT NULL, 
	tutor_id VARCHAR(40), 
	content TEXT, 
	link VARCHAR(500), 
	file_key VARCHAR(300), 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id) ON DELETE CASCADE, 
	FOREIGN KEY(tutor_id) REFERENCES tutors (id) ON DELETE SET NULL
);
CREATE INDEX ix_learning_materials_class_id ON learning_materials (class_id);
CREATE INDEX ix_learning_materials_subject_id ON learning_materials (subject_id);

CREATE TABLE students (
	id VARCHAR(40) NOT NULL, 
	student_no VARCHAR(20) NOT NULL, 
	first_name VARCHAR(60) NOT NULL, 
	last_name VARCHAR(60) NOT NULL, 
	date_of_birth DATE NOT NULL, 
	gender VARCHAR(10) NOT NULL, 
	grade_id VARCHAR(40) NOT NULL, 
	class_id VARCHAR(40) NOT NULL, 
	parent_id VARCHAR(40) NOT NULL, 
	alt_contact VARCHAR(20), 
	address VARCHAR(200) NOT NULL, 
	enrolment_date DATE NOT NULL, 
	status VARCHAR(12) NOT NULL, 
	notes TEXT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(grade_id) REFERENCES grades (id), 
	FOREIGN KEY(class_id) REFERENCES classes (id), 
	FOREIGN KEY(parent_id) REFERENCES parents (id)
);
CREATE INDEX ix_students_class_id ON students (class_id);
CREATE INDEX ix_students_first_name ON students (first_name);
CREATE INDEX ix_students_grade_id ON students (grade_id);
CREATE INDEX ix_students_last_name ON students (last_name);
CREATE INDEX ix_students_parent_id ON students (parent_id);
CREATE INDEX ix_students_status ON students (status);
CREATE UNIQUE INDEX ix_students_student_no ON students (student_no);

CREATE TABLE timetable_slots (
	id VARCHAR(40) NOT NULL, 
	class_id VARCHAR(40) NOT NULL, 
	subject_id VARCHAR(40) NOT NULL, 
	tutor_id VARCHAR(40) NOT NULL, 
	day_of_week SMALLINT NOT NULL, 
	start_time TIME WITHOUT TIME ZONE NOT NULL, 
	end_time TIME WITHOUT TIME ZONE NOT NULL, 
	room VARCHAR(40) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_slot_day CHECK (day_of_week BETWEEN 1 AND 7), 
	CONSTRAINT ck_slot_times CHECK (end_time > start_time), 
	CONSTRAINT uq_slot_tutor_start UNIQUE (tutor_id, day_of_week, start_time), 
	CONSTRAINT uq_slot_room_start UNIQUE (room, day_of_week, start_time), 
	FOREIGN KEY(class_id) REFERENCES classes (id) ON DELETE CASCADE, 
	FOREIGN KEY(subject_id) REFERENCES subjects (id), 
	FOREIGN KEY(tutor_id) REFERENCES tutors (id)
);
CREATE INDEX ix_timetable_slots_class_id ON timetable_slots (class_id);
CREATE INDEX ix_timetable_slots_subject_id ON timetable_slots (subject_id);
CREATE INDEX ix_timetable_slots_tutor_id ON timetable_slots (tutor_id);

CREATE TABLE charges (
	id VARCHAR(40) NOT NULL, 
	student_id VARCHAR(40) NOT NULL, 
	category VARCHAR(20) NOT NULL, 
	term VARCHAR(30) NOT NULL, 
	amount NUMERIC(12, 2) NOT NULL, 
	description VARCHAR(160) NOT NULL, 
	issued_on DATE NOT NULL, 
	due_date DATE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_charge_amount CHECK ((category = 'Discount' AND amount < 0) OR (category <> 'Discount' AND amount > 0)), 
	FOREIGN KEY(student_id) REFERENCES students (id) ON DELETE CASCADE
);
CREATE INDEX ix_charges_student_id ON charges (student_id);
CREATE INDEX ix_charges_term ON charges (term);

CREATE TABLE enrolments (
	id VARCHAR(40) NOT NULL, 
	student_id VARCHAR(40) NOT NULL, 
	event_date DATE NOT NULL, 
	action VARCHAR(40) NOT NULL, 
	detail VARCHAR(300) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(student_id) REFERENCES students (id) ON DELETE CASCADE
);
CREATE INDEX ix_enrolments_student_id ON enrolments (student_id);

CREATE TABLE examination_results (
	id VARCHAR(40) NOT NULL, 
	assessment_id VARCHAR(40) NOT NULL, 
	student_id VARCHAR(40) NOT NULL, 
	marks NUMERIC(6, 2) NOT NULL, 
	comment TEXT NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_result_once UNIQUE (assessment_id, student_id), 
	CONSTRAINT ck_result_marks CHECK (marks >= 0), 
	FOREIGN KEY(assessment_id) REFERENCES assessments (id) ON DELETE CASCADE, 
	FOREIGN KEY(student_id) REFERENCES students (id) ON DELETE CASCADE
);
CREATE INDEX ix_examination_results_assessment_id ON examination_results (assessment_id);
CREATE INDEX ix_examination_results_student_id ON examination_results (student_id);

CREATE TABLE leads (
	id VARCHAR(40) NOT NULL, 
	child_name VARCHAR(120) NOT NULL, 
	grade_id VARCHAR(40) NOT NULL, 
	subject_ids JSON NOT NULL, 
	parent_name VARCHAR(120) NOT NULL, 
	phone VARCHAR(20) NOT NULL, 
	source VARCHAR(20) NOT NULL, 
	referred_by_parent_id VARCHAR(40), 
	stage VARCHAR(12) NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	follow_up_on DATE, 
	notes TEXT NOT NULL, 
	lost_reason VARCHAR(120), 
	student_id VARCHAR(40), 
	reward_applied BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_lead_stage CHECK (stage IN ('new','contacted','trial','enrolled','lost')), 
	FOREIGN KEY(grade_id) REFERENCES grades (id), 
	FOREIGN KEY(referred_by_parent_id) REFERENCES parents (id) ON DELETE SET NULL, 
	FOREIGN KEY(student_id) REFERENCES students (id) ON DELETE SET NULL
);
CREATE INDEX ix_leads_phone ON leads (phone);
CREATE INDEX ix_leads_stage ON leads (stage);

CREATE TABLE payments (
	id VARCHAR(40) NOT NULL, 
	reference VARCHAR(20) NOT NULL, 
	student_id VARCHAR(40) NOT NULL, 
	amount NUMERIC(12, 2) NOT NULL, 
	payment_date DATE NOT NULL, 
	method VARCHAR(20) NOT NULL, 
	channel VARCHAR(8) NOT NULL, 
	network VARCHAR(8), 
	payer_phone VARCHAR(15), 
	gateway_ref VARCHAR(80), 
	gateway_status VARCHAR(20), 
	category VARCHAR(20) NOT NULL, 
	term VARCHAR(30) NOT NULL, 
	external_ref VARCHAR(60), 
	status VARCHAR(10) NOT NULL, 
	recorded_by VARCHAR(120) NOT NULL, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	verified_by VARCHAR(120), 
	verified_at TIMESTAMP WITH TIME ZONE, 
	balance_after NUMERIC(12, 2) NOT NULL, 
	notes TEXT, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_payment_amount CHECK (amount > 0), 
	CONSTRAINT ck_payment_status CHECK (status IN ('pending','verified','rejected')), 
	CONSTRAINT ck_payment_method CHECK (method IN ('Cash','Mobile Money','Bank Transfer','Card')), 
	CONSTRAINT ck_payment_network CHECK (network IS NULL OR network IN ('Airtel','MTN','Zamtel')), 
	UNIQUE (reference), 
	FOREIGN KEY(student_id) REFERENCES students (id), 
	UNIQUE (gateway_ref), 
	UNIQUE (external_ref)
);
CREATE INDEX ix_payments_payment_date ON payments (payment_date);
CREATE INDEX ix_payments_status ON payments (status);
CREATE INDEX ix_payments_student_id ON payments (student_id);
CREATE INDEX ix_payments_term ON payments (term);

CREATE TABLE student_subjects (
	student_id VARCHAR(40) NOT NULL, 
	subject_id VARCHAR(40) NOT NULL, 
	PRIMARY KEY (student_id, subject_id), 
	FOREIGN KEY(student_id) REFERENCES students (id) ON DELETE CASCADE, 
	FOREIGN KEY(subject_id) REFERENCES subjects (id) ON DELETE CASCADE
);

CREATE TABLE users (
	id VARCHAR(40) NOT NULL, 
	email VARCHAR(254) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	password_hash VARCHAR(100) NOT NULL, 
	tutor_id VARCHAR(40), 
	student_id VARCHAR(40), 
	parent_id VARCHAR(40), 
	is_active BOOLEAN NOT NULL, 
	is_demo BOOLEAN NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	last_login_at TIMESTAMP WITH TIME ZONE, 
	PRIMARY KEY (id), 
	FOREIGN KEY(role) REFERENCES roles (name), 
	FOREIGN KEY(tutor_id) REFERENCES tutors (id) ON DELETE SET NULL, 
	FOREIGN KEY(student_id) REFERENCES students (id) ON DELETE SET NULL, 
	FOREIGN KEY(parent_id) REFERENCES parents (id) ON DELETE SET NULL
);
CREATE UNIQUE INDEX ix_users_email ON users (email);
CREATE INDEX ix_users_role ON users (role);

CREATE TABLE attendance (
	id VARCHAR(40) NOT NULL, 
	student_id VARCHAR(40) NOT NULL, 
	slot_id VARCHAR(40) NOT NULL, 
	lesson_date DATE NOT NULL, 
	status VARCHAR(8) NOT NULL, 
	recorded_by VARCHAR(40) NOT NULL, 
	recorded_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_attendance_once_per_lesson UNIQUE (student_id, slot_id, lesson_date), 
	CONSTRAINT ck_attendance_status CHECK (status IN ('present','absent','late')), 
	FOREIGN KEY(student_id) REFERENCES students (id) ON DELETE CASCADE, 
	FOREIGN KEY(slot_id) REFERENCES timetable_slots (id) ON DELETE CASCADE, 
	FOREIGN KEY(recorded_by) REFERENCES users (id)
);
CREATE INDEX ix_attendance_lesson_date ON attendance (lesson_date);
CREATE INDEX ix_attendance_slot_id ON attendance (slot_id);
CREATE INDEX ix_attendance_student_id ON attendance (student_id);

CREATE TABLE receipts (
	id VARCHAR(40) NOT NULL, 
	receipt_no VARCHAR(20) NOT NULL, 
	payment_id VARCHAR(40) NOT NULL, 
	issued_at TIMESTAMP WITH TIME ZONE NOT NULL, 
	issued_by VARCHAR(120) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (receipt_no), 
	UNIQUE (payment_id), 
	FOREIGN KEY(payment_id) REFERENCES payments (id) ON DELETE CASCADE
);
