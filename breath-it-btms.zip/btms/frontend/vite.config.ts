import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { viteSingleFile } from 'vite-plugin-singlefile'
import { fileURLToPath, URL } from 'node:url'

// Two build targets:
//  - default: multi-file static build for GitHub Pages (hash routing, relative base)
//  - "singlefile": everything inlined into one index.html (used for the hosted preview link)
export default defineConfig(({ mode }) => ({
  base: './',
  plugins: [vue(), ...(mode === 'singlefile' ? [viteSingleFile()] : [])],
  resolve: { alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) } },
  build: {
    outDir: mode === 'singlefile' ? 'dist-single' : 'dist',
    chunkSizeWarningLimit: 1500,
  },
}))
