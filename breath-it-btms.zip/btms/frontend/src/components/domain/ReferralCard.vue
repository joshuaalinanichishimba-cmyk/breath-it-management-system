<script setup lang="ts">
import { computed } from 'vue'
import { Gift, Copy } from 'lucide-vue-next'
import { useDb } from '@/stores/db'
import { useAuth } from '@/stores/auth'
import { useUi } from '@/stores/ui'
import { kwacha } from '@/services/format'
import { waLink } from '@/services/whatsapp'

const store = useDb(); const auth = useAuth(); const ui = useUi()
const pid = computed(() => auth.user?.linkedId ?? '')
const code = computed(() => store.db.referralCodes[pid.value] ?? '')
const reward = computed(() => store.db.settings.referralReward)
const mine = computed(() => store.db.leads.filter((l) => l.referredByParentId === pid.value))
const message = computed(() => `My children attend Breath It Tuition Centre in Kaunda Square Stage 2 (Grades 7, 8, 9, 12 and GCE). Mention my code ${code.value} when you enquire — call ${store.db.settings.phone}.`)
const stageLabel: Record<string, string> = { new: 'Enquired', contacted: 'Contacted', trial: 'Trial lesson', enrolled: 'Enrolled', lost: 'Did not join' }
async function copy() { try { await navigator.clipboard.writeText(code.value); ui.info('Code copied', code.value) } catch { ui.info('Your code', code.value) } }
</script>
<template>
  <section v-if="code && reward > 0" class="card card-pad">
    <div class="flex items-start gap-3">
      <div class="h-9 w-9 rounded-md bg-brand-soft text-brand flex items-center justify-center shrink-0"><Gift :size="18" /></div>
      <div class="flex-1 min-w-0">
        <h2 class="h-section">Invite a family, get {{ kwacha(reward) }} off your fees</h2>
        <p class="sub mt-0.5">When a family you refer enrols, {{ kwacha(reward) }} comes off your next balance.</p>
        <div class="flex flex-wrap items-center gap-2 mt-3">
          <button class="h-9 px-3 rounded-md border border-dashed border-brand text-brand font-semibold tnum tracking-wide flex items-center gap-2" @click="copy">{{ code }}<Copy :size="14" /></button>
          <a :href="waLink(null, message)" target="_blank" rel="noopener noreferrer" class="btn btn-primary">Share on WhatsApp</a>
        </div>
        <ul v-if="mine.length" class="mt-4 grid gap-1.5 text-[13px]">
          <li v-for="l in mine" :key="l.id" class="flex justify-between gap-2"><span>{{ l.childName }}</span>
            <span :class="['badge', l.stage === 'enrolled' ? 'badge-ok' : l.stage === 'lost' ? 'badge-mute' : 'badge-info']">{{ stageLabel[l.stage] }}{{ l.rewardApplied ? ' · reward applied' : '' }}</span></li>
        </ul>
      </div>
    </div>
  </section>
</template>
