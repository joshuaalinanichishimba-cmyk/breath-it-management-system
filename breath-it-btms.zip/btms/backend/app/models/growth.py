from datetime import date, datetime
from sqlalchemy import Boolean, Date, DateTime, ForeignKey, JSON, Numeric, String, Text, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column
from ..db import Base, new_id
from .users import utcnow


class Lead(Base):
    """An enquiry from a prospective family, tracked from first contact to enrolment."""
    __tablename__ = "leads"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("ld-"))
    child_name: Mapped[str] = mapped_column(String(120))
    grade_id: Mapped[str] = mapped_column(ForeignKey("grades.id"))
    subject_ids: Mapped[list] = mapped_column(JSON, default=list)
    parent_name: Mapped[str] = mapped_column(String(120))
    phone: Mapped[str] = mapped_column(String(20), index=True)
    source: Mapped[str] = mapped_column(String(20))
    referred_by_parent_id: Mapped[str | None] = mapped_column(ForeignKey("parents.id", ondelete="SET NULL"), nullable=True)
    stage: Mapped[str] = mapped_column(String(12), default="new", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    follow_up_on: Mapped[date | None] = mapped_column(Date, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    lost_reason: Mapped[str | None] = mapped_column(String(120), nullable=True)
    student_id: Mapped[str | None] = mapped_column(ForeignKey("students.id", ondelete="SET NULL"), nullable=True)
    reward_applied: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (CheckConstraint("stage IN ('new','contacted','trial','enrolled','lost')", name="ck_lead_stage"),)


class ReminderLog(Base):
    __tablename__ = "reminder_logs"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("rm-"))
    parent_id: Mapped[str] = mapped_column(ForeignKey("parents.id", ondelete="CASCADE"), index=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    channel: Mapped[str] = mapped_column(String(10))
    amount: Mapped[float] = mapped_column(Numeric(12, 2))
    sent_by: Mapped[str] = mapped_column(String(120))
