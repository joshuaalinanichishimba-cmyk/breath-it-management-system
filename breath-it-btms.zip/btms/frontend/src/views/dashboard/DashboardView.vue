<script setup lang="ts">
import { computed } from 'vue'
import { useAuth } from '@/stores/auth'
import AdminDashboard from './AdminDashboard.vue'
import TutorDashboard from './TutorDashboard.vue'
import StudentDashboard from './StudentDashboard.vue'
import ParentDashboard from './ParentDashboard.vue'
const auth = useAuth()
const view = computed(() => ({ admin: AdminDashboard, tutor: TutorDashboard, student: StudentDashboard, parent: ParentDashboard })[auth.role ?? 'student'])
</script>
<template><component :is="view" /></template>
