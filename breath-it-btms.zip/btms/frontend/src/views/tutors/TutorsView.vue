<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { Plus, Pencil, Phone } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Modal from '@/components/ui/Modal.vue'
import Avatar from '@/components/ui/Avatar.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import type { Tutor } from '@/types'
import { iso, addDays, fmtDate } from '@/services/dates'
import { pct } from '@/services/format'
import { average, pctOf } from '@/services/analytics'

const store = useDb(); const ui = useUi()
const since = addDays(iso(), -28)
const cards = computed(() => store.db.tutors.map((t) => {
  const lessons = store.db.lessons.filter((l) => l.tutorId === t.id)
  const classIds = [...new Set(lessons.map((l) => l.classId))]
  const registers = new Set(store.db.attendance.filter((a) => a.date >= since && lessons.some((l) => l.id === a.lessonId)).map((a) => a.lessonId + a.date)).size
  const marks = store.db.assessments.filter((a) => a.tutorId === t.id && a.term === store.db.settings.currentTerm)
  const students = new Set(store.db.students.filter((s) => s.status === 'active' && lessons.some((l) => l.classId === s.classId && s.subjectIds.includes(l.subjectId))).map((s) => s.id)).size
  return { t, lessons: lessons.length, classIds, registers, avg: average(marks.map(pctOf)), marks: marks.length, students }
}))

const open = ref(false); const editing = ref<Tutor | null>(null); const err = ref('')
const blank = () => ({ firstName: '', lastName: '', gender: 'Female' as Tutor['gender'], phone: '', email: '', qualification: '', subjectIds: [] as string[], hireDate: iso(), status: 'active' as Tutor['status'] })
const f = reactive(blank())
function edit(t?: Tutor) { editing.value = t ?? null; Object.assign(f, blank(), t ? { ...t, subjectIds: [...t.subjectIds] } : {}); err.value = ''; open.value = true }
function save() {
  if (!f.firstName.trim() || !f.lastName.trim()) return (err.value = 'First and last name are required.')
  if (!/^(\+?260|0)[79]\d{8}$/.test(f.phone.replace(/[\s-]/g, ''))) return (err.value = 'Enter a valid Zambian phone number.')
  if (!/^\S+@\S+\.\S+$/.test(f.email)) return (err.value = 'Enter a valid email — the tutor signs in with it.')
  if (!f.subjectIds.length) return (err.value = 'Choose at least one subject.')
  if (editing.value) { store.updateTutor(editing.value.id, { ...f }); ui.success('Tutor updated') }
  else { const t = store.addTutor({ ...f }); ui.success('Tutor added', `${t.staffNo} — assign lessons on the Timetable page.`) }
  open.value = false
}
</script>
<template>
  <div>
    <PageHeader title="Tutors" :sub="`${store.db.tutors.filter((t) => t.status === 'active').length} active tutors · activity over the last 4 weeks`">
      <button class="btn btn-primary" @click="edit()"><Plus :size="15" />Add tutor</button>
    </PageHeader>
    <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
      <article v-for="c in cards" :key="c.t.id" class="card card-pad flex flex-col">
        <div class="flex items-start justify-between gap-3">
          <div class="flex items-center gap-3 min-w-0">
            <Avatar :name="`${c.t.firstName} ${c.t.lastName}`" :size="40" />
            <div class="min-w-0"><div class="font-semibold truncate">{{ c.t.firstName }} {{ c.t.lastName }}</div><div class="text-[12px] text-muted tnum">{{ c.t.staffNo }} · since {{ fmtDate(c.t.hireDate) }}</div></div>
          </div>
          <StatusBadge :status="c.t.status" />
        </div>
        <div class="flex flex-wrap gap-1.5 mt-3"><span v-for="s in c.t.subjectIds" :key="s" class="badge badge-brand">{{ store.subjectName(s) }}</span></div>
        <p class="text-[12.5px] text-muted mt-2">{{ c.t.qualification }}</p>
        <dl class="grid grid-cols-4 gap-2 mt-4 pt-3 border-t border-line text-[12px]">
          <div><dt class="text-muted">Classes</dt><dd class="text-[15px] font-semibold tnum">{{ c.classIds.length }}</dd></div>
          <div><dt class="text-muted">Lessons/wk</dt><dd class="text-[15px] font-semibold tnum">{{ c.lessons }}</dd></div>
          <div><dt class="text-muted">Registers</dt><dd class="text-[15px] font-semibold tnum">{{ c.registers }}</dd></div>
          <div><dt class="text-muted">Students</dt><dd class="text-[15px] font-semibold tnum">{{ c.students }}</dd></div>
        </dl>
        <div class="text-[12px] text-muted mt-2">{{ c.marks }} marks this term · class average {{ c.marks ? pct(c.avg) : '—' }}</div>
        <div class="flex items-center justify-between mt-auto pt-4">
          <a :href="`tel:${c.t.phone.replace(/\s/g, '')}`" class="inline-flex items-center gap-1.5 text-[13px] text-brand hover:underline tnum"><Phone :size="13" />{{ c.t.phone }}</a>
          <button class="btn btn-ghost btn-sm" @click="edit(c.t)"><Pencil :size="14" />Edit</button>
        </div>
      </article>
    </div>
    <Modal :open="open" :title="editing ? 'Edit tutor' : 'Add tutor'" :sub="editing?.staffNo" size="lg" @close="open = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
        <div><label class="label" for="tu-f">First name</label><input id="tu-f" v-model="f.firstName" class="input" /></div>
        <div><label class="label" for="tu-l">Last name</label><input id="tu-l" v-model="f.lastName" class="input" /></div>
        <div><label class="label" for="tu-p">Phone</label><input id="tu-p" v-model="f.phone" class="input" placeholder="0977 123 456" /></div>
        <div><label class="label" for="tu-e">Email (sign-in)</label><input id="tu-e" v-model="f.email" type="email" class="input" /></div>
        <div><label class="label" for="tu-g">Gender</label><select id="tu-g" v-model="f.gender" class="select"><option>Female</option><option>Male</option></select></div>
        <div><label class="label" for="tu-h">Start date</label><input id="tu-h" v-model="f.hireDate" type="date" class="input" /></div>
        <div class="sm:col-span-2"><label class="label" for="tu-q">Qualification</label><input id="tu-q" v-model="f.qualification" class="input" /></div>
        <div v-if="editing"><label class="label" for="tu-s">Status</label><select id="tu-s" v-model="f.status" class="select"><option value="active">Active</option><option value="on_leave">On leave</option><option value="inactive">Inactive</option></select></div>
        <div class="sm:col-span-2"><span class="label">Subjects taught</span>
          <div class="flex flex-wrap gap-2">
            <label v-for="s in store.db.subjects.filter((x) => x.active)" :key="s.id" :class="['flex items-center h-8 px-3 rounded-full border text-[13px] cursor-pointer', f.subjectIds.includes(s.id) ? 'border-brand bg-brand-soft' : 'border-line']">
              <input v-model="f.subjectIds" type="checkbox" :value="s.id" class="sr-only" />{{ s.name }}</label>
          </div></div>
        <p v-if="err" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer><button class="btn btn-secondary" @click="open = false">Cancel</button><button class="btn btn-primary" @click="save">{{ editing ? 'Save changes' : 'Add tutor' }}</button></template>
    </Modal>
  </div>
</template>
