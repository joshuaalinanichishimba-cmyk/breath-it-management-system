from datetime import date, datetime
from decimal import Decimal
from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db import Base, new_id
from .users import utcnow


class AttendanceRecord(Base):
    __tablename__ = "attendance"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("a-"))
    student_id: Mapped[str] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    slot_id: Mapped[str] = mapped_column(ForeignKey("timetable_slots.id", ondelete="CASCADE"), index=True)
    lesson_date: Mapped[date] = mapped_column(Date, index=True)
    status: Mapped[str] = mapped_column(String(8))  # present | absent | late
    recorded_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (
        UniqueConstraint("student_id", "slot_id", "lesson_date", name="uq_attendance_once_per_lesson"),
        CheckConstraint("status IN ('present','absent','late')", name="ck_attendance_status"),
    )


class Assessment(Base):
    """One sitting: e.g. 'Term 3 test 1' in Mathematics for Grade 8 A."""
    __tablename__ = "assessments"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("as-"))
    class_id: Mapped[str] = mapped_column(ForeignKey("classes.id"), index=True)
    subject_id: Mapped[str] = mapped_column(ForeignKey("subjects.id"), index=True)
    tutor_id: Mapped[str | None] = mapped_column(ForeignKey("tutors.id", ondelete="SET NULL"), nullable=True)
    assessment_type: Mapped[str] = mapped_column(String(20))  # Test | Assignment | Mock Exam | End of Term Exam
    title: Mapped[str] = mapped_column(String(120))
    max_marks: Mapped[Decimal] = mapped_column(Numeric(6, 2))
    assessment_date: Mapped[date] = mapped_column(Date, index=True)
    term: Mapped[str] = mapped_column(String(30), index=True)
    results: Mapped[list["ExaminationResult"]] = relationship(back_populates="assessment", cascade="all, delete-orphan")
    __table_args__ = (
        CheckConstraint("max_marks > 0", name="ck_assessment_max"),
        UniqueConstraint("class_id", "subject_id", "title", "assessment_date", name="uq_assessment_sitting"),
    )


class ExaminationResult(Base):
    __tablename__ = "examination_results"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("r-"))
    assessment_id: Mapped[str] = mapped_column(ForeignKey("assessments.id", ondelete="CASCADE"), index=True)
    student_id: Mapped[str] = mapped_column(ForeignKey("students.id", ondelete="CASCADE"), index=True)
    marks: Mapped[Decimal] = mapped_column(Numeric(6, 2))
    comment: Mapped[str] = mapped_column(Text, default="")
    assessment: Mapped[Assessment] = relationship(back_populates="results")
    __table_args__ = (
        UniqueConstraint("assessment_id", "student_id", name="uq_result_once"),
        CheckConstraint("marks >= 0", name="ck_result_marks"),
    )

    @property
    def percentage(self) -> float:
        return round(float(self.marks) / float(self.assessment.max_marks) * 100, 1)
