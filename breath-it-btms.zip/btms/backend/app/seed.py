"""
Database bootstrap.

  python -m app.seed --demo            create tables + load the fictional demonstration data and demo accounts
  python -m app.seed --demo --reset    drop everything first (DESTROYS DATA)
  python -m app.seed                   production bootstrap: tables, roles, grades/subjects, settings and one admin
                                       (needs ADMIN_EMAIL and ADMIN_PASSWORD environment variables)

Run from the backend/ folder so .env is picked up. In production, manage schema changes with Alembic.
"""
import argparse, json, os, sys
from collections import defaultdict
from datetime import date, datetime, time
from decimal import Decimal
from pathlib import Path
from sqlalchemy import select
from .db import Base, SessionLocal, engine
from .core.config import get_settings
from .core.security import hash_password
from .models import (Announcement, Assessment, AttendanceRecord, AuditLog, CentreSetting, Charge, ClassGroup, Enrolment, ExaminationResult,
                     FeeStructure, Grade, LearningMaterial, Parent, Payment, Receipt, Role, Student, Subject, TimetableSlot, Tutor, User, Lead)

SEED_FILE = Path(__file__).parent / "seed_data" / "demo_seed.json"
D = date.fromisoformat
def T(s: str) -> time: return time.fromisoformat(s)
def DT(s: str) -> datetime: return datetime.fromisoformat(s.replace("Z", "+00:00"))

ROLES = [("admin", "Owner and management"), ("tutor", "Tutor / teacher"), ("student", "Student"), ("parent", "Parent or guardian")]


def base_reference(db, data):
    for name, desc in ROLES:
        db.merge(Role(name=name, description=desc))
    st = data["settings"]
    db.merge(CentreSetting(key="centre", value={"name": st["centreName"], "tagline": st["tagline"], "address": st["address"], "phone": st["phone"],
                                                "email": st["email"], "currency": "ZMW", "current_term": st["currentTerm"], "receipt_footer": st["receiptFooter"]}))
    db.merge(CentreSetting(key="terms", value={"items": st["terms"]}))
    db.merge(CentreSetting(key="growth", value={"referral_reward": st.get("referralReward", 100), "reminder_template": st.get("reminderTemplate", "")}))
    op = st.get("onlinePayments", {})
    db.merge(CentreSetting(key="online_payments", value={"methods": op.get("methods", {}), "pass_fee_to_payer": op.get("passFeeToPayer", False), "fee_percent": op.get("feePercent", 2.5), "bank": op.get("bank", {})}))
    db.merge(CentreSetting(key="policies", value={"low_attendance_threshold": st["lowAttendanceThreshold"], "show_fees_to_students": st["showFeesToStudents"]}))
    grades = {}
    for g in data["grades"]:
        grades[g["id"]] = db.merge(Grade(id=g["id"], name=g["name"], sort_order=g["order"], exam_level=g["examLevel"], active=g["active"]))
    db.flush()
    subjects = {}
    for s in data["subjects"]:
        obj = db.merge(Subject(id=s["id"], name=s["name"], code=s["code"], active=s["active"]))
        obj.grades = [grades[x] for x in s["gradeIds"]]
        subjects[s["id"]] = obj
    for f in data["feeStructures"]:
        db.merge(FeeStructure(id=f["id"], grade_id=f["gradeId"], category=f["category"], amount=Decimal(str(f["amount"])), frequency=f["frequency"], description=f["description"]))
    db.flush()
    return subjects


def load_demo(db, data):
    pw = hash_password(get_settings().demo_password)
    subjects = base_reference(db, data)
    for t in data["tutors"]:
        obj = Tutor(id=t["id"], staff_no=t["staffNo"], first_name=t["firstName"], last_name=t["lastName"], gender=t["gender"], phone=t["phone"],
                    email=t["email"], qualification=t["qualification"], hire_date=D(t["hireDate"]), status=t["status"])
        obj.subjects = [subjects[x] for x in t["subjectIds"]]
        db.add(obj)
    for p in data["parents"]:
        db.add(Parent(id=p["id"], name=p["name"], relationship_to_student=p["relationship"], phone=p["phone"], alt_phone=p.get("altPhone"),
                      email=p.get("email"), address=p["address"], occupation=p.get("occupation"), portal_access=p["portalAccess"], referral_code=data.get("referralCodes", {}).get(p["id"])))
    db.flush()
    for c in data["classes"]:
        db.add(ClassGroup(id=c["id"], name=c["name"], grade_id=c["gradeId"], class_tutor_id=c["classTutorId"], room=c["room"], capacity=c["capacity"], active=c["active"]))
    db.flush()
    students = {}
    for s in data["students"]:
        obj = Student(id=s["id"], student_no=s["studentNo"], first_name=s["firstName"], last_name=s["lastName"], date_of_birth=D(s["dob"]), gender=s["gender"],
                      grade_id=s["gradeId"], class_id=s["classId"], parent_id=s["parentId"], alt_contact=s.get("altContact"), address=s["address"],
                      enrolment_date=D(s["enrolmentDate"]), status=s["status"], notes=s.get("notes"))
        obj.subjects = [subjects[x] for x in s["subjectIds"]]
        db.add(obj); students[s["id"]] = s
    for e in data["enrolmentEvents"]:
        db.add(Enrolment(id=e["id"], student_id=e["studentId"], event_date=D(e["date"]), action=e["action"], detail=e["detail"]))
    for l in data["lessons"]:
        db.add(TimetableSlot(id=l["id"], class_id=l["classId"], subject_id=l["subjectId"], tutor_id=l["tutorId"], day_of_week=l["day"], start_time=T(l["start"]), end_time=T(l["end"]), room=l["room"]))
    db.flush()

    # Demo accounts: the four documented logins + a login for every tutor. All flagged is_demo.
    users = {"admin": User(id="admin", email="admin@breathit.demo", name="Centre Administrator", role="admin", password_hash=pw, is_demo=True)}
    for t in data["tutors"]:
        email = "tutor@breathit.demo" if t["id"] == "t1" else t["email"]
        users[f"u-{t['id']}"] = User(id=f"u-{t['id']}", email=email, name=f"{t['firstName']} {t['lastName']}", role="tutor", tutor_id=t["id"], password_hash=pw, is_demo=True)
    users["u-s01"] = User(id="u-s01", email="student@breathit.demo", name="Natasha Banda", role="student", student_id="s01", password_hash=pw, is_demo=True)
    users["u-p01"] = User(id="u-p01", email="parent@breathit.demo", name="Mutale Banda", role="parent", parent_id="p01", password_hash=pw, is_demo=True)
    db.add_all(users.values()); db.flush()

    for a in data["attendance"]:
        db.add(AttendanceRecord(id=a["id"], student_id=a["studentId"], slot_id=a["lessonId"], lesson_date=D(a["date"]), status=a["status"],
                                recorded_by=f"u-{a['recordedBy']}" if f"u-{a['recordedBy']}" in users else "admin", recorded_at=DT(a["recordedAt"] + "+02:00")))
    # Flat frontend assessments -> one Assessment per sitting + ExaminationResult per student
    sittings: dict[tuple, list] = defaultdict(list)
    for a in data["assessments"]:
        sittings[(students[a["studentId"]]["classId"], a["subjectId"], a["title"], a["date"])].append(a)
    for (class_id, subject_id, title, d), rows in sittings.items():
        first = rows[0]
        asm = Assessment(class_id=class_id, subject_id=subject_id, tutor_id=first["tutorId"], assessment_type=first["type"], title=title,
                         max_marks=Decimal(first["maxMarks"]), assessment_date=D(d), term=first["term"])
        asm.results = [ExaminationResult(id=r["id"], student_id=r["studentId"], marks=Decimal(r["marks"]), comment=r["comment"]) for r in rows]
        db.add(asm)
    for c in data["charges"]:
        db.add(Charge(id=c["id"], student_id=c["studentId"], category=c["category"], term=c["term"], amount=Decimal(str(c["amount"])), description=c["description"],
                      issued_on=D(c["issuedOn"]), due_date=D(c["dueDate"])))
    for p in data["payments"]:
        pay = Payment(id=p["id"], reference=p["reference"], student_id=p["studentId"], amount=Decimal(str(p["amount"])), payment_date=D(p["date"]), method=p["method"],
                      category=p["category"], term=p["term"], external_ref=p.get("externalRef"), status=p["status"], recorded_by=p["recordedBy"],
                      recorded_at=DT(p["recordedAt"] + "+02:00"), verified_by=p.get("verifiedBy"), verified_at=DT(p["verifiedAt"] + "+02:00") if p.get("verifiedAt") else None,
                      balance_after=Decimal(str(p["balanceAfter"])), notes=p.get("notes"), channel=p.get("channel", "office"), network=p.get("network"),
                      payer_phone=p.get("payerPhone"), gateway_ref=p.get("gatewayRef"), gateway_status=p.get("gatewayStatus"))
        db.add(pay)
        if p.get("receiptNo"):
            db.add(Receipt(receipt_no=p["receiptNo"], payment_id=p["id"], issued_by=p.get("verifiedBy") or "Centre Administrator", issued_at=pay.verified_at))
    for a in data["announcements"]:
        author = "admin" if a["authorId"] == "admin" else f"u-{a['authorId']}"
        db.add(Announcement(id=a["id"], title=a["title"], body=a["body"], audience=a["audience"], class_id=a.get("classId"), priority=a["priority"],
                            author_id=author, author_name=a["authorName"], created_at=DT(a["createdAt"] + "+02:00"),
                            sms_status="not_configured" if a["channels"]["sms"] else "not_requested", whatsapp_status="not_configured" if a["channels"]["whatsapp"] else "not_requested"))
    for m in data["materials"]:
        db.add(LearningMaterial(id=m["id"], title=m["title"], description=m["description"], kind=m["kind"], subject_id=m["subjectId"], class_id=m["classId"],
                                tutor_id=m["tutorId"], content=m.get("content"), link=m.get("link"), created_at=DT(m["createdAt"] + "+02:00")))
    for l in data.get("leads", []):
        db.add(Lead(id=l["id"], child_name=l["childName"], grade_id=l["gradeId"], subject_ids=l["subjectIds"], parent_name=l["parentName"], phone=l["phone"],
                    source=l["source"], referred_by_parent_id=l.get("referredByParentId"), stage=l["stage"], created_at=DT(l["createdAt"] + "+02:00"),
                    follow_up_on=D(l["followUpOn"]) if l.get("followUpOn") else None, notes=l.get("notes", ""), lost_reason=l.get("lostReason"),
                    student_id=l.get("studentId"), reward_applied=l.get("rewardApplied", False)))
    db.add(AuditLog(actor_id="system", actor_name="Seed script", action="seed.demo", entity="database", detail="Loaded fictional demonstration data"))


def bootstrap_production(db, data):
    email, password = os.environ.get("ADMIN_EMAIL"), os.environ.get("ADMIN_PASSWORD")
    if not email or not password or len(password) < 10:
        sys.exit("Set ADMIN_EMAIL and ADMIN_PASSWORD (10+ characters) to create the first administrator.")
    base_reference(db, data)
    if not db.scalar(select(User.id).where(User.email == email.lower())):
        db.add(User(email=email.lower(), name=os.environ.get("ADMIN_NAME", "Administrator"), role="admin", password_hash=hash_password(password)))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--demo", action="store_true", help="load fictional demonstration data and demo accounts")
    ap.add_argument("--reset", action="store_true", help="drop all tables first (destroys data)")
    args = ap.parse_args()
    if args.reset:
        if get_settings().is_production:
            sys.exit("Refusing to --reset in production.")
        Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    data = json.loads(SEED_FILE.read_text(encoding="utf-8-sig"))
    with SessionLocal() as db:
        if args.demo:
            if get_settings().is_production:
                sys.exit("Refusing to load demo accounts in production.")
            if db.scalar(select(Student.id).limit(1)):
                sys.exit("Database already has students. Use --reset to reload the demo data.")
            load_demo(db, data)
        else:
            bootstrap_production(db, data)
        db.commit()
        print("Database ready." + (f" Demo data loaded: {len(data['students'])} students, {len(data['payments'])} payments." if args.demo else ""))


if __name__ == "__main__":
    main()
