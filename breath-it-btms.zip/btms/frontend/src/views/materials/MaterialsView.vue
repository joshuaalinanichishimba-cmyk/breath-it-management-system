<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { Plus, Download, ExternalLink, Trash2, FileText } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Modal from '@/components/ui/Modal.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useAuth } from '@/stores/auth'
import { useScope } from '@/composables/useScope'
import type { Material } from '@/types'
import { fmtDate } from '@/services/dates'
import { saveFile } from '@/services/download'

const store = useDb(); const ui = useUi(); const auth = useAuth(); const scope = useScope()
const canShare = computed(() => scope.role.value === 'admin' || scope.role.value === 'tutor')
const me = computed(() => (scope.role.value === 'student' ? store.studentMap.get(auth.user?.linkedId ?? '') : undefined))
const subjectF = ref('')
const items = computed(() => store.db.materials.filter((m) => {
  if (scope.role.value === 'student') return !!me.value && m.classId === me.value.classId && me.value.subjectIds.includes(m.subjectId)
  if (scope.role.value === 'tutor') return scope.lessons.value.some((l) => l.classId === m.classId && l.subjectId === m.subjectId)
  return true
}).filter((m) => !subjectF.value || m.subjectId === subjectF.value))
const subjectOptions = computed(() => [...new Set(items.value.map((m) => m.subjectId))].map((id) => ({ id, name: store.subjectName(id) })))

const pairs = computed(() => scope.lessons.value.reduce<{ classId: string; subjectId: string }[]>((acc, l) => { if (!acc.some((x) => x.classId === l.classId && x.subjectId === l.subjectId)) acc.push({ classId: l.classId, subjectId: l.subjectId }); return acc }, []))
const open = ref(false); const err = ref('')
const f = reactive({ title: '', kind: 'Notes' as Material['kind'], pair: '', description: '', content: '', link: '' })
function start() { Object.assign(f, { title: '', kind: 'Notes', pair: pairs.value[0] ? `${pairs.value[0].classId}|${pairs.value[0].subjectId}` : '', description: '', content: '', link: '' }); err.value = ''; open.value = true }
function save() {
  const [classId, subjectId] = f.pair.split('|')
  if (!f.title.trim() || !classId) return (err.value = 'Add a title and choose the class and subject.')
  if (f.kind === 'Link' && !/^https:\/\/\S+\.\S+/.test(f.link.trim())) return (err.value = 'Enter a full https:// link.')
  if (f.kind !== 'Link' && !f.content.trim()) return (err.value = 'Type or paste the notes students will download.')
  const tutorId = scope.role.value === 'tutor' ? scope.tutorId.value : store.db.lessons.find((l) => l.classId === classId && l.subjectId === subjectId)?.tutorId ?? ''
  store.addMaterial({ title: f.title.trim(), kind: f.kind, classId, subjectId, tutorId, description: f.description.trim(), content: f.kind === 'Link' ? undefined : f.content, link: f.kind === 'Link' ? f.link.trim() : undefined })
  ui.success('Material shared', `Students in ${store.className(classId)} taking ${store.subjectName(subjectId)} can now see it.`); open.value = false
}
async function download(m: Material) {
  const text = `${m.title}\n${store.subjectName(m.subjectId)} · ${store.className(m.classId)} · ${store.tutorName(m.tutorId)}\n${'-'.repeat(48)}\n\n${m.content ?? ''}\n`
  try { if ((await saveFile(`${m.title.replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').toLowerCase()}.txt`, text, 'text/plain')) === 'saved') ui.success('Downloaded', m.title) } catch (e) { ui.error('Download failed', (e as Error).message) }
}
async function remove(m: Material) {
  if (!(await ui.confirm({ title: 'Remove this material?', body: `“${m.title}” will no longer be visible to students.`, confirmLabel: 'Remove', tone: 'danger' }))) return
  store.deleteMaterial(m.id); ui.success('Material removed')
}
const preview = ref<Material | null>(null)
</script>
<template>
  <div>
    <PageHeader title="Learning materials" :sub="canShare ? 'Notes, worksheets, past paper practice and links shared with a class' : 'Notes and worksheets shared by your tutors'">
      <select v-if="subjectOptions.length > 1" v-model="subjectF" class="select w-auto" aria-label="Subject"><option value="">All subjects</option><option v-for="s in subjectOptions" :key="s.id" :value="s.id">{{ s.name }}</option></select>
      <button v-if="canShare" class="btn btn-primary" @click="start"><Plus :size="15" />Share material</button>
    </PageHeader>
    <EmptyState v-if="!items.length" title="No materials yet" :body="canShare ? 'Share notes or a worksheet with one of your classes.' : 'Your tutors have not shared anything yet.'" />
    <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
      <article v-for="m in items" :key="m.id" class="card card-pad flex flex-col">
        <div class="flex items-start gap-3">
          <div class="h-9 w-9 rounded-md bg-brand-soft text-brand flex items-center justify-center shrink-0"><FileText :size="17" /></div>
          <div class="min-w-0"><h3 class="font-semibold leading-snug">{{ m.title }}</h3><p class="text-[12px] text-muted">{{ store.subjectName(m.subjectId) }} · {{ store.className(m.classId) }} · {{ m.kind }}</p></div>
        </div>
        <p class="text-[13px] text-muted mt-3">{{ m.description }}</p>
        <div class="text-[12px] text-faint mt-2">{{ store.tutorName(m.tutorId) }} · {{ fmtDate(m.createdAt.slice(0, 10)) }}</div>
        <div class="flex gap-2 mt-auto pt-4">
          <template v-if="m.link"><a :href="m.link" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm"><ExternalLink :size="14" />Open link</a></template>
          <template v-else><button class="btn btn-secondary btn-sm" @click="preview = m">Read</button><button class="btn btn-ghost btn-sm" @click="download(m)"><Download :size="14" />Download</button></template>
          <button v-if="scope.role.value === 'admin' || m.tutorId === scope.tutorId.value" class="icon-btn ml-auto" aria-label="Remove material" @click="remove(m)"><Trash2 :size="15" /></button>
        </div>
      </article>
    </div>
    <Modal :open="!!preview" :title="preview?.title ?? ''" :sub="preview ? `${store.subjectName(preview.subjectId)} · ${store.tutorName(preview.tutorId)}` : ''" size="lg" @close="preview = null">
      <pre class="whitespace-pre-wrap font-sans text-[13.5px] leading-relaxed">{{ preview?.content }}</pre>
      <template #footer><button class="btn btn-primary" @click="download(preview!)"><Download :size="15" />Download</button></template>
    </Modal>
    <Modal :open="open" title="Share learning material" sub="File uploads need the hosted backend; in this demo, notes are typed or pasted and students download them as text." size="lg" @close="open = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="save">
        <div class="sm:col-span-2"><label class="label" for="mt-t">Title</label><input id="mt-t" v-model="f.title" class="input" /></div>
        <div><label class="label" for="mt-p">Class and subject</label><select id="mt-p" v-model="f.pair" class="select"><option v-for="p in pairs" :key="p.classId + p.subjectId" :value="`${p.classId}|${p.subjectId}`">{{ store.className(p.classId) }} · {{ store.subjectName(p.subjectId) }}</option></select></div>
        <div><label class="label" for="mt-k">Type</label><select id="mt-k" v-model="f.kind" class="select"><option>Notes</option><option>Worksheet</option><option>Past paper</option><option>Link</option></select></div>
        <div class="sm:col-span-2"><label class="label" for="mt-d">Short description</label><input id="mt-d" v-model="f.description" class="input" /></div>
        <div v-if="f.kind === 'Link'" class="sm:col-span-2"><label class="label" for="mt-l">Link</label><input id="mt-l" v-model="f.link" class="input" placeholder="https://" /></div>
        <div v-else class="sm:col-span-2"><label class="label" for="mt-c">Content</label><textarea id="mt-c" v-model="f.content" class="textarea min-h-[180px]" /></div>
        <p v-if="err" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer><button class="btn btn-secondary" @click="open = false">Cancel</button><button class="btn btn-primary" @click="save">Share with class</button></template>
    </Modal>
  </div>
</template>
