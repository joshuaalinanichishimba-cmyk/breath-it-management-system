from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import or_, select
from sqlalchemy.orm import Session
from ...db import get_db
from ...deps import current_user, require_roles, client_ip
from ...models import Announcement, AuditLog, LearningMaterial, Student, TimetableSlot, User
from ...schemas.comms import AnnouncementIn, AnnouncementOut, AuditOut, MaterialIn, MaterialOut
from ...services.access import visible_class_ids
from ...services.audit import audit
from ...services.notifications import channel_status

router = APIRouter(tags=["communication"])


@router.get("/announcements", response_model=list[AnnouncementOut])
def list_announcements(user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Announcement).order_by(Announcement.created_at.desc())
    if user.role != "admin":
        group = {"tutor": "tutors", "student": "students", "parent": "parents"}[user.role]
        classes = visible_class_ids(db, user) or {""}
        q = q.where(or_(Announcement.audience.in_(["everyone", group]), (Announcement.audience == "class") & Announcement.class_id.in_(classes)))
    return list(db.scalars(q.limit(200)))


@router.post("/announcements", response_model=AnnouncementOut, status_code=201)
def create_announcement(body: AnnouncementIn, request: Request, user: User = Depends(require_roles("admin", "tutor")), db: Session = Depends(get_db)):
    if user.role == "tutor" and (body.audience != "class" or body.class_id not in (visible_class_ids(db, user) or set())):
        raise HTTPException(403, "Tutors can post only to classes they teach.")
    a = Announcement(title=body.title, body=body.body, audience=body.audience, class_id=body.class_id if body.audience == "class" else None,
                     priority=body.priority, author_id=user.id, author_name=user.name,
                     sms_status=channel_status("sms", body.send_sms), whatsapp_status=channel_status("whatsapp", body.send_whatsapp))
    db.add(a); db.flush()
    audit(db, user, "announcement.created", "announcement", a.id, f"{a.title} ({a.audience}); sms={a.sms_status}; whatsapp={a.whatsapp_status}", client_ip(request))
    db.commit()
    return a


@router.delete("/announcements/{ann_id}", status_code=204)
def delete_announcement(ann_id: str, request: Request, user: User = Depends(require_roles("admin", "tutor")), db: Session = Depends(get_db)):
    a = db.get(Announcement, ann_id)
    if not a or (user.role == "tutor" and a.author_id != user.id):
        raise HTTPException(404, "Announcement not found.")
    db.delete(a); audit(db, user, "announcement.deleted", "announcement", ann_id, a.title, client_ip(request)); db.commit()


@router.get("/materials", response_model=list[MaterialOut])
def list_materials(user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(LearningMaterial).order_by(LearningMaterial.created_at.desc())
    if user.role == "tutor":
        pairs = set(db.execute(select(TimetableSlot.class_id, TimetableSlot.subject_id).where(TimetableSlot.tutor_id == user.tutor_id)).all())
        return [m for m in db.scalars(q) if (m.class_id, m.subject_id) in pairs]
    if user.role == "student":
        s = db.get(Student, user.student_id)
        return [m for m in db.scalars(q.where(LearningMaterial.class_id == s.class_id)) if m.subject_id in {x.id for x in s.subjects}]
    if user.role == "parent":
        raise HTTPException(403, "Learning materials are shared with students.")
    return list(db.scalars(q))


@router.post("/materials", response_model=MaterialOut, status_code=201)
def create_material(body: MaterialIn, request: Request, user: User = Depends(require_roles("admin", "tutor")), db: Session = Depends(get_db)):
    slot = db.scalar(select(TimetableSlot).where(TimetableSlot.class_id == body.class_id, TimetableSlot.subject_id == body.subject_id,
                                                 *([TimetableSlot.tutor_id == user.tutor_id] if user.role == "tutor" else [])).limit(1))
    if not slot:
        raise HTTPException(403, "You can share materials only for subjects you teach in that class.")
    m = LearningMaterial(title=body.title, description=body.description, kind=body.kind, class_id=body.class_id, subject_id=body.subject_id,
                         tutor_id=slot.tutor_id, content=body.content if body.kind != "Link" else None, link=str(body.link) if body.link else None)
    db.add(m); db.flush(); audit(db, user, "material.shared", "material", m.id, m.title, client_ip(request)); db.commit()
    return m


@router.delete("/materials/{material_id}", status_code=204)
def delete_material(material_id: str, request: Request, user: User = Depends(require_roles("admin", "tutor")), db: Session = Depends(get_db)):
    m = db.get(LearningMaterial, material_id)
    if not m or (user.role == "tutor" and m.tutor_id != user.tutor_id):
        raise HTTPException(404, "Material not found.")
    db.delete(m); audit(db, user, "material.deleted", "material", material_id, m.title, client_ip(request)); db.commit()


@router.get("/audit", response_model=list[AuditOut])
def audit_log(q: str = "", limit: int = 200, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    query = select(AuditLog).order_by(AuditLog.at.desc())
    if q:
        like = f"%{q}%"
        query = query.where(or_(AuditLog.action.ilike(like), AuditLog.detail.ilike(like), AuditLog.actor_name.ilike(like)))
    return list(db.scalars(query.limit(min(limit, 1000))))
