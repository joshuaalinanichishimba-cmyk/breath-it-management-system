import { createRouter, createWebHashHistory, createWebHistory, createMemoryHistory, type RouteRecordRaw } from 'vue-router'
import type { Role } from '@/types'
import { useAuth } from '@/stores/auth'
import { useUi } from '@/stores/ui'
import { useDb } from '@/stores/db'
import { ROUTER_MODE } from '@/config'
import AppLayout from '@/layouts/AppLayout.vue'

declare module 'vue-router' {
  interface RouteMeta { roles?: Role[]; public?: boolean; title?: string; open?: boolean }
}
const ALL: Role[] = ['admin', 'tutor', 'student', 'parent']
const STAFF: Role[] = ['admin', 'tutor']
const FAMILY: Role[] = ['student', 'parent']

const routes: RouteRecordRaw[] = [
  { path: '/login', component: () => import('@/views/auth/LoginView.vue'), meta: { public: true, title: 'Sign in' } },
  { path: '/enquire', component: () => import('@/views/public/EnquireView.vue'), meta: { public: true, title: 'Enquire about lessons', open: true } },
  {
    path: '/', component: AppLayout, children: [
      { path: '', redirect: '/dashboard' },
      { path: 'dashboard', component: () => import('@/views/dashboard/DashboardView.vue'), meta: { roles: ALL, title: 'Dashboard' } },
      { path: 'students', component: () => import('@/views/students/StudentsView.vue'), meta: { roles: STAFF, title: 'Students' } },
      { path: 'students/:id', component: () => import('@/views/students/StudentProfileView.vue'), meta: { roles: STAFF, title: 'Student profile' } },
      { path: 'admissions', component: () => import('@/views/admissions/AdmissionsView.vue'), meta: { roles: ['admin'], title: 'Admissions' } },
      { path: 'growth', component: () => import('@/views/growth/GrowthView.vue'), meta: { roles: ['admin'], title: 'Growth' } },
      { path: 'parents', component: () => import('@/views/parents/ParentsView.vue'), meta: { roles: ['admin'], title: 'Parents' } },
      { path: 'tutors', component: () => import('@/views/tutors/TutorsView.vue'), meta: { roles: ['admin'], title: 'Tutors' } },
      { path: 'classes', component: () => import('@/views/classes/ClassesView.vue'), meta: { roles: STAFF, title: 'Classes' } },
      { path: 'subjects', component: () => import('@/views/subjects/SubjectsView.vue'), meta: { roles: ['admin'], title: 'Grades & subjects' } },
      { path: 'timetable', component: () => import('@/views/timetable/TimetableView.vue'), meta: { roles: ALL, title: 'Timetable' } },
      { path: 'attendance', component: () => import('@/views/attendance/AttendanceView.vue'), meta: { roles: STAFF, title: 'Attendance' } },
      { path: 'performance', component: () => import('@/views/performance/PerformanceView.vue'), meta: { roles: STAFF, title: 'Performance' } },
      { path: 'finance', component: () => import('@/views/finance/FinanceView.vue'), meta: { roles: ['admin'], title: 'Finance' } },
      { path: 'my/results', component: () => import('@/views/portal/PortalResults.vue'), meta: { roles: FAMILY, title: 'Results' } },
      { path: 'my/attendance', component: () => import('@/views/portal/PortalAttendance.vue'), meta: { roles: FAMILY, title: 'Attendance' } },
      { path: 'my/payments', component: () => import('@/views/portal/PortalPayments.vue'), meta: { roles: FAMILY, title: 'Payments' } },
      { path: 'materials', component: () => import('@/views/materials/MaterialsView.vue'), meta: { roles: ['admin', 'tutor', 'student'], title: 'Learning materials' } },
      { path: 'announcements', component: () => import('@/views/announcements/AnnouncementsView.vue'), meta: { roles: ALL, title: 'Announcements' } },
      { path: 'reports', component: () => import('@/views/reports/ReportsView.vue'), meta: { roles: ['admin'], title: 'Reports' } },
      { path: 'settings', component: () => import('@/views/settings/SettingsView.vue'), meta: { roles: ['admin'], title: 'Settings' } },
    ],
  },
  { path: '/:pathMatch(.*)*', redirect: '/dashboard' },
]

const history = ROUTER_MODE === 'memory' ? createMemoryHistory() : ROUTER_MODE === 'history' ? createWebHistory(import.meta.env.BASE_URL) : createWebHashHistory()
export const router = createRouter({ history, routes, scrollBehavior: () => ({ top: 0 }) })

router.beforeEach((to) => {
  const auth = useAuth()
  if (to.meta.public) return auth.user && to.path === '/login' ? '/dashboard' : true
  if (!auth.user) return { path: '/login', query: to.fullPath !== '/dashboard' ? { redirect: to.fullPath } : {} }
  const roles = to.matched.reduce<Role[] | undefined>((acc, r) => r.meta.roles ?? acc, undefined)
  if (roles && !roles.includes(auth.user.role)) { useUi().error('That page is not available for your account.'); return '/dashboard' }
  if (to.path === '/my/payments' && auth.user.role === 'student' && !useDb().db.settings.showFeesToStudents) return '/dashboard'
  return true
})
router.afterEach((to) => { document.title = `${to.meta.title ? to.meta.title + ' · ' : ''}Breath It BTMS` })
