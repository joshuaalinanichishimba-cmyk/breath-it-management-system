<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink } from 'vue-router'
import { ClipboardCheck, PenLine } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatTile from '@/components/ui/StatTile.vue'
import TodayTimeline from '@/components/domain/TodayTimeline.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import { useDb } from '@/stores/db'
import { useAuth } from '@/stores/auth'
import { useScope } from '@/composables/useScope'
import { useAnnouncements } from '@/composables/useAnnouncements'
import { iso, addDays, isoWeekday, DAY_NAMES, fmtDate, weekStart } from '@/services/dates'
import { pct } from '@/services/format'
import { average, pctOf } from '@/services/analytics'
import { greeting, todayLabel } from './greeting'

const store = useDb(); const auth = useAuth(); const scope = useScope(); const anns = useAnnouncements()
const today = iso()
const mine = computed(() => scope.tutorLessons.value)
const term = computed(() => store.db.settings.currentTerm)

const missingRegisters = computed(() => {
  const out: { lessonId: string; date: string }[] = []
  for (let d = weekStart(today); d <= today; d = addDays(d, 1)) {
    for (const l of mine.value.filter((x) => x.day === isoWeekday(d))) {
      if (d === today) continue
      if (!store.registerFor(l.id, d).length && store.rosterFor(l.id, d).length) out.push({ lessonId: l.id, date: d })
    }
  }
  return out
})
const myMarks = computed(() => store.db.assessments.filter((a) => a.tutorId === auth.user?.linkedId && a.term === term.value))
const upcoming = computed(() => {
  const out: { date: string; lesson: typeof mine.value[number] }[] = []
  for (let i = 1; i <= 6 && out.length < 6; i++) {
    const d = addDays(today, i)
    for (const l of mine.value.filter((x) => x.day === isoWeekday(d)).sort((a, b) => a.start.localeCompare(b.start))) out.push({ date: d, lesson: l })
  }
  return out.slice(0, 6)
})
const latestSittings = computed(() => {
  const m = new Map<string, { title: string; subjectId: string; date: string; n: number; avg: number[] }>()
  for (const a of myMarks.value) {
    const k = `${a.title}|${a.subjectId}|${a.date}`
    if (!m.has(k)) m.set(k, { title: a.title, subjectId: a.subjectId, date: a.date, n: 0, avg: [] })
    const x = m.get(k)!; x.n++; x.avg.push(pctOf(a))
  }
  return [...m.values()].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5)
})
</script>
<template>
  <div>
    <PageHeader :title="greeting(auth.user?.name ?? '')" :sub="`${todayLabel()} · ${term}`">
      <RouterLink to="/attendance" class="btn btn-secondary"><ClipboardCheck :size="15" />Take register</RouterLink>
      <RouterLink to="/performance?tab=record" class="btn btn-primary"><PenLine :size="15" />Enter marks</RouterLink>
    </PageHeader>
    <section class="card card-pad mb-5">
      <h2 class="h-section mb-3">Your lessons today</h2>
      <TodayTimeline :lessons="mine" can-take-register />
    </section>
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
      <StatTile label="My classes" :value="scope.classIds.value.size" :hint="`${mine.length} lessons a week`" />
      <StatTile label="My students" :value="scope.students.value.filter((s) => s.status === 'active').length" hint="Active, across your classes" />
      <StatTile label="Registers to catch up" :value="missingRegisters.length" :tone="missingRegisters.length ? 'warn' : 'ok'" hint="Earlier this week" />
      <StatTile :label="`Average mark · ${term.replace(' 2026', '')}`" :value="myMarks.length ? pct(average(myMarks.map(pctOf))) : '—'" :hint="`${myMarks.length} marks entered`" />
    </div>
    <div class="grid lg:grid-cols-3 gap-4">
      <section class="card card-pad">
        <h2 class="h-section mb-3">Coming up</h2>
        <ul v-if="upcoming.length" class="grid gap-2.5">
          <li v-for="u in upcoming" :key="u.lesson.id + u.date" class="flex gap-3 text-[13px]">
            <div class="w-[74px] shrink-0 text-muted"><div class="font-medium text-ink">{{ DAY_NAMES[isoWeekday(u.date)].slice(0, 3) }} {{ u.lesson.start }}</div>{{ fmtDate(u.date, false) }}</div>
            <div class="min-w-0"><div class="font-medium truncate">{{ store.subjectName(u.lesson.subjectId) }}</div><div class="text-muted truncate">{{ store.className(u.lesson.classId) }} · {{ u.lesson.room }}</div></div>
          </li>
        </ul>
        <EmptyState v-else compact title="Nothing scheduled this week" />
      </section>
      <section class="card card-pad">
        <h2 class="h-section mb-3">Registers to catch up</h2>
        <ul v-if="missingRegisters.length" class="grid gap-2">
          <li v-for="m in missingRegisters" :key="m.lessonId + m.date">
            <RouterLink :to="{ path: '/attendance', query: { lesson: m.lessonId, date: m.date } }" class="flex justify-between gap-2 text-[13px] hover:underline">
              <span>{{ store.className(store.lessonMap.get(m.lessonId)!.classId) }} · {{ store.subjectName(store.lessonMap.get(m.lessonId)!.subjectId) }}</span>
              <span class="text-muted">{{ fmtDate(m.date, false) }}</span>
            </RouterLink>
          </li>
        </ul>
        <p v-else class="text-[13px] text-muted">All registers for this week are up to date.</p>
        <h2 class="h-section mt-5 mb-3">Recent marks</h2>
        <ul class="grid gap-2">
          <li v-for="s in latestSittings" :key="s.title + s.subjectId + s.date" class="flex justify-between gap-2 text-[13px]">
            <span class="truncate">{{ s.title }} · {{ store.subjectName(s.subjectId) }}</span><span class="text-muted tnum">{{ pct(average(s.avg)) }} avg</span>
          </li>
        </ul>
      </section>
      <section class="card card-pad">
        <div class="flex items-baseline justify-between mb-3"><h2 class="h-section">Announcements</h2><RouterLink to="/announcements" class="text-[12.5px] text-brand hover:underline">All</RouterLink></div>
        <article v-for="a in anns.slice(0, 3)" :key="a.id" class="py-2.5 border-b border-line last:border-0">
          <div class="flex items-center gap-2"><span class="text-[13px] font-medium">{{ a.title }}</span><span v-if="a.priority === 'important'" class="badge badge-bad">Important</span></div>
          <p class="text-[12.5px] text-muted mt-0.5 line-clamp-2">{{ a.body }}</p>
        </article>
      </section>
    </div>
  </div>
</template>
