<script setup lang="ts">
import { computed, ref } from 'vue'
import { Download, FileDown } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { iso, addDays, fmtDate } from '@/services/dates'
import { kwacha, pct } from '@/services/format'
import { attendanceRate, attendanceCounts, average, pctOf } from '@/services/analytics'
import { saveFile, toCsv } from '@/services/download'
import { tablePdf } from '@/services/pdf'

const store = useDb(); const ui = useUi()
type Kind = 'enrolment' | 'collections' | 'balances' | 'tutors' | 'attendance' | 'exams' | 'progress'
const kinds: { id: Kind; name: string; desc: string; dated: boolean }[] = [
  { id: 'enrolment', name: 'Student enrolment', desc: 'Registrations in the period, with grade and parent contact', dated: true },
  { id: 'collections', name: 'Tuition collections', desc: 'Verified payments received in the period', dated: true },
  { id: 'balances', name: 'Outstanding balances', desc: 'Every student who owes, as of today', dated: false },
  { id: 'tutors', name: 'Tutor activity', desc: 'Lessons, registers taken and marks entered per tutor', dated: true },
  { id: 'attendance', name: 'Attendance', desc: 'Attendance rate per student in the period', dated: true },
  { id: 'exams', name: 'Examination results', desc: 'All marks recorded in the period', dated: true },
  { id: 'progress', name: 'Academic progress', desc: 'First vs latest average per student, all terms', dated: false },
]
const kind = ref<Kind>('collections')
const meta = computed(() => kinds.find((k) => k.id === kind.value)!)
const from = ref(store.db.settings.terms.find((t) => t.name === store.db.settings.currentTerm)?.start ?? addDays(iso(), -90))
const to = ref(iso())
function preset(p: 'term' | 'month' | 'year') {
  if (p === 'term') from.value = store.db.settings.terms.find((t) => t.name === store.db.settings.currentTerm)?.start ?? from.value
  if (p === 'month') from.value = iso().slice(0, 8) + '01'
  if (p === 'year') from.value = iso().slice(0, 4) + '-01-01'
  to.value = iso()
}
const inRange = (d: string) => !meta.value.dated || (d >= from.value && d <= to.value)

const report = computed<{ head: string[]; rows: (string | number)[][]; summary: [string, string][] }>(() => {
  const d = store.db
  switch (kind.value) {
    case 'enrolment': {
      const s = d.students.filter((x) => inRange(x.enrolmentDate)).sort((a, b) => a.enrolmentDate.localeCompare(b.enrolmentDate))
      const byGrade = d.grades.map((g) => `${g.name}: ${s.filter((x) => x.gradeId === g.id).length}`).join(', ')
      return { head: ['Enrolled', 'Student no.', 'Student', 'Grade', 'Class', 'Status', 'Parent', 'Phone'],
        rows: s.map((x) => [fmtDate(x.enrolmentDate), x.studentNo, `${x.firstName} ${x.lastName}`, store.gradeName(x.gradeId), store.className(x.classId), x.status, store.parentMap.get(x.parentId)?.name ?? '', store.parentMap.get(x.parentId)?.phone ?? '']),
        summary: [['New registrations', String(s.length)], ['By grade', byGrade], ['Total registered (all time)', String(d.students.length)]] }
    }
    case 'collections': {
      const p = d.payments.filter((x) => x.status === 'verified' && inRange(x.date)).sort((a, b) => a.date.localeCompare(b.date))
      const sum = (f: (x: typeof p[number]) => boolean) => kwacha(p.filter(f).reduce((a, x) => a + x.amount, 0), { decimals: true })
      return { head: ['Date', 'Receipt', 'Student', 'Category', 'Term', 'Method', 'Amount'],
        rows: p.map((x) => [fmtDate(x.date), x.receiptNo ?? '', store.studentName(x.studentId), x.category, x.term, x.method, kwacha(x.amount, { decimals: true })]),
        summary: [['Total collected', sum(() => true)], ['Mobile Money', sum((x) => x.method === 'Mobile Money')], ['Cash', sum((x) => x.method === 'Cash')], ['Bank transfer', sum((x) => x.method === 'Bank Transfer')], ['Payments', String(p.length)]] }
    }
    case 'balances': {
      const r = d.students.map((s) => ({ s, b: store.balance(s.id) })).filter((x) => x.b > 0).sort((a, b) => b.b - a.b)
      return { head: ['Student no.', 'Student', 'Grade', 'Parent', 'Phone', 'Billed', 'Paid', 'Balance'],
        rows: r.map(({ s, b }) => [s.studentNo, `${s.firstName} ${s.lastName}`, store.gradeName(s.gradeId), store.parentMap.get(s.parentId)?.name ?? '', store.parentMap.get(s.parentId)?.phone ?? '', kwacha(store.billed(s.id)), kwacha(store.paid(s.id)), kwacha(b, { decimals: true })]),
        summary: [['Students owing', String(r.length)], ['Total outstanding', kwacha(r.reduce((a, x) => a + x.b, 0), { decimals: true })]] }
    }
    case 'tutors': {
      return { head: ['Tutor', 'Subjects', 'Lessons / week', 'Registers taken', 'Marks entered', 'Average mark'],
        rows: d.tutors.map((t) => {
          const ls = d.lessons.filter((l) => l.tutorId === t.id)
          const regs = new Set(d.attendance.filter((a) => inRange(a.date) && ls.some((l) => l.id === a.lessonId)).map((a) => a.lessonId + a.date)).size
          const marks = d.assessments.filter((a) => a.tutorId === t.id && inRange(a.date))
          return [`${t.firstName} ${t.lastName}`, t.subjectIds.map(store.subjectName).join(', '), ls.length, regs, marks.length, marks.length ? pct(average(marks.map(pctOf))) : '—']
        }), summary: [['Active tutors', String(d.tutors.filter((t) => t.status === 'active').length)]] }
    }
    case 'attendance': {
      const recs = d.attendance.filter((a) => inRange(a.date))
      const r = d.students.map((s) => { const x = recs.filter((a) => a.studentId === s.id); return { s, rate: attendanceRate(x), ...attendanceCounts(x) } }).filter((x) => x.total).sort((a, b) => a.rate - b.rate)
      return { head: ['Student', 'Class', 'Lessons', 'Present', 'Late', 'Absent', 'Rate'],
        rows: r.map((x) => [`${x.s.firstName} ${x.s.lastName}`, store.className(x.s.classId), x.total, x.present, x.late, x.absent, pct(x.rate)]),
        summary: [['Overall attendance', recs.length ? pct(attendanceRate(recs)) : '—'], ['Student-lessons recorded', String(recs.length)], [`Below ${d.settings.lowAttendanceThreshold}%`, String(r.filter((x) => x.rate < d.settings.lowAttendanceThreshold).length)]] }
    }
    case 'exams': {
      const a = d.assessments.filter((x) => inRange(x.date)).sort((x, y) => x.date.localeCompare(y.date))
      return { head: ['Date', 'Student', 'Class', 'Subject', 'Assessment', 'Marks', '%'],
        rows: a.map((x) => [fmtDate(x.date), store.studentName(x.studentId), store.className(store.studentMap.get(x.studentId)?.classId ?? ''), store.subjectName(x.subjectId), x.title, `${x.marks}/${x.maxMarks}`, pct(pctOf(x))]),
        summary: [['Marks recorded', String(a.length)], ['Average', a.length ? pct(average(a.map(pctOf))) : '—']] }
    }
    case 'progress': {
      const r = d.students.map((s) => {
        const a = d.assessments.filter((x) => x.studentId === s.id)
        const dates = [...new Set(a.map((x) => x.date))].sort()
        if (dates.length < 2) return null
        const first = average(a.filter((x) => x.date === dates[0]).map(pctOf)), last = average(a.filter((x) => x.date === dates[dates.length - 1]).map(pctOf))
        return { s, first, last, change: last - first, n: dates.length }
      }).filter((x): x is NonNullable<typeof x> => !!x).sort((a, b) => b.change - a.change)
      return { head: ['Student', 'Grade', 'Sittings', 'First average', 'Latest average', 'Change'],
        rows: r.map((x) => [`${x.s.firstName} ${x.s.lastName}`, store.gradeName(x.s.gradeId), x.n, pct(x.first), pct(x.last), `${x.change >= 0 ? '+' : ''}${x.change.toFixed(1)} pts`]),
        summary: [['Students improving', String(r.filter((x) => x.change > 0).length)], ['Students declining', String(r.filter((x) => x.change < 0).length)]] }
    }
  }
  return { head: [], rows: [], summary: [] }
})
const subtitle = computed(() => (meta.value.dated ? `${fmtDate(from.value)} to ${fmtDate(to.value)}` : `As of ${fmtDate(iso())}`))
async function exportAs(k: 'csv' | 'pdf') {
  const name = `${kind.value}-report-${iso()}`
  try {
    const r = k === 'csv' ? await saveFile(`${name}.csv`, toCsv(report.value.head, report.value.rows), 'text/csv')
      : await saveFile(`${name}.pdf`, tablePdf(store.db, `${meta.value.name} report`, subtitle.value, report.value.head, report.value.rows, report.value.summary, report.value.head.length > 6), 'application/pdf')
    if (r === 'saved') ui.success(`${meta.value.name} report exported`, `${report.value.rows.length} rows · ${k.toUpperCase()}`)
  } catch (e) { ui.error('Export failed', (e as Error).message) }
}
</script>
<template>
  <div>
    <PageHeader title="Reports" sub="Preview any report on screen, then export it as CSV for Excel or as a branded PDF." />
    <div class="grid lg:grid-cols-[260px_1fr] gap-4 items-start">
      <nav class="card p-1.5 grid gap-0.5" aria-label="Reports">
        <button v-for="k in kinds" :key="k.id" :class="['text-left px-3 py-2.5 rounded-md', kind === k.id ? 'bg-brand-soft' : 'hover:bg-sunken']" @click="kind = k.id">
          <div class="text-[13.5px] font-medium">{{ k.name }}</div><div class="text-[12px] text-muted leading-snug">{{ k.desc }}</div>
        </button>
      </nav>
      <section class="card min-w-0">
        <div class="flex flex-wrap items-end justify-between gap-3 p-4 sm:p-5 border-b border-line">
          <div><h2 class="h-section">{{ meta.name }}</h2><p class="sub">{{ subtitle }}</p></div>
          <div class="flex flex-wrap items-end gap-2">
            <template v-if="meta.dated">
              <div><label class="label" for="rp-f">From</label><input id="rp-f" v-model="from" type="date" class="input h-8" /></div>
              <div><label class="label" for="rp-t">To</label><input id="rp-t" v-model="to" type="date" class="input h-8" /></div>
              <div class="seg"><button @click="preset('month')">Month</button><button @click="preset('term')">Term</button><button @click="preset('year')">Year</button></div>
            </template>
            <button class="btn btn-secondary btn-sm" :disabled="!report.rows.length" @click="exportAs('csv')"><Download :size="14" />CSV</button>
            <button class="btn btn-primary btn-sm" :disabled="!report.rows.length" @click="exportAs('pdf')"><FileDown :size="14" />PDF</button>
          </div>
        </div>
        <dl v-if="report.summary.length" class="flex flex-wrap gap-x-8 gap-y-2 px-4 sm:px-5 py-3 border-b border-line text-[13px]">
          <div v-for="[k, v] in report.summary" :key="k"><dt class="text-muted text-[12px]">{{ k }}</dt><dd class="font-semibold tnum">{{ v }}</dd></div>
        </dl>
        <div v-if="report.rows.length" class="table-wrap max-h-[560px] overflow-y-auto"><table class="tbl">
          <thead class="sticky top-0"><tr><th v-for="h in report.head" :key="h">{{ h }}</th></tr></thead>
          <tbody><tr v-for="(r, i) in report.rows.slice(0, 200)" :key="i"><td v-for="(c, j) in r" :key="j" class="whitespace-nowrap tnum">{{ c }}</td></tr></tbody>
        </table></div>
        <EmptyState v-else title="Nothing in this period" body="Widen the date range to include more records." />
        <p v-if="report.rows.length > 200" class="px-4 py-2 text-[12px] text-muted border-t border-line">Showing the first 200 of {{ report.rows.length }} rows. Exports include every row.</p>
      </section>
    </div>
  </div>
</template>
