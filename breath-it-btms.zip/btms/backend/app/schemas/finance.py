from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from pydantic import BaseModel, Field, model_validator
from .common import ORM

Method = Literal["Cash", "Mobile Money", "Bank Transfer", "Card"]
Network = Literal["Airtel", "MTN", "Zamtel"]
Category = Literal["Tuition", "Registration", "Examination", "Materials"]


class PaymentIn(BaseModel):
    student_id: str
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    payment_date: date
    method: Method
    category: Category
    term: str
    external_ref: str | None = Field(default=None, max_length=60)
    notes: str | None = None
    verify_now: bool = False
    network: Network | None = None

    @model_validator(mode="after")
    def _ref(self):
        if self.method != "Cash" and not (self.external_ref or "").strip():
            raise ValueError("Mobile Money and bank payments need a transaction reference so they can be verified")
        if self.payment_date > date.today():
            raise ValueError("Payment date cannot be in the future")
        return self


class RejectIn(BaseModel):
    reason: str = Field(min_length=3, max_length=300)


class PaymentOut(ORM):
    id: str
    reference: str
    student_id: str
    amount: Decimal
    payment_date: date
    method: str
    category: str
    term: str
    external_ref: str | None
    status: str
    recorded_by: str
    recorded_at: datetime
    verified_by: str | None
    verified_at: datetime | None
    balance_after: Decimal
    notes: str | None
    channel: str = "office"
    network: str | None = None
    payer_phone: str | None = None
    gateway_ref: str | None = None
    gateway_status: str | None = None
    receipt_no: str | None = None


class BalanceOut(BaseModel):
    student_id: str
    student_no: str
    name: str
    billed: Decimal
    paid: Decimal
    pending: Decimal
    balance: Decimal


class FeeOut(ORM):
    id: str
    grade_id: str
    category: str
    amount: Decimal
    frequency: str
    description: str


class FeeUpdate(BaseModel):
    amount: Decimal = Field(ge=0)


class ChargeOut(ORM):
    id: str
    student_id: str
    category: str
    term: str
    amount: Decimal
    description: str
    issued_on: date
    due_date: date


class OnlinePayIn(BaseModel):
    """Parent / student checkout. Mobile money pushes a PIN prompt; card returns a hosted checkout URL."""
    student_id: str
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    method: Literal["Mobile Money", "Card"]
    network: Network | None = None
    phone: str | None = None

    @model_validator(mode="after")
    def _mm(self):
        if self.method == "Mobile Money" and (not self.network or not self.phone):
            raise ValueError("Mobile money needs the network and the phone number that will approve the payment")
        return self


class OnlinePayOut(BaseModel):
    payment: PaymentOut
    checkout_url: str | None = None
    message: str


class BankTransferIn(BaseModel):
    student_id: str
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    reference: str = Field(min_length=3, max_length=60)
    payment_date: date


class GatewayEvent(BaseModel):
    gateway_ref: str
    status: Literal["confirmed", "declined", "timed_out"]
    amount: Decimal | None = None
