from datetime import date, timedelta

API = "/api/v1"


def test_health(client):
    assert client.get("/health").json() == {"status": "ok"}


def test_bad_login_and_missing_token(client):
    assert client.post(f"{API}/auth/login", data={"username": "admin@breathit.demo", "password": "wrong"}).status_code == 401
    assert client.get(f"{API}/students").status_code == 401


def test_me_reports_role(client, parent):
    me = client.get(f"{API}/auth/me", headers=parent).json()
    assert me["role"] == "parent" and me["linked_id"] == "p01"


def test_role_scoping(client, admin, tutor, student, parent):
    assert len(client.get(f"{API}/students", headers=admin).json()) == 24
    kids = {s["id"] for s in client.get(f"{API}/students", headers=parent).json()}
    assert kids == {"s01", "s02"}
    assert [s["id"] for s in client.get(f"{API}/students", headers=student).json()] == ["s01"]
    assert client.get(f"{API}/students/s03", headers=parent).status_code == 404       # not their child
    assert client.get(f"{API}/finance/payments", headers=tutor).status_code == 403    # tutors: no finance
    assert client.get(f"{API}/students/s02/statement", headers=tutor).status_code == 403
    tutor_students = {s["id"] for s in client.get(f"{API}/students", headers=tutor).json()}
    assert tutor_students and "s02" in tutor_students and "s04" not in tutor_students  # s04 is Grade 7 (not taught by t1)


def test_balance_matches_brief_example(client, admin):
    st = client.get(f"{API}/students/s02/statement", headers=admin).json()
    assert float(st["balance"]) == 400.0  # John Banda: K1,000 tuition, K600 paid


def test_pending_payment_does_not_reduce_balance_until_verified(client, admin):
    before = float(client.get(f"{API}/students/s02/statement", headers=admin).json()["balance"])
    body = {"student_id": "s02", "amount": "150.00", "payment_date": date.today().isoformat(), "method": "Mobile Money",
            "category": "Tuition", "term": "Term 3 2026", "external_ref": "MP-TEST-0001"}
    p = client.post(f"{API}/finance/payments", json=body, headers=admin).json()
    assert p["status"] == "pending" and p["receipt_no"] is None
    assert float(client.get(f"{API}/students/s02/statement", headers=admin).json()["balance"]) == before
    assert client.post(f"{API}/finance/payments", json=body, headers=admin).status_code == 409          # duplicate transaction id
    v = client.post(f"{API}/finance/payments/{p['id']}/verify", headers=admin).json()
    assert v["status"] == "verified" and v["receipt_no"].startswith("RCT-")
    assert float(client.get(f"{API}/students/s02/statement", headers=admin).json()["balance"]) == before - 150
    assert client.post(f"{API}/finance/payments/{p['id']}/verify", headers=admin).status_code == 409    # cannot verify twice


def test_mobile_money_requires_reference(client, admin):
    body = {"student_id": "s02", "amount": "10", "payment_date": date.today().isoformat(), "method": "Mobile Money", "category": "Tuition", "term": "Term 3 2026"}
    assert client.post(f"{API}/finance/payments", json=body, headers=admin).status_code == 422


def test_attendance_upsert_never_duplicates(client, tutor):
    slots = client.get(f"{API}/timetable", headers=tutor).json()
    slot = slots[0]
    d = date.today()
    while d.isoweekday() != slot["day_of_week"]:
        d -= timedelta(days=1)
    d -= timedelta(days=7 * 8)  # a date with no register in the seed
    reg = client.get(f"{API}/attendance/register", params={"slot_id": slot["id"], "lesson_date": d.isoformat()}, headers=tutor).json()
    if not reg["students"]:
        return
    marks = [{"student_id": s["id"], "status": "present"} for s in reg["students"]]
    r1 = client.post(f"{API}/attendance/register", json={"slot_id": slot["id"], "lesson_date": d.isoformat(), "marks": marks}, headers=tutor).json()
    marks[0]["status"] = "absent"
    r2 = client.post(f"{API}/attendance/register", json={"slot_id": slot["id"], "lesson_date": d.isoformat(), "marks": marks}, headers=tutor).json()
    assert r1 == {"created": len(marks), "updated": 0} and r2 == {"created": 0, "updated": 1}


def test_tutor_cannot_mark_other_tutors_lesson(client, admin, tutor):
    other = next(s for s in client.get(f"{API}/timetable", headers=admin).json() if s["tutor_id"] != "t1")
    r = client.post(f"{API}/attendance/register", json={"slot_id": other["id"], "lesson_date": date.today().isoformat(), "marks": [{"student_id": "s01", "status": "present"}]}, headers=tutor)
    assert r.status_code == 403


def test_timetable_conflicts_rejected(client, admin):
    existing = client.get(f"{API}/timetable", headers=admin).json()[0]
    body = {k: existing[k] for k in ("class_id", "subject_id", "tutor_id", "day_of_week", "start_time", "end_time", "room")}
    r = client.post(f"{API}/timetable", json=body, headers=admin)
    assert r.status_code == 409 and r.json()["detail"]["conflicts"]


def test_assessment_validation_and_percentages(client, tutor):
    body = {"class_id": "c-g8a", "subject_id": "s-math", "assessment_type": "Test", "title": "API quiz", "max_marks": "40",
            "assessment_date": date.today().isoformat(), "results": [{"student_id": "s02", "marks": "34", "comment": "Good"}]}
    res = client.post(f"{API}/assessments", json=body, headers=tutor)
    assert res.status_code == 201 and res.json()[0]["percentage"] == 85.0
    assert client.post(f"{API}/assessments", json=body, headers=tutor).status_code == 409             # same sitting twice
    body["title"] = "Too many marks"; body["results"][0]["marks"] = "41"
    assert client.post(f"{API}/assessments", json=body, headers=tutor).status_code == 422
    body["title"] = "Not my subject"; body["subject_id"] = "s-eng"; body["results"][0]["marks"] = "10"
    assert client.post(f"{API}/assessments", json=body, headers=tutor).status_code == 403


def test_announcements_never_pretend_to_send(client, admin, parent):
    a = client.post(f"{API}/announcements", json={"title": "Test", "body": "Hello parents", "audience": "parents", "send_sms": True}, headers=admin).json()
    assert a["sms_status"] == "not_configured" and a["whatsapp_status"] == "not_requested"
    assert any(x["id"] == a["id"] for x in client.get(f"{API}/announcements", headers=parent).json())


def test_register_student_creates_charges_and_audit(client, admin):
    body = {"first_name": "Test", "last_name": "Learner", "date_of_birth": "2012-05-05", "gender": "Female", "grade_id": "g8", "class_id": "c-g8a",
            "new_parent": {"name": "Test Parent", "phone": "0977 000 111", "address": "Kaunda Square", "relationship_to_student": "Mother"},
            "address": "Kaunda Square", "enrolment_date": date.today().isoformat(), "subject_ids": ["s-math", "s-eng"]}
    s = client.post(f"{API}/students", json=body, headers=admin)
    assert s.status_code == 201, s.text
    st = client.get(f"{API}/students/{s.json()['id']}/statement", headers=admin).json()
    assert len(st["charges"]) == 2 and float(st["balance"]) > 0
    assert any(a["action"] == "student.created" for a in client.get(f"{API}/audit", headers=admin).json())
    body["new_parent"]["phone"] = "12345"
    assert client.post(f"{API}/students", json=body, headers=admin).status_code == 422


def test_dashboard_and_reports(client, admin):
    d = client.get(f"{API}/dashboard/summary", headers=admin).json()
    assert d["students_total"] >= 24 and float(d["outstanding"]) > 0
    csv = client.get(f"{API}/reports/collections", params={"fmt": "csv"}, headers=admin)
    assert csv.status_code == 200 and csv.headers["content-type"].startswith("text/csv")
    assert client.get(f"{API}/reports/tutors", headers=admin).json()["rows"]
