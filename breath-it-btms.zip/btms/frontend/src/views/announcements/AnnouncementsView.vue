<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { Plus, Trash2, MessageSquare, Smartphone, Bell } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import Modal from '@/components/ui/Modal.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useAuth } from '@/stores/auth'
import { useScope } from '@/composables/useScope'
import { useAnnouncements } from '@/composables/useAnnouncements'
import type { Audience } from '@/types'
import { fmtDateTime } from '@/services/dates'

const store = useDb(); const ui = useUi(); const auth = useAuth(); const scope = useScope(); const list = useAnnouncements()
const canPost = computed(() => scope.role.value === 'admin' || scope.role.value === 'tutor')
const audLabel = (a: Audience, classId?: string) => ({ everyone: 'Everyone', parents: 'Parents', students: 'Students', tutors: 'Tutors', class: store.className(classId ?? '') })[a]
const open = ref(false); const err = ref('')
const f = reactive({ title: '', body: '', audience: 'everyone' as Audience, classId: '', priority: 'normal' as 'normal' | 'important', sms: false, whatsapp: false })
const smsReady = computed(() => !!store.db.settings.smsProvider)
const waReady = computed(() => !!store.db.settings.whatsappProvider)
function start() { Object.assign(f, { title: '', body: '', audience: scope.role.value === 'tutor' ? 'class' : 'everyone', classId: [...scope.classIds.value][0] ?? '', priority: 'normal', sms: false, whatsapp: false }); err.value = ''; open.value = true }
function post() {
  if (!f.title.trim() || !f.body.trim()) return (err.value = 'Add a title and a message.')
  if (f.audience === 'class' && !f.classId) return (err.value = 'Choose a class.')
  store.addAnnouncement({ title: f.title.trim(), body: f.body.trim(), audience: f.audience, classId: f.audience === 'class' ? f.classId : undefined, priority: f.priority, channels: { inApp: true, sms: f.sms, whatsapp: f.whatsapp } })
  const extra = f.sms || f.whatsapp ? ' SMS/WhatsApp were not sent — no messaging provider is connected yet.' : ''
  ui.success('Announcement posted', `Visible in the portal now.${extra}`); open.value = false
}
async function remove(id: string) {
  if (!(await ui.confirm({ title: 'Delete announcement?', body: 'It will be removed from every portal.', confirmLabel: 'Delete', tone: 'danger' }))) return
  store.deleteAnnouncement(id); ui.success('Announcement deleted')
}
</script>
<template>
  <div>
    <PageHeader title="Announcements" :sub="canPost ? 'Post updates to everyone, a group, or a single class' : 'Updates from Breath It'">
      <button v-if="canPost" class="btn btn-primary" @click="start"><Plus :size="15" />New announcement</button>
    </PageHeader>
    <EmptyState v-if="!list.length" title="No announcements yet" />
    <div class="grid gap-3 max-w-3xl">
      <article v-for="a in list" :key="a.id" :class="['card card-pad', a.priority === 'important' && 'border-l-4 border-l-bad']">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <div class="flex items-center gap-2 flex-wrap"><h2 class="font-semibold">{{ a.title }}</h2><span v-if="a.priority === 'important'" class="badge badge-bad">Important</span><span class="badge badge-mute">{{ audLabel(a.audience, a.classId) }}</span></div>
            <p class="text-[12px] text-muted mt-0.5">{{ a.authorName }} · {{ fmtDateTime(a.createdAt) }}</p>
          </div>
          <button v-if="scope.role.value === 'admin' || a.authorId === auth.user?.linkedId || a.authorId === auth.user?.id" class="icon-btn" aria-label="Delete announcement" @click="remove(a.id)"><Trash2 :size="15" /></button>
        </div>
        <p class="text-[13.5px] mt-2.5 leading-relaxed max-w-[70ch]">{{ a.body }}</p>
        <div v-if="canPost" class="flex flex-wrap gap-3 mt-3 pt-3 border-t border-line text-[12px] text-muted">
          <span class="flex items-center gap-1.5"><Bell :size="13" class="text-ok" />In-app: delivered</span>
          <span v-if="a.channels.sms" class="flex items-center gap-1.5"><Smartphone :size="13" class="text-warn" />SMS: requested, not sent (no provider)</span>
          <span v-if="a.channels.whatsapp" class="flex items-center gap-1.5"><MessageSquare :size="13" class="text-warn" />WhatsApp: requested, not sent (no provider)</span>
        </div>
      </article>
    </div>
    <Modal :open="open" title="New announcement" size="lg" @close="open = false">
      <form class="grid sm:grid-cols-2 gap-4" @submit.prevent="post">
        <div class="sm:col-span-2"><label class="label" for="an-t">Title</label><input id="an-t" v-model="f.title" class="input" /></div>
        <div class="sm:col-span-2"><label class="label" for="an-b">Message</label><textarea id="an-b" v-model="f.body" class="textarea min-h-[120px]" /></div>
        <div><label class="label" for="an-a">Audience</label>
          <select id="an-a" v-model="f.audience" class="select">
            <template v-if="scope.role.value === 'admin'"><option value="everyone">Everyone</option><option value="parents">Parents</option><option value="students">Students</option><option value="tutors">Tutors</option></template>
            <option value="class">A single class</option>
          </select></div>
        <div v-if="f.audience === 'class'"><label class="label" for="an-c">Class</label><select id="an-c" v-model="f.classId" class="select"><option v-for="c in store.db.classes.filter((x) => scope.classIds.value.has(x.id))" :key="c.id" :value="c.id">{{ c.name }}</option></select></div>
        <div><label class="label" for="an-p">Priority</label><select id="an-p" v-model="f.priority" class="select"><option value="normal">Normal</option><option value="important">Important</option></select></div>
        <fieldset class="sm:col-span-2 rounded-md border border-line p-3">
          <legend class="px-1 text-[12.5px] font-medium text-muted">Also send by</legend>
          <label class="flex items-center gap-2.5 text-[13px]"><input v-model="f.sms" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />SMS <span class="text-muted">{{ smsReady ? '' : '— no provider connected; will be recorded only' }}</span></label>
          <label class="flex items-center gap-2.5 text-[13px] mt-2"><input v-model="f.whatsapp" type="checkbox" class="h-4 w-4 accent-[rgb(var(--brand))]" />WhatsApp <span class="text-muted">{{ waReady ? '' : '— no provider connected; will be recorded only' }}</span></label>
        </fieldset>
        <p v-if="err" class="sm:col-span-2 field-error text-[13px]">{{ err }}</p>
        <button type="submit" class="hidden" />
      </form>
      <template #footer><button class="btn btn-secondary" @click="open = false">Cancel</button><button class="btn btn-primary" @click="post">Post announcement</button></template>
    </Modal>
  </div>
</template>
