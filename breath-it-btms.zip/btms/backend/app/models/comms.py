from datetime import datetime
from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column
from ..db import Base, new_id
from .users import utcnow


class Announcement(Base):
    __tablename__ = "announcements"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("an-"))
    title: Mapped[str] = mapped_column(String(160))
    body: Mapped[str] = mapped_column(Text)
    audience: Mapped[str] = mapped_column(String(12), index=True)  # everyone | parents | students | tutors | class
    class_id: Mapped[str | None] = mapped_column(ForeignKey("classes.id", ondelete="CASCADE"), nullable=True)
    priority: Mapped[str] = mapped_column(String(10), default="normal")
    author_id: Mapped[str] = mapped_column(String(40))
    author_name: Mapped[str] = mapped_column(String(120))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    # Requested external channels and their real delivery state: 'not_requested' | 'not_configured' | 'queued' | 'sent' | 'failed'
    sms_status: Mapped[str] = mapped_column(String(16), default="not_requested")
    whatsapp_status: Mapped[str] = mapped_column(String(16), default="not_requested")


class LearningMaterial(Base):
    __tablename__ = "learning_materials"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("m-"))
    title: Mapped[str] = mapped_column(String(160))
    description: Mapped[str] = mapped_column(String(400), default="")
    kind: Mapped[str] = mapped_column(String(20))
    subject_id: Mapped[str] = mapped_column(ForeignKey("subjects.id"), index=True)
    class_id: Mapped[str] = mapped_column(ForeignKey("classes.id", ondelete="CASCADE"), index=True)
    tutor_id: Mapped[str | None] = mapped_column(ForeignKey("tutors.id", ondelete="SET NULL"), nullable=True)
    content: Mapped[str | None] = mapped_column(Text, nullable=True)
    link: Mapped[str | None] = mapped_column(String(500), nullable=True)
    file_key: Mapped[str | None] = mapped_column(String(300), nullable=True)  # object-storage key once uploads are enabled
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("au-"))
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    actor_id: Mapped[str] = mapped_column(String(40), index=True)
    actor_name: Mapped[str] = mapped_column(String(120))
    action: Mapped[str] = mapped_column(String(60), index=True)
    entity: Mapped[str] = mapped_column(String(40))
    entity_id: Mapped[str] = mapped_column(String(60), default="")
    detail: Mapped[str] = mapped_column(Text, default="")
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)


class CentreSetting(Base):
    """Single-row key/value settings (centre details, terms, policies)."""
    __tablename__ = "centre_settings"
    key: Mapped[str] = mapped_column(String(60), primary_key=True)
    value: Mapped[dict] = mapped_column(JSON)
