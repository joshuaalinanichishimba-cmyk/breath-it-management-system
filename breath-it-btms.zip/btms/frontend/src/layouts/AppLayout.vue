<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { Menu, Search, LogOut, X, ChevronsUpDown, Repeat } from 'lucide-vue-next'
import { useAuth } from '@/stores/auth'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useScope } from '@/composables/useScope'
import { navFor } from './nav'
import BrandMark from '@/components/ui/BrandMark.vue'
import Avatar from '@/components/ui/Avatar.vue'
import { DEMO_MODE } from '@/config'
import { DEMO_ACCOUNTS, ROLE_LABEL } from '@/services/demo/accounts'

const auth = useAuth(); const store = useDb(); const ui = useUi(); const route = useRoute(); const router = useRouter()
const scope = useScope()
const groups = computed(() => (auth.role ? navFor(auth.role, { showFees: store.db.settings.showFeesToStudents }) : []))
watch(() => route.fullPath, () => { ui.mobileNav = false; menu.value = false; q.value = '' })

const q = ref('')
const results = computed(() => {
  const t = q.value.trim().toLowerCase()
  if (t.length < 2) return []
  return scope.students.value.filter((s) => `${s.firstName} ${s.lastName} ${s.studentNo}`.toLowerCase().includes(t)).slice(0, 6)
})
const canSearch = computed(() => auth.role === 'admin' || auth.role === 'tutor')
function go(id: string) { router.push(`/students/${id}`) }

const menu = ref(false)
function logout() { auth.logout(); router.push('/login') }
async function switchTo(email: string) {
  const acc = DEMO_ACCOUNTS.find((a) => a.email === email)!
  await auth.login(acc.email, acc.password)
  ui.selectedChildId = null
  router.push('/dashboard')
  ui.info(`Now viewing as ${acc.name}`, ROLE_LABEL[acc.role])
}
const isActive = (to: string) => route.path === to || (to !== '/dashboard' && route.path.startsWith(to + '/'))
</script>

<template>
  <div class="h-full flex">
    <!-- Sidebar -->
    <div v-if="ui.mobileNav" class="fixed inset-0 z-40 bg-ink/40 lg:hidden" @click="ui.mobileNav = false" />
    <aside :class="['fixed lg:static z-40 inset-y-0 left-0 w-[248px] shrink-0 bg-surface border-r border-line flex flex-col transition-transform lg:translate-x-0', ui.mobileNav ? 'translate-x-0' : '-translate-x-full']"
      style="padding-top: env(safe-area-inset-top, 0px)">
      <div class="h-14 px-4 flex items-center justify-between border-b border-line">
        <BrandMark />
        <button class="icon-btn lg:hidden" aria-label="Close menu" @click="ui.mobileNav = false"><X :size="18" /></button>
      </div>
      <nav class="flex-1 overflow-y-auto px-2.5 py-3" aria-label="Main">
        <div v-for="(g, gi) in groups" :key="gi" class="mb-3">
          <div v-if="g.label" class="px-2.5 pb-1 pt-1 text-[11.5px] font-medium text-faint">{{ g.label }}</div>
          <RouterLink v-for="item in g.items" :key="item.to" :to="item.to"
            :class="['flex items-center gap-2.5 h-9 px-2.5 rounded-md text-[13.5px] transition-colors', isActive(item.to) ? 'bg-brand-soft text-ink font-medium' : 'text-muted hover:text-ink hover:bg-sunken']">
            <component :is="item.icon" :size="17" :class="isActive(item.to) ? 'text-brand' : ''" />{{ item.label }}
          </RouterLink>
        </div>
      </nav>
      <div class="p-3 border-t border-line text-[11.5px] text-muted leading-snug">
        <div class="font-medium text-ink text-[12px]">{{ store.db.settings.currentTerm }}</div>
        Kaunda Square Stage Two, Lusaka
      </div>
    </aside>

    <!-- Main column -->
    <div class="flex-1 min-w-0 flex flex-col h-full">
      <div v-if="DEMO_MODE" class="shrink-0 bg-brand text-brand-ink text-[12px] px-4 py-1.5 text-center">
        Demonstration system — all students, payments and marks are fictional sample data. Changes are kept only in this browser.
      </div>
      <header class="h-14 shrink-0 bg-surface/90 backdrop-blur border-b border-line flex items-center gap-2 px-3 sm:px-5">
        <button class="icon-btn lg:hidden" aria-label="Open menu" @click="ui.mobileNav = true"><Menu :size="19" /></button>
        <div v-if="canSearch" class="relative flex-1 max-w-md">
          <Search :size="15" class="absolute left-3 top-1/2 -translate-y-1/2 text-faint" />
          <input v-model="q" class="input pl-9 h-9 bg-sunken/70 border-transparent" :placeholder="auth.role === 'tutor' ? 'Find one of your students' : 'Find a student by name or number'" aria-label="Search students" />
          <div v-if="q.trim().length >= 2" class="absolute z-30 mt-1 w-full card shadow-lg py-1">
            <button v-for="s in results" :key="s.id" class="w-full text-left px-3 py-2 hover:bg-sunken flex items-center gap-2.5" @click="go(s.id)">
              <Avatar :name="`${s.firstName} ${s.lastName}`" :size="26" />
              <span class="flex-1 min-w-0"><span class="font-medium">{{ s.firstName }} {{ s.lastName }}</span>
                <span class="block text-[12px] text-muted tnum">{{ s.studentNo }} · {{ store.className(s.classId) }}</span></span>
            </button>
            <div v-if="!results.length" class="px-3 py-2.5 text-[13px] text-muted">No students match “{{ q }}”.</div>
          </div>
        </div>
        <div v-else class="flex-1" />
        <div class="relative ml-auto">
          <button class="flex items-center gap-2 h-10 pl-1 pr-2 rounded-md hover:bg-sunken" :aria-expanded="menu" @click="menu = !menu">
            <Avatar :name="auth.user?.name ?? ''" :size="30" />
            <span class="hidden sm:block text-left leading-tight">
              <span class="block text-[13px] font-medium">{{ auth.user?.name }}</span>
              <span class="block text-[11.5px] text-muted">{{ auth.role ? ROLE_LABEL[auth.role] : '' }}</span>
            </span>
            <ChevronsUpDown :size="14" class="text-faint" />
          </button>
          <div v-if="menu" class="absolute right-0 mt-1 w-64 card shadow-lg py-1.5 z-30">
            <div class="px-3 py-2 text-[12px] text-muted border-b border-line mb-1">{{ auth.user?.email }}</div>
            <template v-if="DEMO_MODE">
              <div class="px-3 pt-1 pb-1 text-[11.5px] text-faint flex items-center gap-1.5"><Repeat :size="12" />View the demo as</div>
              <button v-for="a in DEMO_ACCOUNTS" :key="a.id" :disabled="a.id === auth.user?.id"
                class="w-full text-left px-3 py-1.5 text-[13px] hover:bg-sunken disabled:opacity-50 flex justify-between" @click="switchTo(a.email)">
                <span>{{ a.name }}</span><span class="text-muted text-[12px]">{{ ROLE_LABEL[a.role] }}</span>
              </button>
              <div class="border-t border-line my-1" />
            </template>
            <button class="w-full text-left px-3 py-2 text-[13px] hover:bg-sunken flex items-center gap-2 text-bad" @click="logout"><LogOut :size="15" />Sign out</button>
          </div>
        </div>
      </header>
      <main class="flex-1 overflow-y-auto" @click="menu = false">
        <div class="max-w-[1280px] mx-auto px-3 sm:px-6 py-5 sm:py-7">
          <RouterView v-slot="{ Component }"><component :is="Component" :key="route.fullPath" /></RouterView>
        </div>
      </main>
    </div>
  </div>
</template>
