/**
 * Demo repository. Holds the in-browser database and every domain action (with validation + audit trail).
 * In connected mode these actions map 1:1 onto backend endpoints (see services/api.ts and backend/app/api/v1).
 */
import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import type {
  Announcement, Assessment, AssessmentType, AttendanceStatus, Charge, ClassGroup, DemoDatabase, FeeCategory,
  Lesson, Material, Parent, Payment, PaymentMethod, Student, StudentStatus, Subject, Tutor, Grade, CentreSettings,
  Lead, LeadStage, MobileNetwork,
} from '@/types'
import { NETWORK_LABEL } from '@/services/payments'
import { buildSeed, SEED_VERSION, termFor } from '@/services/demo/seed'
import { STORAGE_KEY } from '@/config'
import { addDays, iso, timeToMinutes, DAY_NAMES } from '@/services/dates'
import { fullName, kwacha, round2 } from '@/services/format'
import { useAuth } from './auth'

function loadDb(): DemoDatabase {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) {
      const parsed = JSON.parse(raw) as DemoDatabase
      if (parsed.version === SEED_VERSION) return parsed
    }
  } catch { /* storage unavailable or corrupt: fall back to a fresh seed */ }
  return buildSeed(iso())
}

export const useDb = defineStore('db', () => {
  const db = ref<DemoDatabase>(loadDb())
  let timer: ReturnType<typeof setTimeout> | undefined
  watch(db, () => {
    clearTimeout(timer)
    timer = setTimeout(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(db.value)) } catch { /* ignore */ } }, 300)
  }, { deep: true })

  // ---------- lookups ----------
  const byId = <T extends { id: string }>(arr: () => T[]) => computed(() => new Map(arr().map((x) => [x.id, x])))
  const studentMap = byId(() => db.value.students)
  const tutorMap = byId(() => db.value.tutors)
  const parentMap = byId(() => db.value.parents)
  const classMap = byId(() => db.value.classes)
  const subjectMap = byId(() => db.value.subjects)
  const gradeMap = byId(() => db.value.grades)
  const lessonMap = byId(() => db.value.lessons)

  const studentName = (id: string) => { const s = studentMap.value.get(id); return s ? fullName(s) : 'Unknown student' }
  const tutorName = (id: string) => { const t = tutorMap.value.get(id); return t ? fullName(t) : '—' }
  const subjectName = (id: string) => subjectMap.value.get(id)?.name ?? '—'
  const className = (id: string) => classMap.value.get(id)?.name ?? '—'
  const gradeName = (id: string) => gradeMap.value.get(id)?.name ?? '—'

  // ---------- finance helpers (only VERIFIED payments reduce a balance) ----------
  function billed(studentId: string, term?: string) {
    return db.value.charges.filter((c) => c.studentId === studentId && (!term || c.term === term)).reduce((a, c) => a + c.amount, 0)
  }
  function paid(studentId: string, term?: string) {
    return db.value.payments.filter((p) => p.studentId === studentId && p.status === 'verified' && (!term || p.term === term)).reduce((a, p) => a + p.amount, 0)
  }
  function pendingAmount(studentId: string) {
    return db.value.payments.filter((p) => p.studentId === studentId && p.status === 'pending').reduce((a, p) => a + p.amount, 0)
  }
  function balance(studentId: string, term?: string) { return round2(billed(studentId, term) - paid(studentId, term)) }

  // ---------- infrastructure ----------
  function actor() { const a = useAuth(); return { id: a.user?.id ?? 'system', name: a.user?.name ?? 'System' } }
  function counter(key: string) { db.value.counters[key] = (db.value.counters[key] ?? 0) + 1; return db.value.counters[key] }
  function uid(prefix: string) { return `${prefix}${counter('uid:' + prefix)}-${Date.now().toString(36)}` }
  function log(action: string, entity: string, entityId: string, detail: string) {
    const a = actor()
    db.value.audit.unshift({ id: uid('au'), at: new Date().toISOString(), actorId: a.id, actorName: a.name, action, entity, entityId, detail })
  }
  function reset() { db.value = buildSeed(iso()) }

  // ---------- students ----------
  type StudentInput = Omit<Student, 'id' | 'studentNo'>
  function addStudent(input: StudentInput, opts: { chargeRegistration: boolean }) {
    const year = input.enrolmentDate.slice(0, 4)
    const seq = counter('student')
    const s: Student = { ...input, id: uid('s'), studentNo: `BIT-${year}-${String(seq).padStart(3, '0')}` }
    db.value.students.push(s)
    db.value.enrolmentEvents.push({ id: uid('ev'), studentId: s.id, date: s.enrolmentDate, action: 'Registered', detail: `Enrolled in ${gradeName(s.gradeId)}, ${className(s.classId)}` })
    const term = termFor(s.enrolmentDate)
    if (opts.chargeRegistration) {
      const reg = db.value.feeStructures.find((f) => f.gradeId === s.gradeId && f.category === 'Registration')
      if (reg) addCharge({ studentId: s.id, category: 'Registration', term, amount: reg.amount, description: 'Registration fee', issuedOn: s.enrolmentDate, dueDate: s.enrolmentDate }, false)
    }
    const tui = db.value.feeStructures.find((f) => f.gradeId === s.gradeId && f.category === 'Tuition')
    if (tui && opts.chargeRegistration) addCharge({ studentId: s.id, category: 'Tuition', term, amount: tui.amount, description: `${term} tuition`, issuedOn: s.enrolmentDate, dueDate: addDays(s.enrolmentDate, 14) }, false)
    log('student.created', 'student', s.studentNo, `Registered ${fullName(s)} (${gradeName(s.gradeId)})`)
    return s
  }
  function updateStudent(id: string, patch: Partial<StudentInput>) {
    const s = studentMap.value.get(id)
    if (!s) throw new Error('Student not found')
    const changes: string[] = []
    if (patch.classId && patch.classId !== s.classId) changes.push(`class ${className(s.classId)} → ${className(patch.classId)}`)
    if (patch.gradeId && patch.gradeId !== s.gradeId) changes.push(`grade ${gradeName(s.gradeId)} → ${gradeName(patch.gradeId)}`)
    if (patch.subjectIds && patch.subjectIds.join() !== s.subjectIds.join()) changes.push('subjects updated')
    if (patch.status && patch.status !== s.status) changes.push(`status ${s.status} → ${patch.status}`)
    Object.assign(s, patch)
    if (changes.length) db.value.enrolmentEvents.push({ id: uid('ev'), studentId: id, date: iso(), action: 'Record updated', detail: changes.join('; ') })
    log('student.updated', 'student', s.studentNo, `${fullName(s)}: ${changes.join('; ') || 'details edited'}`)
  }
  function setStudentStatus(id: string, status: StudentStatus) { updateStudent(id, { status }) }

  // ---------- parents / tutors ----------
  function addParent(p: Omit<Parent, 'id'>) { const x = { ...p, id: uid('p') }; db.value.parents.push(x); log('parent.created', 'parent', x.id, x.name); return x }
  function updateParent(id: string, patch: Partial<Parent>) { const p = parentMap.value.get(id); if (!p) return; Object.assign(p, patch); log('parent.updated', 'parent', id, p.name) }
  function addTutor(t: Omit<Tutor, 'id' | 'staffNo'>) {
    const x: Tutor = { ...t, id: uid('t'), staffNo: `BIT-T-${String(db.value.tutors.length + 1).padStart(3, '0')}` }
    db.value.tutors.push(x); log('tutor.created', 'tutor', x.staffNo, fullName(x)); return x
  }
  function updateTutor(id: string, patch: Partial<Tutor>) { const t = tutorMap.value.get(id); if (!t) return; Object.assign(t, patch); log('tutor.updated', 'tutor', t.staffNo, fullName(t)) }

  // ---------- classes / subjects / grades ----------
  function saveClass(c: Omit<ClassGroup, 'id'> & { id?: string }) {
    if (db.value.classes.some((x) => x.name.trim().toLowerCase() === c.name.trim().toLowerCase() && x.id !== c.id)) throw new Error('A class with this name already exists.')
    if (c.id) { Object.assign(classMap.value.get(c.id)!, c); log('class.updated', 'class', c.id, c.name); return }
    const x = { ...c, id: uid('c') } as ClassGroup
    db.value.classes.push(x); log('class.created', 'class', x.id, x.name)
  }
  function saveSubject(s: Omit<Subject, 'id'> & { id?: string }) {
    if (db.value.subjects.some((x) => x.code.toUpperCase() === s.code.toUpperCase() && x.id !== s.id)) throw new Error('Subject code must be unique.')
    if (s.id) { Object.assign(subjectMap.value.get(s.id)!, s); log('subject.updated', 'subject', s.id, s.name); return }
    const x = { ...s, id: uid('s-') } as Subject
    db.value.subjects.push(x); log('subject.created', 'subject', x.id, x.name)
  }
  function addGrade(g: Omit<Grade, 'id'>) { const x = { ...g, id: uid('g') }; db.value.grades.push(x); log('grade.created', 'grade', x.id, x.name); return x }

  // ---------- timetable ----------
  function lessonConflicts(d: Omit<Lesson, 'id'>, ignoreId?: string): string[] {
    const a1 = timeToMinutes(d.start), a2 = timeToMinutes(d.end)
    const out: string[] = []
    if (a2 <= a1) out.push('End time must be after the start time.')
    for (const l of db.value.lessons) {
      if (l.id === ignoreId || l.day !== d.day) continue
      const overlap = a1 < timeToMinutes(l.end) && timeToMinutes(l.start) < a2
      if (!overlap) continue
      const when = `${DAY_NAMES[l.day]} ${l.start}–${l.end}`
      if (l.tutorId === d.tutorId) out.push(`${tutorName(l.tutorId)} already teaches ${subjectName(l.subjectId)} (${className(l.classId)}) on ${when}.`)
      if (l.room === d.room) out.push(`${l.room} is already booked for ${className(l.classId)} on ${when}.`)
      if (l.classId === d.classId) out.push(`${className(l.classId)} already has ${subjectName(l.subjectId)} on ${when}.`)
    }
    return [...new Set(out)]
  }
  function saveLesson(d: Omit<Lesson, 'id'> & { id?: string }) {
    const errs = lessonConflicts(d, d.id)
    if (errs.length) throw new Error(errs[0])
    const label = `${className(d.classId)} ${subjectName(d.subjectId)} ${DAY_NAMES[d.day]} ${d.start}`
    if (d.id) { Object.assign(lessonMap.value.get(d.id)!, d); log('timetable.updated', 'lesson', d.id, label); return }
    db.value.lessons.push({ ...d, id: uid('l') } as Lesson); log('timetable.created', 'lesson', '', label)
  }
  function deleteLesson(id: string) {
    const l = lessonMap.value.get(id); if (!l) return
    if (db.value.attendance.some((a) => a.lessonId === id)) throw new Error('This lesson has attendance records. Move it to another time instead of deleting it.')
    db.value.lessons = db.value.lessons.filter((x) => x.id !== id)
    log('timetable.deleted', 'lesson', id, `${className(l.classId)} ${subjectName(l.subjectId)}`)
  }

  // ---------- attendance ----------
  function rosterFor(lessonId: string, date: string) {
    const l = lessonMap.value.get(lessonId)
    if (!l) return []
    return db.value.students
      .filter((s) => s.classId === l.classId && s.status === 'active' && s.subjectIds.includes(l.subjectId) && s.enrolmentDate <= date)
      .sort((a, b) => a.lastName.localeCompare(b.lastName) || a.firstName.localeCompare(b.firstName))
  }
  function registerFor(lessonId: string, date: string) { return db.value.attendance.filter((a) => a.lessonId === lessonId && a.date === date) }
  /** Upsert: one record per student + lesson + date (duplicates are impossible by construction). */
  function submitRegister(lessonId: string, date: string, marks: Record<string, AttendanceStatus>) {
    const a = actor()
    const l = lessonMap.value.get(lessonId)!
    let created = 0, updated = 0
    for (const [studentId, status] of Object.entries(marks)) {
      const existing = db.value.attendance.find((r) => r.lessonId === lessonId && r.date === date && r.studentId === studentId)
      if (existing) { if (existing.status !== status) { existing.status = status; existing.recordedAt = new Date().toISOString(); updated++ } }
      else { db.value.attendance.push({ id: uid('a'), studentId, lessonId, date, status, recordedBy: a.id, recordedAt: new Date().toISOString() }); created++ }
    }
    log(updated && !created ? 'attendance.corrected' : 'attendance.submitted', 'register', lessonId, `${className(l.classId)} ${subjectName(l.subjectId)} on ${date}: ${created} new, ${updated} changed`)
    return { created, updated }
  }

  // ---------- assessments ----------
  function addAssessments(base: { subjectId: string; type: AssessmentType; title: string; maxMarks: number; date: string; tutorId: string }, rows: { studentId: string; marks: number; comment: string }[]) {
    for (const r of rows) {
      if (r.marks < 0 || r.marks > base.maxMarks) throw new Error(`Marks for ${studentName(r.studentId)} must be between 0 and ${base.maxMarks}.`)
    }
    const term = termFor(base.date)
    for (const r of rows) db.value.assessments.push({ id: uid('x'), ...base, term, studentId: r.studentId, marks: r.marks, comment: r.comment })
    log('assessment.recorded', 'assessment', '', `${base.title} — ${subjectName(base.subjectId)} (${rows.length} students)`)
  }
  function updateAssessment(id: string, patch: Partial<Assessment>) {
    const x = db.value.assessments.find((a) => a.id === id); if (!x) return
    if (patch.marks !== undefined && (patch.marks < 0 || patch.marks > (patch.maxMarks ?? x.maxMarks))) throw new Error('Marks exceed the maximum for this assessment.')
    Object.assign(x, patch); log('assessment.updated', 'assessment', id, `${studentName(x.studentId)} ${x.title}`)
  }
  function deleteAssessment(id: string) {
    const x = db.value.assessments.find((a) => a.id === id); if (!x) return
    db.value.assessments = db.value.assessments.filter((a) => a.id !== id); log('assessment.deleted', 'assessment', id, `${studentName(x.studentId)} ${x.title}`)
  }

  // ---------- finance ----------
  function addCharge(c: Omit<Charge, 'id'>, audit = true) {
    const x = { ...c, id: uid('ch') }; db.value.charges.push(x)
    if (audit) log('charge.created', 'charge', x.id, `${studentName(c.studentId)}: ${c.description} ${kwacha(c.amount)}`)
    return x
  }
  function recordPayment(input: { studentId: string; amount: number; date: string; method: PaymentMethod; category: FeeCategory; term: string; externalRef?: string; notes?: string; network?: MobileNetwork }, verifyNow: boolean) {
    if (!(input.amount > 0)) throw new Error('Amount must be greater than zero.')
    if (input.method !== 'Cash' && !input.externalRef?.trim()) throw new Error(`Enter the ${input.method === 'Mobile Money' ? 'Mobile Money transaction ID' : 'bank reference'} so the payment can be verified.`)
    if (input.externalRef && db.value.payments.some((p) => p.externalRef?.toLowerCase() === input.externalRef!.trim().toLowerCase() && p.status !== 'rejected'))
      throw new Error('A payment with this transaction reference has already been recorded.')
    const a = actor()
    const p: Payment = {
      ...input, externalRef: input.externalRef?.trim() || undefined, id: uid('pm'), reference: `PAY-${input.date.slice(0, 4)}-${String(counter('payref')).padStart(4, '0')}`,
      recordedBy: a.name, recordedAt: new Date().toISOString(), status: 'pending', balanceAfter: 0, channel: 'office',
    }
    db.value.payments.push(p)
    p.balanceAfter = round2(balance(p.studentId) - p.amount)
    log('payment.recorded', 'payment', p.reference, `${studentName(p.studentId)} ${kwacha(p.amount)} via ${p.method} (awaiting verification)`)
    if (verifyNow) verifyPayment(p.id)
    return p
  }
  function verifyPayment(id: string) {
    const p = db.value.payments.find((x) => x.id === id)
    if (!p || p.status !== 'pending') return
    const a = actor()
    p.status = 'verified'; p.verifiedBy = a.name; p.verifiedAt = new Date().toISOString()
    p.receiptNo = `RCT-${p.date.slice(0, 4)}-${String(counter('receipt')).padStart(4, '0')}`
    p.balanceAfter = balance(p.studentId)
    log('payment.verified', 'payment', p.reference, `${studentName(p.studentId)} ${kwacha(p.amount)} — receipt ${p.receiptNo}`)
  }
  // ---------- online payments (parent portal → payment gateway) ----------
  /** Creates the payment and "sends" the PIN prompt. The gateway's callback (settleOnlinePayment) is what verifies it. */
  function startOnlinePayment(input: { studentId: string; amount: number; term: string; method: 'Mobile Money' | 'Card'; network?: MobileNetwork; phone?: string; fee: number }) {
    if (!(input.amount > 0)) throw new Error('Enter an amount greater than zero.')
    const a = actor()
    const p: Payment = {
      id: uid('pm'), reference: `PAY-${iso().slice(0, 4)}-${String(counter('payref')).padStart(4, '0')}`, studentId: input.studentId, amount: round2(input.amount),
      date: iso(), method: input.method, network: input.network, payerPhone: input.phone, category: 'Tuition', term: input.term, channel: 'online',
      gatewayRef: `GW-${Date.now().toString().slice(-8)}`, gatewayStatus: 'awaiting_customer', recordedBy: 'Parent portal', recordedAt: new Date().toISOString(),
      status: 'pending', balanceAfter: 0, notes: input.fee ? `Gateway fee ${kwacha(input.fee, { decimals: true })} paid by ${a.name}` : undefined,
    }
    db.value.payments.push(p)
    log('payment.online_started', 'payment', p.reference, `${studentName(p.studentId)} ${kwacha(p.amount)} via ${input.network ? NETWORK_LABEL[input.network] : 'bank card'} (${a.name})`)
    return p
  }
  function settleOnlinePayment(id: string, outcome: 'confirmed' | 'declined' | 'timed_out') {
    const p = db.value.payments.find((x) => x.id === id)
    if (!p || p.status !== 'pending' || p.channel !== 'online') return
    p.gatewayStatus = outcome
    if (outcome === 'confirmed') {
      p.status = 'verified'; p.verifiedBy = 'Payment gateway'; p.verifiedAt = new Date().toISOString()
      p.receiptNo = `RCT-${p.date.slice(0, 4)}-${String(counter('receipt')).padStart(4, '0')}`
      p.balanceAfter = balance(p.studentId)
      log('payment.gateway_confirmed', 'payment', p.reference, `${studentName(p.studentId)} ${kwacha(p.amount)} — receipt ${p.receiptNo}`)
    } else {
      p.status = 'rejected'; p.notes = [p.notes, outcome === 'declined' ? 'Declined on the phone' : 'No response before the prompt expired'].filter(Boolean).join(' · ')
      log('payment.gateway_failed', 'payment', p.reference, `${studentName(p.studentId)} ${kwacha(p.amount)} — ${outcome}`)
    }
  }
  /** Parent reports a bank deposit/transfer: needs the office to match it on the bank statement. */
  function reportBankTransfer(input: { studentId: string; amount: number; term: string; reference: string; date: string }) {
    if (!(input.amount > 0)) throw new Error('Enter an amount greater than zero.')
    if (!input.reference.trim()) throw new Error('Enter the bank reference from your deposit slip or banking app.')
    if (db.value.payments.some((p) => p.externalRef?.toLowerCase() === input.reference.trim().toLowerCase() && p.status !== 'rejected')) throw new Error('This reference has already been submitted.')
    const a = actor()
    const p: Payment = {
      id: uid('pm'), reference: `PAY-${iso().slice(0, 4)}-${String(counter('payref')).padStart(4, '0')}`, studentId: input.studentId, amount: round2(input.amount),
      date: input.date, method: 'Bank Transfer', category: 'Tuition', term: input.term, externalRef: input.reference.trim(), channel: 'online',
      recordedBy: `Parent portal (${a.name})`, recordedAt: new Date().toISOString(), status: 'pending', balanceAfter: 0,
    }
    db.value.payments.push(p)
    log('payment.bank_reported', 'payment', p.reference, `${studentName(p.studentId)} ${kwacha(p.amount)} — ref ${p.externalRef} (awaiting verification)`)
    return p
  }

  // ---------- growth: admissions, reminders, referrals ----------
  function addLead(l: Omit<Lead, 'id' | 'createdAt' | 'stage'> & { stage?: LeadStage }, viaPublicForm = false) {
    const x: Lead = { ...l, stage: l.stage ?? 'new', id: uid('ld'), createdAt: new Date().toISOString() }
    db.value.leads.unshift(x)
    if (viaPublicForm) db.value.audit.unshift({ id: uid('au'), at: x.createdAt, actorId: 'public', actorName: 'Online enquiry form', action: 'lead.created', entity: 'lead', entityId: x.id, detail: `${x.childName} (${gradeName(x.gradeId)}) — ${x.parentName}` })
    else log('lead.created', 'lead', x.id, `${x.childName} (${gradeName(x.gradeId)}) via ${x.source}`)
    return x
  }
  function updateLead(id: string, patch: Partial<Lead>) {
    const l = db.value.leads.find((x) => x.id === id); if (!l) return
    const from = l.stage; Object.assign(l, patch)
    log('lead.updated', 'lead', id, patch.stage && patch.stage !== from ? `${l.childName}: ${from} → ${patch.stage}` : `${l.childName} updated`)
  }
  function logReminder(parentId: string, channel: 'WhatsApp' | 'SMS', amount: number) {
    db.value.reminders.unshift({ id: uid('rm'), parentId, at: new Date().toISOString(), channel, amount })
    log('reminder.opened', 'parent', parentId, `${channel} fee reminder for ${parentMap.value.get(parentId)?.name} (${kwacha(amount)})`)
  }
  /** Credits the referring family once the referred child has enrolled. */
  function rewardReferral(leadId: string) {
    const l = db.value.leads.find((x) => x.id === leadId)
    if (!l || l.stage !== 'enrolled' || !l.referredByParentId || l.rewardApplied) throw new Error('This referral is not eligible for a reward.')
    const child = db.value.students.find((s) => s.parentId === l.referredByParentId && s.status === 'active')
    if (!child) throw new Error('The referring family has no active student to credit.')
    const amt = db.value.settings.referralReward
    addCharge({ studentId: child.id, category: 'Discount', term: db.value.settings.currentTerm, amount: -amt, description: `Referral reward — ${l.childName} enrolled`, issuedOn: iso(), dueDate: iso() }, false)
    l.rewardApplied = true
    log('referral.rewarded', 'lead', l.id, `${kwacha(amt)} credit to ${parentMap.value.get(l.referredByParentId)?.name} for referring ${l.childName}`)
  }

  function rejectPayment(id: string, reason: string) {
    const p = db.value.payments.find((x) => x.id === id)
    if (!p || p.status !== 'pending') return
    p.status = 'rejected'; p.notes = [p.notes, `Rejected: ${reason}`].filter(Boolean).join(' · ')
    log('payment.rejected', 'payment', p.reference, `${studentName(p.studentId)} ${kwacha(p.amount)} — ${reason}`)
  }
  function updateFee(id: string, amount: number) {
    const f = db.value.feeStructures.find((x) => x.id === id); if (!f) return
    if (!(amount >= 0)) throw new Error('Enter a valid amount.')
    const old = f.amount; f.amount = amount
    log('fee.updated', 'fee_structure', id, `${gradeName(f.gradeId)} ${f.category}: ${kwacha(old)} → ${kwacha(amount)} (applies to new charges)`)
  }
  /** Raise the current term's tuition (and exam fee) for active students who have not been billed yet. */
  function billTerm(term: string) {
    const t = db.value.settings.terms.find((x) => x.name === term); if (!t) return 0
    let n = 0
    for (const s of db.value.students.filter((x) => x.status === 'active')) {
      for (const f of db.value.feeStructures.filter((x) => x.gradeId === s.gradeId && x.frequency === 'per term')) {
        if (db.value.charges.some((c) => c.studentId === s.id && c.term === term && c.category === f.category)) continue
        addCharge({ studentId: s.id, category: f.category, term, amount: f.amount, description: `${term} ${f.category.toLowerCase()}`, issuedOn: iso(), dueDate: addDays(iso(), 14) }, false)
        n++
      }
    }
    log('billing.run', 'charge', term, `${n} charges raised for ${term}`)
    return n
  }

  // ---------- communication / materials / settings ----------
  function addAnnouncement(x: Omit<Announcement, 'id' | 'createdAt' | 'authorId' | 'authorName'>) {
    const a = actor()
    const ann: Announcement = { ...x, id: uid('an'), createdAt: new Date().toISOString(), authorId: a.id, authorName: a.name }
    db.value.announcements.unshift(ann); log('announcement.created', 'announcement', ann.id, `${ann.title} (${ann.audience})`)
    return ann
  }
  function deleteAnnouncement(id: string) { db.value.announcements = db.value.announcements.filter((a) => a.id !== id); log('announcement.deleted', 'announcement', id, '') }
  function addMaterial(m: Omit<Material, 'id' | 'createdAt'>) { const x = { ...m, id: uid('m'), createdAt: new Date().toISOString() }; db.value.materials.unshift(x); log('material.shared', 'material', x.id, x.title); return x }
  function deleteMaterial(id: string) { db.value.materials = db.value.materials.filter((m) => m.id !== id); log('material.deleted', 'material', id, '') }
  function updateSettings(patch: Partial<CentreSettings>) { Object.assign(db.value.settings, patch); log('settings.updated', 'settings', 'centre', Object.keys(patch).join(', ')) }

  return {
    db, reset,
    studentMap, tutorMap, parentMap, classMap, subjectMap, gradeMap, lessonMap,
    studentName, tutorName, subjectName, className, gradeName,
    billed, paid, pendingAmount, balance,
    addStudent, updateStudent, setStudentStatus, addParent, updateParent, addTutor, updateTutor,
    saveClass, saveSubject, addGrade, lessonConflicts, saveLesson, deleteLesson,
    rosterFor, registerFor, submitRegister, addAssessments, updateAssessment, deleteAssessment,
    addCharge, recordPayment, verifyPayment, rejectPayment, updateFee, billTerm,
    startOnlinePayment, settleOnlinePayment, reportBankTransfer, addLead, updateLead, logReminder, rewardReferral,
    addAnnouncement, deleteAnnouncement, addMaterial, deleteMaterial, updateSettings,
  }
})

export type Db = ReturnType<typeof useDb>
