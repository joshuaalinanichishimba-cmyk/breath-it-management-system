import re
from pydantic import BaseModel, ConfigDict, field_validator

ZM_PHONE = re.compile(r"^(\+?260|0)[79]\d{8}$")


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


def check_zm_phone(v: str | None) -> str | None:
    if v is None or v == "":
        return None
    if not ZM_PHONE.match(re.sub(r"[\s-]", "", v)):
        raise ValueError("Use a Zambian phone number, e.g. 0977 123 456")
    return v.strip()


class PhoneMixin(BaseModel):
    @field_validator("phone", "alt_phone", "alt_contact", check_fields=False)
    @classmethod
    def _phone(cls, v):
        return check_zm_phone(v)
