/** Role-based data scoping: every view filters through this so each role only sees what it may see. */
import { computed } from 'vue'
import { useAuth } from '@/stores/auth'
import { useDb } from '@/stores/db'

export function useScope() {
  const auth = useAuth()
  const store = useDb()
  const role = computed(() => auth.role)

  const tutorLessons = computed(() => (role.value === 'tutor' ? store.db.lessons.filter((l) => l.tutorId === auth.user?.linkedId) : []))
  const classIds = computed<Set<string>>(() => {
    switch (role.value) {
      case 'admin': return new Set(store.db.classes.map((c) => c.id))
      case 'tutor': return new Set(tutorLessons.value.map((l) => l.classId))
      case 'student': { const s = store.studentMap.get(auth.user?.linkedId ?? ''); return new Set(s ? [s.classId] : []) }
      case 'parent': return new Set(store.db.students.filter((s) => s.parentId === auth.user?.linkedId).map((s) => s.classId))
      default: return new Set()
    }
  })
  const students = computed(() => {
    switch (role.value) {
      case 'admin': return store.db.students
      case 'tutor': {
        const pairs = new Set(tutorLessons.value.map((l) => `${l.classId}|${l.subjectId}`))
        return store.db.students.filter((s) => s.subjectIds.some((sub) => pairs.has(`${s.classId}|${sub}`)))
      }
      case 'student': return store.db.students.filter((s) => s.id === auth.user?.linkedId)
      case 'parent': return store.db.students.filter((s) => s.parentId === auth.user?.linkedId)
      default: return []
    }
  })
  const studentIds = computed(() => new Set(students.value.map((s) => s.id)))
  /** Subjects a tutor teaches (admin: all) — used to limit assessment entry. */
  const teachableSubjectIds = computed(() => role.value === 'tutor' ? new Set(tutorLessons.value.map((l) => l.subjectId)) : new Set(store.db.subjects.map((s) => s.id)))
  const lessons = computed(() => {
    if (role.value === 'admin') return store.db.lessons
    if (role.value === 'tutor') return tutorLessons.value
    return store.db.lessons.filter((l) => classIds.value.has(l.classId))
  })

  return { role, classIds, students, studentIds, lessons, tutorLessons, teachableSubjectIds, tutorId: computed(() => (role.value === 'tutor' ? auth.user?.linkedId ?? '' : '')) }
}
