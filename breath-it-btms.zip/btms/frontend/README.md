# BTMS frontend

Vue 3 · Vite · TypeScript · Tailwind CSS · Vue Router · Pinia · Chart.js · jsPDF

```
npm install
npm run dev            # development server
npm run typecheck      # vue-tsc
npm run build          # static build for GitHub Pages → dist/
npm run build:single   # single self-contained index.html → dist-single/ (used for the hosted preview link)
npm run export-seed    # writes ../backend/app/seed_data/demo_seed.json so API and demo share identical data
```
Environment variables: see `.env.example`. See the root README for features and deployment.
