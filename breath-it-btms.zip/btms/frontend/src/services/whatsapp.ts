import { normalisePhone } from './payments'
/** Opens WhatsApp with a pre-written message (wa.me works on phones and WhatsApp Web; no provider account needed). */
export function waLink(phone: string | null, text: string): string {
  const n = phone ? normalisePhone(phone) : null
  const to = n ? `260${n.slice(1)}` : ''
  return `https://wa.me/${to}?text=${encodeURIComponent(text)}`
}
export function smsLink(phone: string, text: string): string {
  const n = normalisePhone(phone) ?? phone
  return `sms:${n}?body=${encodeURIComponent(text)}`
}
export function fillTemplate(tpl: string, vars: Record<string, string>): string {
  return tpl.replace(/\{(\w+)\}/g, (m, k) => vars[k] ?? m)
}
