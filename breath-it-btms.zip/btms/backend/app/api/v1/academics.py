from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session
from ...db import get_db
from ...deps import current_user, require_roles, client_ip
from ...models import AttendanceRecord, ClassGroup, Grade, Student, Subject, TimetableSlot, Tutor, User
from ...schemas.academics import ClassIn, ClassOut, GradeIn, GradeOut, SlotIn, SlotOut, SubjectIn, SubjectOut
from ...schemas.people import StudentOut
from ...services.access import visible_class_ids, visible_student_ids
from ...services.audit import audit
from ...services.timetable import conflicts, DAYS
from .people import student_out

router = APIRouter(tags=["academics"])
admin_only = require_roles("admin")


def subject_out(s: Subject) -> SubjectOut:
    o = SubjectOut.model_validate(s); o.grade_ids = [g.id for g in s.grades]; return o


@router.get("/grades", response_model=list[GradeOut])
def list_grades(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return list(db.scalars(select(Grade).order_by(Grade.sort_order)))


@router.post("/grades", response_model=GradeOut, status_code=201)
def create_grade(body: GradeIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    if db.scalar(select(Grade.id).where(Grade.name == body.name)):
        raise HTTPException(409, "That grade already exists.")
    g = Grade(**body.model_dump()); db.add(g); db.flush()
    audit(db, user, "grade.created", "grade", g.id, g.name, client_ip(request)); db.commit()
    return g


@router.get("/subjects", response_model=list[SubjectOut])
def list_subjects(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return [subject_out(s) for s in db.scalars(select(Subject).order_by(Subject.name))]


def _grades(db: Session, ids: list[str]) -> list[Grade]:
    gs = list(db.scalars(select(Grade).where(Grade.id.in_(ids))))
    if len(gs) != len(set(ids)):
        raise HTTPException(422, "One or more grades do not exist.")
    return gs


@router.post("/subjects", response_model=SubjectOut, status_code=201)
def create_subject(body: SubjectIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    code = body.code.strip().upper()
    if db.scalar(select(Subject.id).where(Subject.code == code)):
        raise HTTPException(409, "Subject code must be unique.")
    s = Subject(name=body.name.strip(), code=code, active=body.active); s.grades = _grades(db, body.grade_ids)
    db.add(s); db.flush(); audit(db, user, "subject.created", "subject", s.id, s.name, client_ip(request)); db.commit()
    return subject_out(s)


@router.put("/subjects/{subject_id}", response_model=SubjectOut)
def update_subject(subject_id: str, body: SubjectIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    s = db.get(Subject, subject_id)
    if not s:
        raise HTTPException(404, "Subject not found.")
    code = body.code.strip().upper()
    if db.scalar(select(Subject.id).where(Subject.code == code, Subject.id != subject_id)):
        raise HTTPException(409, "Subject code must be unique.")
    s.name, s.code, s.active, s.grades = body.name.strip(), code, body.active, _grades(db, body.grade_ids)
    audit(db, user, "subject.updated", "subject", s.id, s.name, client_ip(request)); db.commit()
    return subject_out(s)


@router.get("/classes", response_model=list[ClassOut])
def list_classes(user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(ClassGroup).order_by(ClassGroup.name)
    allowed = visible_class_ids(db, user)
    if allowed is not None:
        q = q.where(ClassGroup.id.in_(allowed or {""}))
    return list(db.scalars(q))


@router.post("/classes", response_model=ClassOut, status_code=201)
def create_class(body: ClassIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    if db.scalar(select(ClassGroup.id).where(ClassGroup.name == body.name.strip())):
        raise HTTPException(409, "A class with this name already exists.")
    c = ClassGroup(**body.model_dump()); db.add(c); db.flush()
    audit(db, user, "class.created", "class", c.id, c.name, client_ip(request)); db.commit()
    return c


@router.put("/classes/{class_id}", response_model=ClassOut)
def update_class(class_id: str, body: ClassIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    c = db.get(ClassGroup, class_id)
    if not c:
        raise HTTPException(404, "Class not found.")
    for k, v in body.model_dump().items():
        setattr(c, k, v)
    audit(db, user, "class.updated", "class", c.id, c.name, client_ip(request)); db.commit()
    return c


@router.get("/classes/{class_id}/students", response_model=list[StudentOut])
def class_students(class_id: str, user: User = Depends(require_roles("admin", "tutor")), db: Session = Depends(get_db)):
    allowed = visible_student_ids(db, user)
    q = select(Student).where(Student.class_id == class_id, Student.status == "active")
    if allowed is not None:
        q = q.where(Student.id.in_(allowed or {""}))
    return [student_out(s) for s in db.scalars(q.order_by(Student.last_name))]


# ---------------- timetable ----------------
@router.get("/timetable", response_model=list[SlotOut])
def timetable(class_id: str | None = None, tutor_id: str | None = None, user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(TimetableSlot)
    if user.role == "tutor":
        q = q.where(TimetableSlot.tutor_id == user.tutor_id)
    elif user.role != "admin":
        q = q.where(TimetableSlot.class_id.in_(visible_class_ids(db, user) or {""}))
    if class_id: q = q.where(TimetableSlot.class_id == class_id)
    if tutor_id: q = q.where(TimetableSlot.tutor_id == tutor_id)
    return list(db.scalars(q.order_by(TimetableSlot.day_of_week, TimetableSlot.start_time)))


def _validate_slot(db: Session, body: SlotIn, ignore_id: str | None = None):
    cls, subj, tutor = db.get(ClassGroup, body.class_id), db.get(Subject, body.subject_id), db.get(Tutor, body.tutor_id)
    if not cls or not subj or not tutor:
        raise HTTPException(422, "Class, subject or tutor not found.")
    if subj not in tutor.subjects:
        raise HTTPException(422, f"{tutor.first_name} {tutor.last_name} is not assigned to teach {subj.name}.")
    clash = conflicts(db, class_id=body.class_id, tutor_id=body.tutor_id, room=body.room, day=body.day_of_week, start=body.start_time, end=body.end_time, ignore_id=ignore_id)
    if clash:
        raise HTTPException(409, {"message": "This lesson clashes with the existing timetable.", "conflicts": clash})
    return cls, subj


@router.post("/timetable", response_model=SlotOut, status_code=201)
def create_slot(body: SlotIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    cls, subj = _validate_slot(db, body)
    s = TimetableSlot(**body.model_dump()); db.add(s); db.flush()
    audit(db, user, "timetable.created", "lesson", s.id, f"{cls.name} {subj.name} {DAYS[s.day_of_week]} {s.start_time:%H:%M}", client_ip(request)); db.commit()
    return s


@router.put("/timetable/{slot_id}", response_model=SlotOut)
def update_slot(slot_id: str, body: SlotIn, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    s = db.get(TimetableSlot, slot_id)
    if not s:
        raise HTTPException(404, "Lesson not found.")
    cls, subj = _validate_slot(db, body, ignore_id=slot_id)
    for k, v in body.model_dump().items():
        setattr(s, k, v)
    audit(db, user, "timetable.updated", "lesson", s.id, f"{cls.name} {subj.name} {DAYS[s.day_of_week]} {s.start_time:%H:%M}", client_ip(request)); db.commit()
    return s


@router.delete("/timetable/{slot_id}", status_code=204)
def delete_slot(slot_id: str, request: Request, user: User = Depends(admin_only), db: Session = Depends(get_db)):
    s = db.get(TimetableSlot, slot_id)
    if not s:
        raise HTTPException(404, "Lesson not found.")
    if db.scalar(select(AttendanceRecord.id).where(AttendanceRecord.slot_id == slot_id).limit(1)):
        raise HTTPException(409, "This lesson has attendance records. Move it to another time instead of deleting it.")
    db.delete(s); audit(db, user, "timetable.deleted", "lesson", slot_id, "", client_ip(request)); db.commit()
