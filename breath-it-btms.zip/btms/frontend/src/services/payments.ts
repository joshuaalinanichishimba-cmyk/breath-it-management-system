import type { MobileNetwork, Payment } from '@/types'

/** Zambian mobile number prefixes by network (numbers are not portable between networks). */
const PREFIX: Record<string, MobileNetwork> = { '97': 'Airtel', '77': 'Airtel', '96': 'MTN', '76': 'MTN', '95': 'Zamtel', '75': 'Zamtel' }

export function normalisePhone(raw: string): string | null {
  const d = raw.replace(/[^\d+]/g, '')
  const m = d.match(/^(?:\+?260|0)?([79]\d{8})$/)
  return m ? `0${m[1]}` : null
}
export function networkFromPhone(raw: string): MobileNetwork | null {
  const n = normalisePhone(raw)
  return n ? PREFIX[n.slice(1, 3)] ?? null : null
}
export const NETWORK_LABEL: Record<MobileNetwork, string> = { Airtel: 'Airtel Money', MTN: 'MTN MoMo', Zamtel: 'Zamtel Kwacha' }
export const NETWORK_PREFIXES: Record<MobileNetwork, string> = { Airtel: '097 / 077', MTN: '096 / 076', Zamtel: '095 / 075' }

export function methodLabel(p: Pick<Payment, 'method' | 'network'>): string {
  if (p.method === 'Mobile Money' && p.network) return NETWORK_LABEL[p.network]
  if (p.method === 'Card') return 'Bank card'
  return p.method
}
export function formatPhone(n: string): string {
  const x = normalisePhone(n) ?? n
  return x.length === 10 ? `${x.slice(0, 4)} ${x.slice(4, 7)} ${x.slice(7)}` : x
}
