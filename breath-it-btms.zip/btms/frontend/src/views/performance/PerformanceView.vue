<script setup lang="ts">
import { computed, reactive, ref, watch } from 'vue'
import { useRoute, RouterLink } from 'vue-router'
import type { ChartConfiguration } from 'chart.js'
import { Download, Pencil, Trash2 } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatTile from '@/components/ui/StatTile.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import Pager from '@/components/ui/Pager.vue'
import Modal from '@/components/ui/Modal.vue'
import ChartBox from '@/components/charts/ChartBox.vue'
import { tok } from '@/components/charts/palette'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { useScope } from '@/composables/useScope'
import { usePager } from '@/composables/usePager'
import type { Assessment, AssessmentType } from '@/types'
import { iso, fmtDate } from '@/services/dates'
import { pct, gradeBand } from '@/services/format'
import { average, pctOf, subjectAverages, progressSeries } from '@/services/analytics'
import { saveFile, toCsv } from '@/services/download'

const store = useDb(); const ui = useUi(); const scope = useScope(); const route = useRoute()
const tab = ref<'overview' | 'record' | 'marks'>(route.query.tab === 'record' ? 'record' : 'overview')
const isTutor = computed(() => scope.role.value === 'tutor')
const scopedMarks = computed(() => store.db.assessments.filter((a) => scope.studentIds.value.has(a.studentId) && (!isTutor.value || a.tutorId === scope.tutorId.value)))

// ---------- overview ----------
const term = ref(store.db.settings.currentTerm)
const classF = ref('')
const ov = computed(() => scopedMarks.value.filter((a) => a.term === term.value && (!classF.value || store.studentMap.get(a.studentId)?.classId === classF.value)))
const ovAvg = computed(() => average(ov.value.map(pctOf)))
const studentAvgs = computed(() => {
  const m = new Map<string, number[]>()
  for (const a of ov.value) { if (!m.has(a.studentId)) m.set(a.studentId, []); m.get(a.studentId)!.push(pctOf(a)) }
  return [...m.entries()].map(([id, v]) => ({ id, avg: average(v), n: v.length })).sort((a, b) => b.avg - a.avg)
})
const subjCfg = computed<ChartConfiguration>(() => {
  const s = subjectAverages(ov.value, store.subjectName)
  return { type: 'bar', data: { labels: s.map((x) => x.name), datasets: [{ label: 'Average %', data: s.map((x) => +x.avg.toFixed(1)), backgroundColor: tok('brand', 0.8), borderRadius: 3, maxBarThickness: 26 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + '%' } }, x: { grid: { display: false } } } } }
})
const progCfg = computed<ChartConfiguration>(() => {
  const p = progressSeries(scopedMarks.value.filter((a) => !classF.value || store.studentMap.get(a.studentId)?.classId === classF.value))
  return { type: 'line', data: { labels: p.map((x) => fmtDate(x.date, false)), datasets: [{ label: 'Average %', data: p.map((x) => +x.avg.toFixed(1)), borderColor: tok('ok'), backgroundColor: tok('ok', 0.12), fill: true, tension: 0.3, pointRadius: 3 }] },
    options: { plugins: { legend: { display: false }, tooltip: { callbacks: { title: (i) => p[i[0].dataIndex]?.title ?? '' } } }, scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + '%' } }, x: { grid: { display: false } } } } }
})

// ---------- record ----------
const types: AssessmentType[] = ['Test', 'Assignment', 'Mock Exam', 'End of Term Exam']
const rc = reactive({ classId: [...scope.classIds.value][0] ?? '', subjectId: '', type: 'Test' as AssessmentType, title: '', maxMarks: 50, date: iso() })
const subjectsForClass = computed(() => {
  const ids = new Set(scope.lessons.value.filter((l) => l.classId === rc.classId).map((l) => l.subjectId))
  return store.db.subjects.filter((s) => ids.has(s.id))
})
watch(() => rc.classId, () => { if (!subjectsForClass.value.some((s) => s.id === rc.subjectId)) rc.subjectId = subjectsForClass.value[0]?.id ?? '' }, { immediate: true })
watch(() => rc.type, (t) => { rc.maxMarks = t === 'Assignment' ? 20 : t === 'Test' ? 50 : 100 })
const recRoster = computed(() => store.db.students.filter((s) => s.classId === rc.classId && s.status === 'active' && s.subjectIds.includes(rc.subjectId)).sort((a, b) => a.lastName.localeCompare(b.lastName)))
const entries = reactive<Record<string, { marks: string | number; comment: string }>>({})
watch(recRoster, (r) => { for (const k of Object.keys(entries)) delete entries[k]; for (const s of r) entries[s.id] = { marks: '', comment: '' } }, { immediate: true })
const entryPct = (id: string) => { const m = parseFloat(String(entries[id]?.marks ?? '')); return Number.isFinite(m) && rc.maxMarks > 0 ? (m / rc.maxMarks) * 100 : NaN }
const quick = ['Excellent work — keep this standard.', 'Good effort. Revise the weaker sections.', 'Show all working clearly.', 'Needs more practice on basic concepts.']
const recErr = ref('')
function saveMarks() {
  recErr.value = ''
  if (!rc.subjectId) return (recErr.value = 'Choose a subject.')
  if (!rc.title.trim()) return (recErr.value = 'Give the assessment a title, e.g. “Term 3 test 3”.')
  if (!(rc.maxMarks > 0)) return (recErr.value = 'Maximum marks must be more than zero.')
  if (rc.date > iso()) return (recErr.value = 'The assessment date cannot be in the future.')
  const rows = recRoster.value.filter((s) => String(entries[s.id]?.marks ?? '').trim() !== '').map((s) => ({ studentId: s.id, marks: Number(entries[s.id].marks), comment: entries[s.id].comment.trim() }))
  if (!rows.length) return (recErr.value = 'Enter marks for at least one student. Leave a box empty if the student did not sit.')
  const bad = rows.find((r) => !Number.isFinite(r.marks) || r.marks < 0 || r.marks > rc.maxMarks)
  if (bad) return (recErr.value = `${store.studentName(bad.studentId)}: marks must be between 0 and ${rc.maxMarks}.`)
  const dup = rows.find((r) => store.db.assessments.some((a) => a.studentId === r.studentId && a.subjectId === rc.subjectId && a.date === rc.date && a.title.toLowerCase() === rc.title.trim().toLowerCase()))
  if (dup) return (recErr.value = `${store.studentName(dup.studentId)} already has marks for “${rc.title}” on this date. Edit them under All marks instead.`)
  try {
    const tutorId = isTutor.value ? scope.tutorId.value : (store.db.lessons.find((l) => l.classId === rc.classId && l.subjectId === rc.subjectId)?.tutorId ?? '')
    store.addAssessments({ subjectId: rc.subjectId, type: rc.type, title: rc.title.trim(), maxMarks: rc.maxMarks, date: rc.date, tutorId }, rows)
    ui.success('Marks saved', `${rows.length} students · ${store.subjectName(rc.subjectId)} · visible to parents now`)
    rc.title = ''; for (const s of recRoster.value) entries[s.id] = { marks: '', comment: '' }
  } catch (e) { recErr.value = (e as Error).message }
}

// ---------- all marks ----------
const mq = ref(''); const mClass = ref(''); const mSubject = ref(''); const mType = ref('')
const allMarks = computed(() => scopedMarks.value.filter((a) => {
  const s = store.studentMap.get(a.studentId)!
  return (!mClass.value || s.classId === mClass.value) && (!mSubject.value || a.subjectId === mSubject.value) && (!mType.value || a.type === mType.value) &&
    (!mq.value.trim() || `${s.firstName} ${s.lastName} ${a.title}`.toLowerCase().includes(mq.value.trim().toLowerCase()))
}).sort((a, b) => b.date.localeCompare(a.date) || store.studentName(a.studentId).localeCompare(store.studentName(b.studentId))))
const { page, pages, rows: pageRows, range } = usePager(allMarks, 15)
const editing = ref<Assessment | null>(null); const ed = reactive({ marks: 0, comment: '' })
function openEdit(a: Assessment) { editing.value = a; ed.marks = a.marks; ed.comment = a.comment }
function saveEdit() { try { store.updateAssessment(editing.value!.id, { marks: Number(ed.marks), comment: ed.comment }); ui.success('Mark updated'); editing.value = null } catch (e) { ui.error((e as Error).message) } }
async function remove(a: Assessment) {
  if (!(await ui.confirm({ title: 'Delete this mark?', body: `${store.studentName(a.studentId)} — ${a.title} (${store.subjectName(a.subjectId)}). Parents will no longer see it.`, confirmLabel: 'Delete', tone: 'danger' }))) return
  store.deleteAssessment(a.id); ui.success('Mark deleted')
}
async function exportCsv() {
  const body = allMarks.value.map((a) => { const s = store.studentMap.get(a.studentId)!; return [s.studentNo, `${s.firstName} ${s.lastName}`, store.className(s.classId), store.subjectName(a.subjectId), a.type, a.title, a.date, a.marks, a.maxMarks, pctOf(a).toFixed(1), a.comment] })
  try { if ((await saveFile(`marks-${iso()}.csv`, toCsv(['Student no.', 'Student', 'Class', 'Subject', 'Type', 'Assessment', 'Date', 'Marks', 'Max', '%', 'Comment'], body), 'text/csv')) === 'saved') ui.success('Marks exported') } catch (e) { ui.error('Export failed', (e as Error).message) }
}
const classOptions = computed(() => store.db.classes.filter((c) => scope.classIds.value.has(c.id)))
</script>

<template>
  <div>
    <PageHeader :title="isTutor ? 'Marks and comments' : 'Academic performance'" sub="Tests, assignments, mock and end-of-term examinations. Percentages are calculated automatically." />
    <div class="tabs mb-5" role="tablist">
      <button v-for="t in (['overview', 'record', 'marks'] as const)" :key="t" role="tab" :aria-selected="tab === t" :class="['tab', tab === t && 'tab-active']" @click="tab = t">{{ t === 'overview' ? 'Overview' : t === 'record' ? 'Enter marks' : 'All marks' }}</button>
    </div>

    <div v-if="tab === 'overview'">
      <div class="flex flex-wrap gap-2 mb-4">
        <select v-model="term" class="select w-auto" aria-label="Term"><option v-for="t in store.db.settings.terms" :key="t.name">{{ t.name }}</option></select>
        <select v-model="classF" class="select w-auto" aria-label="Class"><option value="">All classes</option><option v-for="c in classOptions" :key="c.id" :value="c.id">{{ c.name }}</option></select>
      </div>
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <StatTile label="Average mark" :value="ov.length ? pct(ovAvg) : '—'" :hint="`${ov.length} marks recorded`" />
        <StatTile label="Distinction (75%+)" :value="ov.filter((a) => pctOf(a) >= 75).length" tone="ok" />
        <StatTile label="Below pass (<40%)" :value="ov.filter((a) => pctOf(a) < 40).length" tone="bad" />
        <StatTile label="Students assessed" :value="studentAvgs.length" />
      </div>
      <div class="grid lg:grid-cols-2 gap-4 mb-4">
        <section class="card card-pad"><h2 class="h-section">Average by subject</h2><p class="sub mb-3">{{ term }}</p><ChartBox :config="subjCfg" label="Average mark by subject" /></section>
        <section class="card card-pad"><h2 class="h-section">Improvement over time</h2><p class="sub mb-3">Average at each sitting, all terms</p><ChartBox :config="progCfg" label="Average mark at each sitting" /></section>
      </div>
      <div class="grid lg:grid-cols-2 gap-4">
        <section class="card card-pad"><h2 class="h-section mb-3">Top performers</h2>
          <ol class="grid gap-2 text-[13px]"><li v-for="x in studentAvgs.slice(0, 5)" :key="x.id" class="flex justify-between"><RouterLink :to="`/students/${x.id}`" class="hover:underline">{{ store.studentName(x.id) }}</RouterLink><span class="badge badge-ok tnum">{{ pct(x.avg) }}</span></li></ol></section>
        <section class="card card-pad"><h2 class="h-section mb-3">Need extra support</h2>
          <ol class="grid gap-2 text-[13px]"><li v-for="x in [...studentAvgs].reverse().slice(0, 5)" :key="x.id" class="flex justify-between"><RouterLink :to="`/students/${x.id}`" class="hover:underline">{{ store.studentName(x.id) }}</RouterLink><span :class="['badge tnum', 'badge-' + gradeBand(x.avg).tone]">{{ pct(x.avg) }}</span></li></ol></section>
      </div>
    </div>

    <div v-else-if="tab === 'record'" class="card">
      <div class="p-4 sm:p-5 grid sm:grid-cols-3 lg:grid-cols-6 gap-3 border-b border-line">
        <div><label class="label" for="rc-c">Class</label><select id="rc-c" v-model="rc.classId" class="select"><option v-for="c in classOptions" :key="c.id" :value="c.id">{{ c.name }}</option></select></div>
        <div><label class="label" for="rc-s">Subject</label><select id="rc-s" v-model="rc.subjectId" class="select"><option v-for="s in subjectsForClass" :key="s.id" :value="s.id">{{ s.name }}</option></select></div>
        <div><label class="label" for="rc-t">Type</label><select id="rc-t" v-model="rc.type" class="select"><option v-for="t in types" :key="t">{{ t }}</option></select></div>
        <div><label class="label" for="rc-ti">Title</label><input id="rc-ti" v-model="rc.title" class="input" placeholder="e.g. Term 3 test 3" /></div>
        <div><label class="label" for="rc-m">Maximum marks</label><input id="rc-m" v-model.number="rc.maxMarks" type="number" min="1" class="input tnum" /></div>
        <div><label class="label" for="rc-d">Date</label><input id="rc-d" v-model="rc.date" type="date" :max="iso()" class="input" /></div>
      </div>
      <EmptyState v-if="!recRoster.length" title="No students take this subject in this class" />
      <div v-else class="table-wrap"><table class="tbl">
        <thead><tr><th>Student</th><th class="w-[120px]">Marks / {{ rc.maxMarks }}</th><th class="w-[90px]">%</th><th>Comment</th></tr></thead>
        <tbody><tr v-for="s in recRoster" :key="s.id">
          <td class="font-medium whitespace-nowrap">{{ s.firstName }} {{ s.lastName }}</td>
          <td><input v-model="entries[s.id].marks" type="number" min="0" :max="rc.maxMarks" step="0.5" class="input tnum h-8" :aria-label="`Marks for ${s.firstName}`" /></td>
          <td class="tnum"><span v-if="Number.isFinite(entryPct(s.id))" :class="['badge', entryPct(s.id) > 100 ? 'badge-bad' : 'badge-' + gradeBand(entryPct(s.id)).tone]">{{ pct(entryPct(s.id)) }}</span><span v-else class="text-faint">—</span></td>
          <td><input v-model="entries[s.id].comment" class="input h-8 min-w-[220px]" :list="`qc-${s.id}`" placeholder="Optional comment for the parent" /><datalist :id="`qc-${s.id}`"><option v-for="q in quick" :key="q" :value="q" /></datalist></td>
        </tr></tbody>
      </table></div>
      <div class="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-5 py-3 border-t border-line bg-sunken/40 rounded-b-lg">
        <p :class="['text-[13px]', recErr ? 'text-bad' : 'text-muted']">{{ recErr || 'Leave a box empty for a student who did not sit the assessment.' }}</p>
        <button class="btn btn-primary" :disabled="!recRoster.length" @click="saveMarks">Save marks</button>
      </div>
    </div>

    <div v-else class="card">
      <div class="p-3 sm:p-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-[1fr_150px_170px_150px_auto] border-b border-line">
        <input v-model="mq" class="input" placeholder="Search student or assessment" aria-label="Search marks" />
        <select v-model="mClass" class="select" aria-label="Class"><option value="">All classes</option><option v-for="c in classOptions" :key="c.id" :value="c.id">{{ c.name }}</option></select>
        <select v-model="mSubject" class="select" aria-label="Subject"><option value="">All subjects</option><option v-for="s in store.db.subjects.filter((x) => scope.teachableSubjectIds.value.has(x.id))" :key="s.id" :value="s.id">{{ s.name }}</option></select>
        <select v-model="mType" class="select" aria-label="Type"><option value="">All types</option><option v-for="t in types" :key="t">{{ t }}</option></select>
        <button class="btn btn-secondary" @click="exportCsv"><Download :size="15" />CSV</button>
      </div>
      <div v-if="allMarks.length" class="table-wrap"><table class="tbl">
        <thead><tr><th>Date</th><th>Student</th><th>Subject</th><th>Assessment</th><th>Marks</th><th>%</th><th>Comment</th><th></th></tr></thead>
        <tbody><tr v-for="a in pageRows" :key="a.id">
          <td class="whitespace-nowrap">{{ fmtDate(a.date) }}</td>
          <td class="whitespace-nowrap"><RouterLink :to="`/students/${a.studentId}`" class="hover:underline">{{ store.studentName(a.studentId) }}</RouterLink></td>
          <td class="whitespace-nowrap">{{ store.subjectName(a.subjectId) }}</td>
          <td class="whitespace-nowrap">{{ a.title }}<div class="text-[12px] text-muted">{{ a.type }}</div></td>
          <td class="tnum">{{ a.marks }}/{{ a.maxMarks }}</td>
          <td><span :class="['badge tnum', 'badge-' + gradeBand(pctOf(a)).tone]">{{ pct(pctOf(a)) }}</span></td>
          <td class="text-muted max-w-[260px] truncate" :title="a.comment">{{ a.comment }}</td>
          <td class="whitespace-nowrap text-right"><button class="icon-btn" aria-label="Edit mark" @click="openEdit(a)"><Pencil :size="15" /></button><button class="icon-btn" aria-label="Delete mark" @click="remove(a)"><Trash2 :size="15" /></button></td>
        </tr></tbody>
      </table></div>
      <EmptyState v-else title="No marks match these filters" />
      <Pager v-if="allMarks.length" v-model="page" :pages="pages" :range="range" />
    </div>

    <Modal :open="!!editing" title="Edit mark" :sub="editing ? `${store.studentName(editing.studentId)} · ${editing.title}` : ''" size="sm" @close="editing = null">
      <div v-if="editing" class="grid gap-4">
        <div><label class="label" for="ed-m">Marks (out of {{ editing.maxMarks }})</label><input id="ed-m" v-model.number="ed.marks" type="number" min="0" :max="editing.maxMarks" class="input tnum" />
          <p class="text-[12px] text-muted mt-1">= {{ pct((ed.marks / editing.maxMarks) * 100, 1) }}</p></div>
        <div><label class="label" for="ed-c">Comment</label><textarea id="ed-c" v-model="ed.comment" class="textarea" /></div>
      </div>
      <template #footer><button class="btn btn-secondary" @click="editing = null">Cancel</button><button class="btn btn-primary" @click="saveEdit">Save changes</button></template>
    </Modal>
  </div>
</template>
