from datetime import time
from sqlalchemy import Boolean, CheckConstraint, Column, ForeignKey, Integer, SmallInteger, String, Table, Time, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ..db import Base, new_id

grade_subjects = Table(
    "grade_subjects", Base.metadata,
    Column("grade_id", ForeignKey("grades.id", ondelete="CASCADE"), primary_key=True),
    Column("subject_id", ForeignKey("subjects.id", ondelete="CASCADE"), primary_key=True),
)


class Grade(Base):
    __tablename__ = "grades"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("g-"))
    name: Mapped[str] = mapped_column(String(60), unique=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    exam_level: Mapped[str] = mapped_column(String(120), default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    subjects: Mapped[list["Subject"]] = relationship(secondary=grade_subjects, back_populates="grades")


class Subject(Base):
    __tablename__ = "subjects"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("s-"))
    name: Mapped[str] = mapped_column(String(80))
    code: Mapped[str] = mapped_column(String(12), unique=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    grades: Mapped[list[Grade]] = relationship(secondary=grade_subjects, back_populates="subjects")


class ClassGroup(Base):
    __tablename__ = "classes"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("c-"))
    name: Mapped[str] = mapped_column(String(60), unique=True)
    grade_id: Mapped[str] = mapped_column(ForeignKey("grades.id"), index=True)
    class_tutor_id: Mapped[str | None] = mapped_column(ForeignKey("tutors.id", ondelete="SET NULL"), nullable=True)
    room: Mapped[str] = mapped_column(String(40))
    capacity: Mapped[int] = mapped_column(Integer, default=20)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (CheckConstraint("capacity > 0", name="ck_class_capacity"),)


class TimetableSlot(Base):
    """A weekly recurring lesson. Overlaps for the same tutor, room or class are rejected in services/timetable.py."""
    __tablename__ = "timetable_slots"
    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=lambda: new_id("l-"))
    class_id: Mapped[str] = mapped_column(ForeignKey("classes.id", ondelete="CASCADE"), index=True)
    subject_id: Mapped[str] = mapped_column(ForeignKey("subjects.id"), index=True)
    tutor_id: Mapped[str] = mapped_column(ForeignKey("tutors.id"), index=True)
    day_of_week: Mapped[int] = mapped_column(SmallInteger)  # 1 = Monday … 7 = Sunday
    start_time: Mapped[time] = mapped_column(Time)
    end_time: Mapped[time] = mapped_column(Time)
    room: Mapped[str] = mapped_column(String(40))
    __table_args__ = (
        CheckConstraint("day_of_week BETWEEN 1 AND 7", name="ck_slot_day"),
        CheckConstraint("end_time > start_time", name="ck_slot_times"),
        UniqueConstraint("tutor_id", "day_of_week", "start_time", name="uq_slot_tutor_start"),
        UniqueConstraint("room", "day_of_week", "start_time", name="uq_slot_room_start"),
    )
