"""
Outbound messaging (SMS / WhatsApp).

No provider is wired in yet, so `deliver` NEVER pretends to send: it reports 'not_configured'.
To go live, implement a Notifier for the chosen gateway (e.g. a Zambian bulk-SMS API or the
WhatsApp Business Cloud API), register it in `get_notifier`, and set SMS_PROVIDER / WHATSAPP_PROVIDER.
Sending should then happen from a background job, updating Announcement.sms_status per batch.
"""
from typing import Protocol
from ..core.config import get_settings


class Notifier(Protocol):
    def send(self, to: list[str], message: str) -> str: ...


def get_notifier(channel: str) -> Notifier | None:
    s = get_settings()
    provider = s.sms_provider if channel == "sms" else s.whatsapp_provider
    if not provider:
        return None
    raise NotImplementedError(f"{channel} provider '{provider}' is configured but no adapter has been written yet.")


def channel_status(channel: str, requested: bool) -> str:
    if not requested:
        return "not_requested"
    return "queued" if get_notifier(channel) else "not_configured"
