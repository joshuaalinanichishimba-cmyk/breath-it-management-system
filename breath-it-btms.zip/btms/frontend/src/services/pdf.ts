import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import type { DemoDatabase, Payment, Student } from '@/types'
import { fmtDate, fmtDateTime, iso, ageFrom } from './dates'
import { fullName, kwacha } from './format'
import { average, pctOf, attendanceRate } from './analytics'
import { gradeBand } from './format'

import { hexToRgb } from './brand'
import { methodLabel } from './payments'
let BRAND: [number, number, number] = [73, 58, 143]
const MUTED: [number, number, number] = [98, 94, 120]
/** Standard PDF fonts are Latin-1: normalise typographic characters. */
const t = (s: string) => s.replace(/[—–]/g, '-').replace(/[’‘]/g, "'").replace(/[“”]/g, '"').replace(/→/g, '->').replace(/·/g, '-').replace(/…/g, '...')

function header(doc: jsPDF, db: DemoDatabase, title: string, subtitle?: string) {
  const w = doc.internal.pageSize.getWidth()
  BRAND = hexToRgb(db.settings.brand?.primary ?? '#493a8f') ?? BRAND
  const logo = db.settings.brand?.logoDataUrl
  if (logo) { try { doc.addImage(logo, 'PNG', 14, 13, 11, 11) } catch { /* unsupported image: fall back to the mark */ } }
  else {
    doc.setFillColor(...BRAND); doc.roundedRect(14, 14, 10, 10, 2, 2, 'F')
    doc.setDrawColor(255, 255, 255); doc.setLineWidth(0.8)
    doc.line(16.5, 21, 21.5, 21); doc.line(17.5, 18.2, 20.5, 18.2)
  }
  doc.setTextColor(29, 26, 47); doc.setFont('helvetica', 'bold'); doc.setFontSize(13)
  doc.text(t(db.settings.centreName), 28, 19)
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...MUTED)
  doc.text(t(`${db.settings.address}  |  ${db.settings.phone}  |  ${db.settings.email}`), 28, 23.5)
  doc.setDrawColor(227, 224, 236); doc.setLineWidth(0.3); doc.line(14, 29, w - 14, 29)
  doc.setTextColor(29, 26, 47); doc.setFont('helvetica', 'bold'); doc.setFontSize(15)
  doc.text(t(title), 14, 40)
  if (subtitle) { doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5); doc.setTextColor(...MUTED); doc.text(t(subtitle), 14, 46) }
  return subtitle ? 52 : 46
}
function footer(doc: jsPDF) {
  const n = doc.getNumberOfPages()
  for (let i = 1; i <= n; i++) {
    doc.setPage(i)
    const h = doc.internal.pageSize.getHeight(), w = doc.internal.pageSize.getWidth()
    doc.setFontSize(7.5); doc.setTextColor(150, 146, 172); doc.setFont('helvetica', 'normal')
    doc.text(t(`Generated ${fmtDateTime(new Date().toISOString())} by Breath It BTMS - DEMONSTRATION DATA, not a real record`), 14, h - 8)
    doc.text(`Page ${i} of ${n}`, w - 14, h - 8, { align: 'right' })
  }
}
const lastY = (doc: jsPDF) => (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY

export function receiptPdf(db: DemoDatabase, p: Payment): Blob {
  const doc = new jsPDF({ unit: 'mm', format: 'a5' })
  const s = db.students.find((x) => x.id === p.studentId)!
  const parent = db.parents.find((x) => x.id === s.parentId)
  const y = header(doc, db, 'Payment receipt', `${p.receiptNo}  |  ${fmtDate(p.date)}`)
  autoTable(doc, {
    startY: y, theme: 'plain', styles: { fontSize: 9.5, cellPadding: 1.6 }, columnStyles: { 0: { textColor: MUTED, cellWidth: 38 } },
    body: [
      ['Received from', t(parent ? `${parent.name} (${parent.relationship})` : '-')],
      ['Student', t(`${fullName(s)} - ${s.studentNo}`)],
      ['Grade / class', t(`${db.grades.find((g) => g.id === s.gradeId)?.name} - ${db.classes.find((c) => c.id === s.classId)?.name}`)],
      ['For', t(`${p.category} - ${p.term}`)],
      ['Payment method', t(methodLabel(p) + (p.payerPhone ? ` ${p.payerPhone}` : '') + (p.externalRef ? ` (ref ${p.externalRef})` : '') + (p.gatewayRef ? ` (gateway ref ${p.gatewayRef})` : ''))],
      ['Payment reference', p.reference],
    ],
  })
  const y2 = lastY(doc) + 4
  doc.setFillColor(240, 238, 246); doc.roundedRect(14, y2, doc.internal.pageSize.getWidth() - 28, 22, 2, 2, 'F')
  doc.setFontSize(9); doc.setTextColor(...MUTED); doc.text('Amount received', 18, y2 + 7)
  doc.text('Balance after this payment', 80, y2 + 7)
  doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.setTextColor(29, 26, 47)
  doc.text(kwacha(p.amount, { decimals: true }), 18, y2 + 16)
  doc.text(kwacha(p.balanceAfter, { decimals: true }), 80, y2 + 16)
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...MUTED)
  doc.text(t(`Recorded by ${p.recordedBy}; verified by ${p.verifiedBy ?? '-'} on ${fmtDateTime(p.verifiedAt)}.`), 14, y2 + 30)
  doc.text(t(db.settings.receiptFooter), 14, y2 + 35, { maxWidth: doc.internal.pageSize.getWidth() - 28 })
  footer(doc)
  return doc.output('blob')
}

export function reportCardPdf(db: DemoDatabase, s: Student, term: string): Blob {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' })
  const grade = db.grades.find((g) => g.id === s.gradeId)?.name ?? ''
  const y = header(doc, db, 'Academic progress report', `${term}  |  issued ${fmtDate(iso())}`)
  const att = db.attendance.filter((a) => a.studentId === s.id)
  autoTable(doc, {
    startY: y, theme: 'plain', styles: { fontSize: 9.5, cellPadding: 1.4 },
    body: [
      ['Student', t(`${fullName(s)} (${s.studentNo})`), 'Grade / class', t(`${grade} - ${db.classes.find((c) => c.id === s.classId)?.name}`)],
      ['Age', String(ageFrom(s.dob)), 'Attendance (all lessons)', att.length ? `${attendanceRate(att).toFixed(0)}% of ${att.length} lessons` : 'No records'],
    ],
    columnStyles: { 0: { textColor: MUTED, cellWidth: 26 }, 2: { textColor: MUTED, cellWidth: 42 } },
  })
  const rows = s.subjectIds.map((sub) => {
    const all = db.assessments.filter((a) => a.studentId === s.id && a.subjectId === sub && a.term === term).sort((a, b) => a.date.localeCompare(b.date))
    const avg = average(all.map(pctOf))
    const latest = all[all.length - 1]
    return [
      t(db.subjects.find((x) => x.id === sub)?.name ?? sub),
      all.map((a) => `${a.title}: ${a.marks}/${a.maxMarks}`).join('\n') || 'No assessments',
      Number.isFinite(avg) ? `${avg.toFixed(0)}%` : '-',
      Number.isFinite(avg) ? gradeBand(avg).label : '-',
      t(latest?.comment ?? ''),
    ]
  })
  autoTable(doc, {
    startY: lastY(doc) + 6,
    head: [['Subject', 'Assessments', 'Average', 'Band', 'Tutor comment']],
    body: rows,
    headStyles: { fillColor: BRAND, fontSize: 9 },
    styles: { fontSize: 8.6, cellPadding: 2, valign: 'top' },
    columnStyles: { 0: { cellWidth: 34, fontStyle: 'bold' }, 1: { cellWidth: 52 }, 2: { cellWidth: 18 }, 3: { cellWidth: 22 } },
  })
  const all = db.assessments.filter((a) => a.studentId === s.id && a.term === term)
  const overall = average(all.map(pctOf))
  doc.setFontSize(10); doc.setTextColor(29, 26, 47); doc.setFont('helvetica', 'bold')
  doc.text(`Overall average for ${t(term)}: ${Number.isFinite(overall) ? overall.toFixed(1) + '%' : '-'}`, 14, lastY(doc) + 10)
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...MUTED)
  doc.text('Bands are indicative (Distinction 75%+, Merit 60%+, Credit 50%+, Pass 40%+) and should be confirmed with management.', 14, lastY(doc) + 16)
  footer(doc)
  return doc.output('blob')
}

export function tablePdf(db: DemoDatabase, title: string, subtitle: string, head: string[], body: (string | number)[][], summary: [string, string][] = [], landscape = false): Blob {
  const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: landscape ? 'landscape' : 'portrait' })
  let y = header(doc, db, title, subtitle)
  if (summary.length) {
    autoTable(doc, { startY: y, theme: 'plain', styles: { fontSize: 9.5, cellPadding: 1.2 }, body: summary.map(([k, v]) => [t(k), t(v)]), columnStyles: { 0: { textColor: MUTED, cellWidth: 60 }, 1: { fontStyle: 'bold' } } })
    y = lastY(doc) + 4
  }
  autoTable(doc, {
    startY: y, head: [head.map(t)], body: body.map((r) => r.map((c) => t(String(c)))),
    headStyles: { fillColor: BRAND, fontSize: 8.6 }, styles: { fontSize: 8.4, cellPadding: 1.8 }, alternateRowStyles: { fillColor: [247, 246, 251] },
  })
  footer(doc)
  return doc.output('blob')
}
