import type { Component } from 'vue'
import {
  LayoutDashboard, Users, Contact, GraduationCap, School, BookOpen, CalendarDays, ClipboardCheck, TrendingUp, Wallet,
  Megaphone, FileText, Settings, FolderOpen, Receipt, Rocket, Inbox,
} from 'lucide-vue-next'
import type { Role } from '@/types'

export interface NavItem { to: string; label: string; icon: Component }
export interface NavGroup { label?: string; items: NavItem[] }

export function navFor(role: Role, opts: { showFees: boolean }): NavGroup[] {
  switch (role) {
    case 'admin': return [
      { items: [{ to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard }, { to: '/growth', label: 'Growth', icon: Rocket }] },
      { label: 'Admissions', items: [{ to: '/admissions', label: 'Enquiries', icon: Inbox }] },
      { label: 'People', items: [
        { to: '/students', label: 'Students', icon: Users },
        { to: '/parents', label: 'Parents', icon: Contact },
        { to: '/tutors', label: 'Tutors', icon: GraduationCap },
      ] },
      { label: 'Teaching', items: [
        { to: '/classes', label: 'Classes', icon: School },
        { to: '/subjects', label: 'Grades & subjects', icon: BookOpen },
        { to: '/timetable', label: 'Timetable', icon: CalendarDays },
        { to: '/attendance', label: 'Attendance', icon: ClipboardCheck },
        { to: '/performance', label: 'Performance', icon: TrendingUp },
      ] },
      { label: 'Office', items: [
        { to: '/finance', label: 'Finance', icon: Wallet },
        { to: '/announcements', label: 'Announcements', icon: Megaphone },
        { to: '/reports', label: 'Reports', icon: FileText },
        { to: '/settings', label: 'Settings', icon: Settings },
      ] },
    ]
    case 'tutor': return [
      { items: [
        { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { to: '/classes', label: 'My classes', icon: School },
        { to: '/timetable', label: 'Timetable', icon: CalendarDays },
        { to: '/attendance', label: 'Attendance', icon: ClipboardCheck },
        { to: '/performance', label: 'Marks & comments', icon: TrendingUp },
        { to: '/students', label: 'My students', icon: Users },
        { to: '/materials', label: 'Learning materials', icon: FolderOpen },
        { to: '/announcements', label: 'Announcements', icon: Megaphone },
      ] },
    ]
    case 'student': return [
      { items: [
        { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { to: '/timetable', label: 'Timetable', icon: CalendarDays },
        { to: '/my/results', label: 'Results', icon: TrendingUp },
        { to: '/my/attendance', label: 'Attendance', icon: ClipboardCheck },
        { to: '/materials', label: 'Learning materials', icon: FolderOpen },
        ...(opts.showFees ? [{ to: '/my/payments', label: 'Payments', icon: Receipt }] : []),
        { to: '/announcements', label: 'Announcements', icon: Megaphone },
      ] },
    ]
    case 'parent': return [
      { items: [
        { to: '/dashboard', label: 'Overview', icon: LayoutDashboard },
        { to: '/my/results', label: 'Results & comments', icon: TrendingUp },
        { to: '/my/attendance', label: 'Attendance', icon: ClipboardCheck },
        { to: '/my/payments', label: 'Fees & receipts', icon: Receipt },
        { to: '/timetable', label: 'Timetable', icon: CalendarDays },
        { to: '/announcements', label: 'Announcements', icon: Megaphone },
      ] },
    ]
  }
}
