import type { Assessment, AttendanceRecord, DemoDatabase } from '@/types'
import { lastMonths, monthKey, addDays, iso } from './dates'

export const pctOf = (a: Assessment) => (a.maxMarks ? (a.marks / a.maxMarks) * 100 : 0)

export function attendanceRate(records: AttendanceRecord[]): number {
  if (!records.length) return NaN
  const attended = records.filter((r) => r.status !== 'absent').length
  return (attended / records.length) * 100
}
export function attendanceCounts(records: AttendanceRecord[]) {
  return {
    present: records.filter((r) => r.status === 'present').length,
    late: records.filter((r) => r.status === 'late').length,
    absent: records.filter((r) => r.status === 'absent').length,
    total: records.length,
  }
}
export function average(nums: number[]): number { return nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : NaN }

export function monthlyRevenue(db: DemoDatabase, months = 11, to = iso()) {
  const keys = lastMonths(months, to)
  const sums = Object.fromEntries(keys.map((k) => [k, 0]))
  for (const p of db.payments) if (p.status === 'verified' && monthKey(p.date) in sums) sums[monthKey(p.date)] += p.amount
  return { keys, values: keys.map((k) => sums[k]) }
}
export function enrolmentTrend(db: DemoDatabase, months = 12, to = iso()) {
  const keys = lastMonths(months, to)
  const added = keys.map((k) => db.students.filter((s) => monthKey(s.enrolmentDate) === k).length)
  const cumulative = keys.map((k) => db.students.filter((s) => monthKey(s.enrolmentDate) <= k).length)
  return { keys, added, cumulative }
}
/** Weekly attendance rate for the last n weeks (Mon–Sat). */
export function weeklyAttendance(records: AttendanceRecord[], weeks = 6, to = iso()) {
  const out: { label: string; rate: number }[] = []
  for (let i = weeks - 1; i >= 0; i--) {
    const end = addDays(to, -7 * i)
    const start = addDays(end, -6)
    const r = records.filter((x) => x.date >= start && x.date <= end)
    out.push({ label: start.slice(5).replace('-', '/'), rate: attendanceRate(r) })
  }
  return out
}
/** Average percentage per subject. */
export function subjectAverages(assessments: Assessment[], subjectName: (id: string) => string) {
  const m = new Map<string, number[]>()
  for (const a of assessments) { if (!m.has(a.subjectId)) m.set(a.subjectId, []); m.get(a.subjectId)!.push(pctOf(a)) }
  return [...m.entries()].map(([id, v]) => ({ id, name: subjectName(id), avg: average(v), count: v.length })).sort((a, b) => b.avg - a.avg)
}
/** Group assessments by sitting (title + date) in date order and average them. */
export function progressSeries(assessments: Assessment[]) {
  const m = new Map<string, { date: string; title: string; vals: number[] }>()
  for (const a of assessments) {
    const k = `${a.date}|${a.title}`
    if (!m.has(k)) m.set(k, { date: a.date, title: a.title, vals: [] })
    m.get(k)!.vals.push(pctOf(a))
  }
  return [...m.values()].sort((a, b) => a.date.localeCompare(b.date)).map((x) => ({ date: x.date, title: x.title, avg: average(x.vals) }))
}
