<script setup lang="ts">
import { RouterLink } from 'vue-router'
import PageHeader from '@/components/ui/PageHeader.vue'
import LearnerSummary from '@/components/domain/LearnerSummary.vue'
import { usePortalStudent } from '@/composables/usePortalStudent'
import { useAnnouncements } from '@/composables/useAnnouncements'
import { useDb } from '@/stores/db'
import { fmtDate } from '@/services/dates'
import { greeting, todayLabel } from './greeting'
const { student } = usePortalStudent(); const anns = useAnnouncements(); const store = useDb()
</script>
<template>
  <div v-if="student">
    <PageHeader :title="greeting(student.firstName)" :sub="`${todayLabel()} · ${store.gradeName(student.gradeId)}, ${store.className(student.classId)} · ${student.studentNo}`" />
    <LearnerSummary :student="student" />
    <div class="grid lg:grid-cols-2 gap-4 mt-4">
      <section class="card card-pad">
        <div class="flex items-baseline justify-between mb-2"><h2 class="h-section">Announcements</h2><RouterLink to="/announcements" class="text-[12.5px] text-brand hover:underline">All</RouterLink></div>
        <article v-for="a in anns.slice(0, 3)" :key="a.id" class="py-2.5 border-b border-line last:border-0">
          <div class="flex items-center gap-2"><span class="text-[13px] font-medium">{{ a.title }}</span><span v-if="a.priority === 'important'" class="badge badge-bad">Important</span></div>
          <p class="text-[12.5px] text-muted mt-0.5">{{ a.body }}</p>
        </article>
      </section>
      <section class="card card-pad">
        <div class="flex items-baseline justify-between mb-2"><h2 class="h-section">New learning materials</h2><RouterLink to="/materials" class="text-[12.5px] text-brand hover:underline">All</RouterLink></div>
        <div v-for="m in store.db.materials.filter((m) => m.classId === student!.classId && student!.subjectIds.includes(m.subjectId)).slice(0, 4)" :key="m.id" class="py-2.5 border-b border-line last:border-0">
          <div class="text-[13px] font-medium">{{ m.title }}</div>
          <div class="text-[12px] text-muted">{{ store.subjectName(m.subjectId) }} · {{ m.kind }} · {{ fmtDate(m.createdAt.slice(0, 10)) }}</div>
        </div>
      </section>
    </div>
  </div>
</template>
