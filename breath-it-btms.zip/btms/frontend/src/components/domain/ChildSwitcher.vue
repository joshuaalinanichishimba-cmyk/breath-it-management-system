<script setup lang="ts">
import { usePortalStudent } from '@/composables/usePortalStudent'
import { useUi } from '@/stores/ui'
import { useDb } from '@/stores/db'
import Avatar from '@/components/ui/Avatar.vue'
const { children, student, isParent } = usePortalStudent()
const ui = useUi(); const store = useDb()
</script>
<template>
  <div v-if="isParent && children.length > 1" class="flex flex-wrap gap-2 mb-5" role="tablist" aria-label="Choose child">
    <button v-for="c in children" :key="c.id" role="tab" :aria-selected="student?.id === c.id"
      :class="['flex items-center gap-2 pl-1.5 pr-3 h-10 rounded-full border text-[13px] transition-colors', student?.id === c.id ? 'border-brand bg-brand-soft text-ink' : 'border-line bg-surface text-muted hover:text-ink']"
      @click="ui.selectedChildId = c.id">
      <Avatar :name="`${c.firstName} ${c.lastName}`" :size="28" />
      <span class="font-medium">{{ c.firstName }}</span>
      <span class="text-[12px] text-muted">{{ store.gradeName(c.gradeId) }}</span>
    </button>
  </div>
</template>
