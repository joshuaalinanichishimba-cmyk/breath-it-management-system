from datetime import date
from typing import Literal
from pydantic import BaseModel, Field, field_validator, model_validator
from .common import ORM, PhoneMixin

StudentStatus = Literal["active", "inactive", "suspended", "completed"]


class ParentIn(PhoneMixin):
    name: str = Field(min_length=2, max_length=120)
    relationship_to_student: Literal["Mother", "Father", "Guardian", "Aunt", "Uncle", "Grandparent"] = "Guardian"
    phone: str
    alt_phone: str | None = None
    email: str | None = Field(default=None, pattern=r"^\S+@\S+\.\S+$")
    address: str = Field(min_length=2, max_length=200)
    occupation: str | None = None
    portal_access: bool = True


class ParentUpdate(PhoneMixin):
    name: str | None = None
    phone: str | None = None
    alt_phone: str | None = None
    email: str | None = None
    address: str | None = None
    occupation: str | None = None
    portal_access: bool | None = None


class ParentOut(ORM):
    id: str
    name: str
    relationship_to_student: str
    phone: str
    alt_phone: str | None
    email: str | None
    address: str
    occupation: str | None
    portal_access: bool


class TutorIn(PhoneMixin):
    first_name: str = Field(min_length=1, max_length=60)
    last_name: str = Field(min_length=1, max_length=60)
    gender: Literal["Female", "Male"]
    phone: str
    email: str = Field(pattern=r"^\S+@\S+\.\S+$")
    qualification: str = ""
    hire_date: date
    subject_ids: list[str] = Field(min_length=1)


class TutorUpdate(PhoneMixin):
    first_name: str | None = None
    last_name: str | None = None
    phone: str | None = None
    email: str | None = None
    qualification: str | None = None
    status: Literal["active", "on_leave", "inactive"] | None = None
    subject_ids: list[str] | None = None


class TutorOut(ORM):
    id: str
    staff_no: str
    first_name: str
    last_name: str
    gender: str
    phone: str
    email: str
    qualification: str
    hire_date: date
    status: str
    subject_ids: list[str] = []


class StudentIn(PhoneMixin):
    first_name: str = Field(min_length=1, max_length=60)
    last_name: str = Field(min_length=1, max_length=60)
    date_of_birth: date
    gender: Literal["Female", "Male"]
    grade_id: str
    class_id: str
    parent_id: str | None = None
    new_parent: ParentIn | None = None
    alt_contact: str | None = None
    address: str = Field(min_length=2, max_length=200)
    enrolment_date: date
    subject_ids: list[str] = Field(min_length=1)
    charge_fees: bool = True

    @field_validator("date_of_birth")
    @classmethod
    def _dob(cls, v: date) -> date:
        if v >= date.today():
            raise ValueError("Date of birth must be in the past")
        return v

    @model_validator(mode="after")
    def _parent(self):
        if not self.parent_id and not self.new_parent:
            raise ValueError("Link an existing parent (parent_id) or provide new_parent")
        return self


class StudentUpdate(PhoneMixin):
    first_name: str | None = None
    last_name: str | None = None
    date_of_birth: date | None = None
    gender: Literal["Female", "Male"] | None = None
    grade_id: str | None = None
    class_id: str | None = None
    alt_contact: str | None = None
    address: str | None = None
    subject_ids: list[str] | None = None
    status: StudentStatus | None = None
    notes: str | None = None


class StudentOut(ORM):
    id: str
    student_no: str
    first_name: str
    last_name: str
    date_of_birth: date
    gender: str
    grade_id: str
    class_id: str
    parent_id: str
    alt_contact: str | None
    address: str
    enrolment_date: date
    status: str
    notes: str | None
    subject_ids: list[str] = []


class EnrolmentOut(ORM):
    id: str
    event_date: date
    action: str
    detail: str
