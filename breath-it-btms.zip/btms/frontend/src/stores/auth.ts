import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import type { Role, SessionUser } from '@/types'
import { DEMO_MODE, SESSION_KEY } from '@/config'
import { demoAuthenticate } from '@/services/demo/accounts'
import { endpoints } from '@/services/api'

interface Session { user: SessionUser; token?: string; mode: 'demo' | 'api' }

function load(): Session | null {
  try { return JSON.parse(sessionStorage.getItem(SESSION_KEY) ?? 'null') } catch { return null }
}

export const useAuth = defineStore('auth', () => {
  const session = ref<Session | null>(load())
  const user = computed(() => session.value?.user ?? null)
  const role = computed<Role | null>(() => user.value?.role ?? null)

  function persist() {
    try {
      if (session.value) sessionStorage.setItem(SESSION_KEY, JSON.stringify(session.value))
      else sessionStorage.removeItem(SESSION_KEY)
    } catch { /* storage unavailable: session lives in memory only */ }
  }

  async function login(email: string, password: string): Promise<SessionUser> {
    if (DEMO_MODE) {
      const u = demoAuthenticate(email, password)
      if (!u) throw new Error('Email or password is incorrect.')
      session.value = { user: u, mode: 'demo' }
    } else {
      const res = await endpoints.login(email, password)
      session.value = {
        token: res.access_token, mode: 'api',
        user: { id: res.user.id, name: res.user.name, email: res.user.email, role: res.user.role as Role, linkedId: res.user.linked_id },
      }
    }
    persist()
    return session.value.user
  }
  function logout() { session.value = null; persist() }

  return { session, user, role, login, logout }
})
