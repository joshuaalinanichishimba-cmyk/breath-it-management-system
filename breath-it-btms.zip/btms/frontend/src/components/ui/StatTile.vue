<script setup lang="ts">
defineProps<{ label: string; value: string | number; hint?: string; tone?: 'ok' | 'warn' | 'bad' | 'info' | 'brand' }>()
const tones = { ok: 'text-ok', warn: 'text-warn', bad: 'text-bad', info: 'text-info', brand: 'text-brand' }
</script>
<template>
  <div class="card px-4 py-3.5">
    <div class="text-[12.5px] text-muted">{{ label }}</div>
    <div :class="['mt-1 text-[22px] font-semibold tnum tracking-[-0.01em]', tone ? tones[tone] : '']">{{ value }}</div>
    <div v-if="hint || $slots.default" class="text-[12px] text-muted mt-0.5"><slot>{{ hint }}</slot></div>
  </div>
</template>
