<script setup lang="ts">
import { computed } from 'vue'
const props = defineProps<{ status: string }>()
const map: Record<string, [string, string]> = {
  active: ['badge-ok', 'Active'], inactive: ['badge-mute', 'Inactive'], suspended: ['badge-bad', 'Suspended'], completed: ['badge-info', 'Completed'],
  on_leave: ['badge-warn', 'On leave'], verified: ['badge-ok', 'Verified'], pending: ['badge-warn', 'Awaiting verification'], rejected: ['badge-bad', 'Rejected'],
  present: ['badge-ok', 'Present'], absent: ['badge-bad', 'Absent'], late: ['badge-warn', 'Late'],
  paid: ['badge-ok', 'Paid'], partial: ['badge-warn', 'Part paid'], unpaid: ['badge-bad', 'Unpaid'], important: ['badge-bad', 'Important'],
}
const v = computed(() => map[props.status] ?? ['badge-mute', props.status])
</script>
<template><span :class="['badge', v[0]]">{{ v[1] }}</span></template>
