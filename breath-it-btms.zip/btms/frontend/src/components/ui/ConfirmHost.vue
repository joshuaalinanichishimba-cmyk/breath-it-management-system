<script setup lang="ts">
import { useUi } from '@/stores/ui'
import Modal from './Modal.vue'
const ui = useUi()
</script>
<template>
  <Modal :open="!!ui.confirmState" :title="ui.confirmState?.title ?? ''" size="sm" @close="ui.settleConfirm(false)">
    <p class="text-[13.5px] text-muted">{{ ui.confirmState?.body }}</p>
    <template #footer>
      <button class="btn btn-secondary" @click="ui.settleConfirm(false)">Cancel</button>
      <button :class="['btn', ui.confirmState?.tone === 'danger' ? 'btn-danger' : 'btn-primary']" @click="ui.settleConfirm(true)">{{ ui.confirmState?.confirmLabel }}</button>
    </template>
  </Modal>
</template>
