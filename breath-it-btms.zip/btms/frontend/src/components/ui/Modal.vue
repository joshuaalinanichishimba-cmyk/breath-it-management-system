<script setup lang="ts">
import { onBeforeUnmount, watch } from 'vue'
import { X } from 'lucide-vue-next'
const props = withDefaults(defineProps<{ open: boolean; title: string; sub?: string; size?: 'sm' | 'md' | 'lg' | 'xl' }>(), { size: 'md' })
const emit = defineEmits<{ close: [] }>()
const widths = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' }
function onKey(e: KeyboardEvent) { if (e.key === 'Escape' && props.open) emit('close') }
watch(() => props.open, (v) => { if (v) window.addEventListener('keydown', onKey); else window.removeEventListener('keydown', onKey) }, { immediate: true })
onBeforeUnmount(() => window.removeEventListener('keydown', onKey))
</script>
<template>
  <Teleport to="body">
    <div v-if="open" class="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:p-6">
      <div class="absolute inset-0 bg-ink/40" @click="emit('close')" />
      <div role="dialog" aria-modal="true" :aria-label="title"
        :class="['relative w-full bg-surface border border-line shadow-xl flex flex-col max-h-[92%] rounded-t-xl sm:rounded-xl', widths[size]]">
        <header class="flex items-start justify-between gap-4 px-5 pt-4 pb-3 border-b border-line">
          <div>
            <h2 class="text-[15.5px] font-semibold">{{ title }}</h2>
            <p v-if="sub" class="sub mt-0.5">{{ sub }}</p>
          </div>
          <button class="icon-btn -mr-1.5" aria-label="Close" @click="emit('close')"><X :size="18" /></button>
        </header>
        <div class="px-5 py-4 overflow-y-auto"><slot /></div>
        <footer v-if="$slots.footer" class="px-5 py-3 border-t border-line flex flex-wrap justify-end gap-2 bg-sunken/40 rounded-b-xl"><slot name="footer" /></footer>
      </div>
    </div>
  </Teleport>
</template>
