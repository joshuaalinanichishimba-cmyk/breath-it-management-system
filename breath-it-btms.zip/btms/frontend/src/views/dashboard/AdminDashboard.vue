<script setup lang="ts">
import { methodLabel } from '@/services/payments'
import { computed, ref } from 'vue'
import { RouterLink } from 'vue-router'
import type { ChartConfiguration } from 'chart.js'
import { Plus, Wallet, AlertTriangle } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import StatTile from '@/components/ui/StatTile.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import Avatar from '@/components/ui/Avatar.vue'
import ChartBox from '@/components/charts/ChartBox.vue'
import { tok } from '@/components/charts/palette'
import TodayTimeline from '@/components/domain/TodayTimeline.vue'
import PaymentFormModal from '@/components/domain/PaymentFormModal.vue'
import StudentFormModal from '@/components/domain/StudentFormModal.vue'
import { useDb } from '@/stores/db'
import { useAuth } from '@/stores/auth'
import { iso, fmtDate, monthLabel, relativeDay, addDays } from '@/services/dates'
import { kwacha, pct } from '@/services/format'
import { attendanceRate, monthlyRevenue, enrolmentTrend, weeklyAttendance, subjectAverages } from '@/services/analytics'
import { greeting, todayLabel } from './greeting'

const store = useDb(); const auth = useAuth()
const d = computed(() => store.db)
const today = iso()
const term = computed(() => d.value.settings.currentTerm)

const activeStudents = computed(() => d.value.students.filter((s) => s.status === 'active'))
const collectedTerm = computed(() => d.value.payments.filter((p) => p.status === 'verified' && p.term === term.value).reduce((a, p) => a + p.amount, 0))
const billedTerm = computed(() => d.value.charges.filter((c) => c.term === term.value).reduce((a, c) => a + c.amount, 0))
const outstanding = computed(() => d.value.students.reduce((a, s) => a + Math.max(0, store.balance(s.id)), 0))
const owing = computed(() => d.value.students.filter((s) => store.balance(s.id) > 0).length)
const pending = computed(() => d.value.payments.filter((p) => p.status === 'pending'))
const todayAtt = computed(() => d.value.attendance.filter((a) => a.date === today))
const activeClasses = computed(() => d.value.classes.filter((c) => c.active).length)
const activeTutors = computed(() => d.value.tutors.filter((t) => t.status === 'active').length)

const recentPayments = computed(() => [...d.value.payments].sort((a, b) => b.recordedAt.localeCompare(a.recordedAt)).slice(0, 6))
const recentRegs = computed(() => [...d.value.students].sort((a, b) => b.enrolmentDate.localeCompare(a.enrolmentDate)).slice(0, 5))
const lowAttendance = computed(() => {
  const since = addDays(today, -28)
  return activeStudents.value.map((s) => {
    const r = d.value.attendance.filter((a) => a.studentId === s.id && a.date >= since)
    return { s, rate: attendanceRate(r), n: r.length }
  }).filter((x) => x.n >= 5 && x.rate < d.value.settings.lowAttendanceThreshold).sort((a, b) => a.rate - b.rate).slice(0, 5)
})

const revenueCfg = computed<ChartConfiguration>(() => {
  const r = monthlyRevenue(d.value, 11, today)
  return { type: 'bar', data: { labels: r.keys.map(monthLabel), datasets: [{ label: 'Collected (K)', data: r.values, backgroundColor: tok('brand', 0.85), borderRadius: 4, maxBarThickness: 28 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { callback: (v) => 'K' + Number(v).toLocaleString() } }, x: { grid: { display: false } } } } }
})
const enrolCfg = computed<ChartConfiguration>(() => {
  const e = enrolmentTrend(d.value, 12, today)
  return { type: 'bar', data: { labels: e.keys.map(monthLabel), datasets: [
    { type: 'line', label: 'Total registered', data: e.cumulative, borderColor: tok('brand'), backgroundColor: tok('brand'), tension: 0.3, pointRadius: 2, yAxisID: 'y' },
    { type: 'bar', label: 'New registrations', data: e.added, backgroundColor: tok('info', 0.35), borderRadius: 3, maxBarThickness: 18, yAxisID: 'y' },
  ] }, options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } }, x: { grid: { display: false } } } } }
})
const attCfg = computed<ChartConfiguration>(() => {
  const w = weeklyAttendance(d.value.attendance, 6, today)
  return { type: 'line', data: { labels: w.map((x) => 'w/c ' + x.label), datasets: [{ label: 'Attendance %', data: w.map((x) => (Number.isFinite(x.rate) ? +x.rate.toFixed(1) : null)), borderColor: tok('ok'), backgroundColor: tok('ok', 0.12), fill: true, tension: 0.3, pointRadius: 3 }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { min: 50, max: 100, ticks: { callback: (v) => v + '%' } }, x: { grid: { display: false } } } } }
})
const perfCfg = computed<ChartConfiguration>(() => {
  const avgs = subjectAverages(d.value.assessments.filter((a) => a.term === term.value), store.subjectName)
  return { type: 'bar', data: { labels: avgs.map((a) => a.name), datasets: [{ label: 'Average %', data: avgs.map((a) => +a.avg.toFixed(1)), backgroundColor: avgs.map((a) => a.avg >= 60 ? tok('ok', 0.8) : a.avg >= 50 ? tok('warn', 0.8) : tok('bad', 0.8)), borderRadius: 3, maxBarThickness: 16 }] },
    options: { indexAxis: 'y', plugins: { legend: { display: false } }, scales: { x: { min: 0, max: 100, ticks: { callback: (v) => v + '%' } }, y: { grid: { display: false }, ticks: { autoSkip: false } } } } }
})

const perfHeight = computed(() => Math.max(240, new Set(d.value.assessments.filter((a) => a.term === term.value).map((a) => a.subjectId)).size * 24 + 50))
const showPay = ref(false); const showReg = ref(false)
</script>

<template>
  <div>
    <PageHeader :title="greeting('')" :sub="`${todayLabel()} · ${term}`">
      <button class="btn btn-secondary" @click="showReg = true"><Plus :size="15" />Register student</button>
      <button class="btn btn-primary" @click="showPay = true"><Wallet :size="15" />Record payment</button>
    </PageHeader>

    <section class="card card-pad mb-5">
      <div class="flex items-baseline justify-between mb-3">
        <h2 class="h-section">Today at the centre</h2>
        <RouterLink to="/timetable" class="text-[12.5px] text-brand hover:underline">Full timetable</RouterLink>
      </div>
      <TodayTimeline :lessons="d.lessons" can-take-register />
    </section>

    <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 mb-5">
      <StatTile label="Registered students" :value="d.students.length" :hint="`${activeStudents.length} active`" />
      <StatTile label="Tutors" :value="activeTutors" :hint="`${d.tutors.length} on record`" />
      <StatTile label="Active classes" :value="activeClasses" :hint="`${d.lessons.length} lessons a week`" />
      <StatTile :label="`Collected · ${term.replace(' 2026', '')}`" :value="kwacha(collectedTerm)" tone="ok" :hint="`of ${kwacha(billedTerm)} billed`" />
      <StatTile label="Outstanding fees" :value="kwacha(outstanding)" tone="bad" :hint="`${owing} students owing`" />
      <StatTile label="Today’s attendance" :value="todayAtt.length ? pct(attendanceRate(todayAtt)) : '—'" :hint="todayAtt.length ? `${todayAtt.length} marks so far` : 'No registers yet'" />
    </div>

    <RouterLink v-if="pending.length" to="/finance?tab=verify" class="card px-4 py-3 mb-5 flex items-center gap-3 border-warn/40 bg-warn-soft/50 hover:bg-warn-soft">
      <AlertTriangle :size="18" class="text-warn shrink-0" />
      <span class="text-[13.5px]"><b>{{ pending.length }} payments</b> ({{ kwacha(pending.reduce((a, p) => a + p.amount, 0)) }}) are waiting to be checked against the Mobile Money statement. They do not reduce balances until verified.</span>
    </RouterLink>

    <div class="grid lg:grid-cols-2 gap-4 mb-5">
      <section class="card card-pad"><h2 class="h-section">Monthly revenue</h2><p class="sub mb-3">Verified payments by month</p><ChartBox :config="revenueCfg" label="Monthly revenue bar chart" /></section>
      <section class="card card-pad"><h2 class="h-section">Enrolment</h2><p class="sub mb-3">New registrations and total students</p><ChartBox :config="enrolCfg" label="Enrolment trend chart" /></section>
      <section class="card card-pad"><h2 class="h-section">Attendance trend</h2><p class="sub mb-3">Share of lessons attended (present or late), weekly</p><ChartBox :config="attCfg" label="Weekly attendance line chart" /></section>
      <section class="card card-pad"><h2 class="h-section">Academic performance</h2><p class="sub mb-3">Average mark by subject, {{ term }}</p><ChartBox :config="perfCfg" :height="perfHeight" label="Average marks by subject" /></section>
    </div>

    <div class="grid lg:grid-cols-3 gap-4">
      <section class="card lg:col-span-2">
        <div class="flex items-baseline justify-between px-4 sm:px-5 pt-4 pb-2"><h2 class="h-section">Recent payments</h2><RouterLink to="/finance" class="text-[12.5px] text-brand hover:underline">All payments</RouterLink></div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Student</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th></tr></thead>
          <tbody><tr v-for="p in recentPayments" :key="p.id">
            <td><RouterLink :to="`/students/${p.studentId}`" class="font-medium hover:underline">{{ store.studentName(p.studentId) }}</RouterLink><div class="text-[12px] text-muted">{{ p.reference }}</div></td>
            <td class="tnum font-medium">{{ kwacha(p.amount) }}</td><td class="whitespace-nowrap">{{ methodLabel(p) }}<span v-if="p.channel === 'online'" class="badge badge-info ml-1.5">Online</span></td><td class="whitespace-nowrap">{{ fmtDate(p.date) }}</td><td><StatusBadge :status="p.status" /></td>
          </tr></tbody>
        </table></div>
      </section>
      <div class="grid gap-4 content-start">
        <section class="card card-pad">
          <h2 class="h-section mb-3">Recent registrations</h2>
          <ul class="grid gap-2.5">
            <li v-for="s in recentRegs" :key="s.id"><RouterLink :to="`/students/${s.id}`" class="flex items-center gap-2.5 group">
              <Avatar :name="`${s.firstName} ${s.lastName}`" :size="30" />
              <span class="flex-1 min-w-0"><span class="block text-[13px] font-medium group-hover:underline truncate">{{ s.firstName }} {{ s.lastName }}</span><span class="block text-[12px] text-muted">{{ store.gradeName(s.gradeId) }} · {{ relativeDay(s.enrolmentDate) }}</span></span>
            </RouterLink></li>
          </ul>
        </section>
        <section class="card card-pad">
          <h2 class="h-section">Frequently absent</h2><p class="sub mb-3">Below {{ d.settings.lowAttendanceThreshold }}% over the last 4 weeks</p>
          <ul v-if="lowAttendance.length" class="grid gap-2">
            <li v-for="x in lowAttendance" :key="x.s.id" class="flex items-center justify-between gap-2 text-[13px]">
              <RouterLink :to="`/students/${x.s.id}`" class="hover:underline truncate">{{ x.s.firstName }} {{ x.s.lastName }}</RouterLink>
              <span class="badge badge-bad tnum">{{ pct(x.rate) }}</span>
            </li>
          </ul>
          <p v-else class="text-[13px] text-muted">Everyone is above the threshold.</p>
        </section>
      </div>
    </div>

    <PaymentFormModal :open="showPay" @close="showPay = false" />
    <StudentFormModal :open="showReg" @close="showReg = false" />
  </div>
</template>
