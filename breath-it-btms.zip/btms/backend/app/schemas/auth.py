from pydantic import BaseModel, Field
from .common import ORM


class UserOut(ORM):
    id: str
    name: str
    email: str
    role: str
    linked_id: str | None = None


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)
