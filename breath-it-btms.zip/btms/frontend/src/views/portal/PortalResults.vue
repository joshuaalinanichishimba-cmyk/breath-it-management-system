<script setup lang="ts">
import { computed, ref } from 'vue'
import type { ChartConfiguration } from 'chart.js'
import { FileDown } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import ChildSwitcher from '@/components/domain/ChildSwitcher.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import ChartBox from '@/components/charts/ChartBox.vue'
import { series } from '@/components/charts/palette'
import { usePortalStudent } from '@/composables/usePortalStudent'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'
import { fmtDate } from '@/services/dates'
import { pct, gradeBand } from '@/services/format'
import { average, pctOf } from '@/services/analytics'
import { reportCardPdf } from '@/services/pdf'
import { saveFile } from '@/services/download'

const { student, isParent } = usePortalStudent(); const store = useDb(); const ui = useUi()
const term = ref(store.db.settings.currentTerm)
const all = computed(() => (student.value ? store.db.assessments.filter((a) => a.studentId === student.value!.id) : []))
const termResults = computed(() => all.value.filter((a) => a.term === term.value))
const bySubject = computed(() => (student.value?.subjectIds ?? []).map((sub) => {
  const rs = termResults.value.filter((a) => a.subjectId === sub).sort((a, b) => a.date.localeCompare(b.date))
  const prev = all.value.filter((a) => a.subjectId === sub && a.term < term.value)
  return { sub, rs, avg: average(rs.map(pctOf)), prevAvg: average(prev.map(pctOf)) }
}))
const cfg = computed<ChartConfiguration>(() => {
  const dates = [...new Set(all.value.map((a) => a.date))].sort()
  const colors = series()
  return { type: 'line', data: { labels: dates.map((d) => fmtDate(d, false)), datasets: (student.value?.subjectIds ?? []).map((sub, i) => ({
    label: store.subjectName(sub), data: dates.map((d) => { const r = all.value.find((a) => a.subjectId === sub && a.date === d); return r ? +pctOf(r).toFixed(1) : null }),
    borderColor: colors[i % colors.length], backgroundColor: colors[i % colors.length], spanGaps: true, tension: 0.3, pointRadius: 3 })) },
    options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 10 } } }, scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + '%' } }, x: { grid: { display: false } } } } }
})
async function download() {
  if (!student.value) return
  try { if ((await saveFile(`report-${student.value.studentNo}-${term.value.replace(/\s/g, '-')}.pdf`, reportCardPdf(store.db, student.value, term.value), 'application/pdf')) === 'saved') ui.success('Report card downloaded') }
  catch (e) { ui.error('Could not download the report', (e as Error).message) }
}
</script>
<template>
  <div>
    <PageHeader :title="isParent ? 'Results and tutor comments' : 'My results'" :sub="student ? `${student.firstName} ${student.lastName} · ${store.gradeName(student.gradeId)}` : ''">
      <select v-model="term" class="select w-auto" aria-label="Term"><option v-for="t in store.db.settings.terms" :key="t.name">{{ t.name }}</option></select>
      <button class="btn btn-primary" @click="download"><FileDown :size="15" />Report card (PDF)</button>
    </PageHeader>
    <ChildSwitcher />
    <section class="card card-pad mb-4"><h2 class="h-section">Progress by subject</h2><p class="sub mb-3">Every test and exam this year</p>
      <ChartBox v-if="all.length" :config="cfg" :height="260" label="Marks by subject over time" />
      <EmptyState v-else compact title="No results yet" /></section>
    <div class="grid md:grid-cols-2 gap-4">
      <section v-for="x in bySubject" :key="x.sub" class="card">
        <div class="flex items-start justify-between gap-3 px-4 sm:px-5 pt-4 pb-3">
          <div><h3 class="font-semibold">{{ store.subjectName(x.sub) }}</h3>
            <p class="text-[12px] text-muted">{{ store.tutorName(x.rs[0]?.tutorId ?? store.db.lessons.find((l) => l.classId === student?.classId && l.subjectId === x.sub)?.tutorId ?? '') }}</p></div>
          <div class="text-right">
            <div class="text-[20px] font-semibold tnum">{{ Number.isFinite(x.avg) ? pct(x.avg) : '—' }}</div>
            <div v-if="Number.isFinite(x.avg)" class="text-[12px]">
              <span :class="'text-' + gradeBand(x.avg).tone">{{ gradeBand(x.avg).label }}</span>
              <span v-if="Number.isFinite(x.prevAvg)" :class="x.avg >= x.prevAvg ? 'text-ok' : 'text-bad'"> · {{ x.avg >= x.prevAvg ? '▲' : '▼' }} {{ Math.abs(x.avg - x.prevAvg).toFixed(0) }} pts</span>
            </div>
          </div>
        </div>
        <ul class="border-t border-line divide-y divide-line">
          <li v-for="r in x.rs" :key="r.id" class="px-4 sm:px-5 py-2.5">
            <div class="flex justify-between gap-3 text-[13px]"><span>{{ r.title }} <span class="text-muted">· {{ fmtDate(r.date, false) }}</span></span><span class="tnum font-medium">{{ r.marks }}/{{ r.maxMarks }} ({{ pct(pctOf(r)) }})</span></div>
            <p v-if="r.comment" class="text-[12.5px] text-muted mt-0.5">“{{ r.comment }}”</p>
          </li>
          <li v-if="!x.rs.length" class="px-4 sm:px-5 py-3 text-[13px] text-muted">No assessments in {{ term }}.</li>
        </ul>
      </section>
    </div>
  </div>
</template>
