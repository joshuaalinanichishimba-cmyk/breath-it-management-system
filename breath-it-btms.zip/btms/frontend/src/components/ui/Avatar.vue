<script setup lang="ts">
import { computed } from 'vue'
import { initials } from '@/services/format'
const props = withDefaults(defineProps<{ name: string; size?: number }>(), { size: 32 })
const hue = computed(() => [...props.name].reduce((a, c) => a + c.charCodeAt(0), 0) % 4)
const tones = ['bg-brand-soft text-brand', 'bg-info-soft text-info', 'bg-ok-soft text-ok', 'bg-warn-soft text-warn']
</script>
<template>
  <span :class="['inline-flex items-center justify-center rounded-full font-semibold shrink-0', tones[hue]]"
    :style="{ width: size + 'px', height: size + 'px', fontSize: Math.round(size * 0.38) + 'px' }">{{ initials(name) }}</span>
</template>
