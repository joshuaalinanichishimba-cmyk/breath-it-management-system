<script setup lang="ts">
import { methodLabel } from '@/services/payments'
import { computed, ref } from 'vue'
import { Smartphone } from 'lucide-vue-next'
import PageHeader from '@/components/ui/PageHeader.vue'
import ChildSwitcher from '@/components/domain/ChildSwitcher.vue'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import ReceiptModal from '@/components/domain/ReceiptModal.vue'
import PayNowModal from '@/components/domain/PayNowModal.vue'
import { Wallet } from 'lucide-vue-next'
import { usePortalStudent } from '@/composables/usePortalStudent'
import { useDb } from '@/stores/db'
import type { Payment } from '@/types'
import { fmtDate } from '@/services/dates'
import { kwacha } from '@/services/format'

const { student, children, isParent } = usePortalStudent(); const store = useDb()
const terms = computed(() => (student.value ? [...new Set(store.db.charges.filter((c) => c.studentId === student.value!.id).map((c) => c.term))].sort().reverse() : []))
const payments = computed(() => (student.value ? store.db.payments.filter((p) => p.studentId === student.value!.id).sort((a, b) => b.date.localeCompare(a.date)) : []))
const charges = computed(() => (student.value ? store.db.charges.filter((c) => c.studentId === student.value!.id).sort((a, b) => b.issuedOn.localeCompare(a.issuedOn)) : []))
const familyBalance = computed(() => children.value.reduce((a, c) => a + Math.max(0, store.balance(c.id)), 0))
const receipt = ref<Payment | null>(null)
const payOpen = ref(false)
const canPayOnline = computed(() => store.db.settings.onlinePayments.enabled)
</script>
<template>
  <div>
    <PageHeader :title="isParent ? 'Fees and receipts' : 'My payments'" :sub="isParent && children.length > 1 ? `Family balance ${kwacha(familyBalance)}` : ''">
      <button v-if="canPayOnline" class="btn btn-primary" @click="payOpen = true"><Wallet :size="15" />Pay now</button>
    </PageHeader>
    <ChildSwitcher />
    <div v-if="student" class="grid lg:grid-cols-[1fr_320px] gap-4 items-start">
      <div class="grid gap-4">
        <div class="grid sm:grid-cols-3 gap-3">
          <div v-for="t in terms" :key="t" class="card px-4 py-3">
            <div class="text-[12.5px] text-muted">{{ t }}</div>
            <div :class="['text-[19px] font-semibold tnum mt-0.5', store.balance(student.id, t) > 0 ? 'text-bad' : 'text-ok']">{{ store.balance(student.id, t) > 0 ? kwacha(store.balance(student.id, t)) + ' due' : 'Paid in full' }}</div>
            <div class="text-[12px] text-muted tnum">{{ kwacha(store.paid(student.id, t)) }} paid of {{ kwacha(store.billed(student.id, t)) }}</div>
          </div>
        </div>
        <section class="card">
          <h2 class="h-section px-4 sm:px-5 pt-4 pb-2">Payments</h2>
          <div class="table-wrap"><table class="tbl">
            <thead><tr><th>Date</th><th>For</th><th>Method</th><th class="text-right">Amount</th><th>Status</th><th></th></tr></thead>
            <tbody><tr v-for="p in payments" :key="p.id">
              <td class="whitespace-nowrap">{{ fmtDate(p.date) }}</td><td class="whitespace-nowrap">{{ p.category }} · {{ p.term }}</td><td class="whitespace-nowrap">{{ methodLabel(p) }}<span v-if="p.channel === 'online'" class="badge badge-info ml-1.5">Online</span></td>
              <td class="text-right tnum font-medium">{{ kwacha(p.amount) }}</td><td><StatusBadge :status="p.status" /></td>
              <td class="text-right"><button v-if="p.status === 'verified'" class="btn btn-ghost btn-sm" @click="receipt = p">Receipt</button></td>
            </tr></tbody>
          </table></div>
          <EmptyState v-if="!payments.length" compact title="No payments yet" />
        </section>
        <section class="card">
          <h2 class="h-section px-4 sm:px-5 pt-4 pb-2">Fees charged</h2>
          <div class="table-wrap"><table class="tbl">
            <thead><tr><th>Description</th><th>Due</th><th class="text-right">Amount</th></tr></thead>
            <tbody><tr v-for="c in charges" :key="c.id"><td>{{ c.description }}</td><td class="whitespace-nowrap">{{ fmtDate(c.dueDate) }}</td><td class="text-right tnum">{{ kwacha(c.amount) }}</td></tr></tbody>
          </table></div>
        </section>
      </div>
      <aside class="card card-pad">
        <div class="flex items-center gap-2"><Smartphone :size="17" class="text-brand" /><h2 class="h-section">Pay from your phone</h2></div>
        <p class="text-[13px] mt-2">Pay with <b>Airtel Money</b>, <b>MTN MoMo</b>, <b>Zamtel Kwacha</b>, a bank card or a bank transfer. Mobile money and card payments are confirmed instantly and your receipt appears here straight away.</p>
        <button v-if="canPayOnline" class="btn btn-primary w-full mt-3" @click="payOpen = true">Pay {{ store.balance(student.id) > 0 ? kwacha(store.balance(student.id)) : 'fees' }}</button>
        <p class="text-[12px] text-muted mt-3">You can still pay at the office in cash. Bank transfers show as “awaiting verification” until the office finds them on the statement.</p>
      </aside>
    </div>
    <ReceiptModal :payment="receipt" @close="receipt = null" />
    <PayNowModal :open="payOpen" :students="children" :initial-student-id="student?.id" @close="payOpen = false" />
  </div>
</template>
