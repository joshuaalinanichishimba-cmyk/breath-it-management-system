const pad = (n: number) => String(n).padStart(2, '0')

/** Local calendar date as YYYY-MM-DD (never UTC-shifted). */
export function iso(d: Date = new Date()): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}
export function parseISO(s: string): Date {
  const [y, m, d] = s.slice(0, 10).split('-').map(Number)
  return new Date(y, m - 1, d)
}
export function addDays(s: string, n: number): string {
  const d = parseISO(s)
  d.setDate(d.getDate() + n)
  return iso(d)
}
/** 1 = Monday … 7 = Sunday */
export function isoWeekday(s: string): number {
  const w = parseISO(s).getDay()
  return w === 0 ? 7 : w
}
export const DAY_NAMES = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
export const DAY_SHORT = ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

export function fmtDate(s?: string, withYear = true): string {
  if (!s) return '—'
  const d = parseISO(s)
  return `${d.getDate()} ${MONTHS[d.getMonth()]}${withYear ? ' ' + d.getFullYear() : ''}`
}
export function fmtDateTime(s?: string): string {
  if (!s) return '—'
  const d = new Date(s)
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}, ${pad(d.getHours())}:${pad(d.getMinutes())}`
}
export function monthKey(s: string): string { return s.slice(0, 7) }
export function monthLabel(key: string): string {
  const [y, m] = key.split('-').map(Number)
  return `${MONTHS[m - 1]} ${String(y).slice(2)}`
}
export function lastMonths(n: number, from: string = iso()): string[] {
  const d = parseISO(from)
  const out: string[] = []
  for (let i = n - 1; i >= 0; i--) {
    const x = new Date(d.getFullYear(), d.getMonth() - i, 1)
    out.push(`${x.getFullYear()}-${pad(x.getMonth() + 1)}`)
  }
  return out
}
/** Monday of the week containing s */
export function weekStart(s: string): string { return addDays(s, 1 - isoWeekday(s)) }
export function ageFrom(dob: string, today = iso()): number {
  const a = parseISO(dob), b = parseISO(today)
  let age = b.getFullYear() - a.getFullYear()
  if (b.getMonth() < a.getMonth() || (b.getMonth() === a.getMonth() && b.getDate() < a.getDate())) age--
  return age
}
export function timeToMinutes(t: string): number { const [h, m] = t.split(':').map(Number); return h * 60 + m }
export function nowTime(): string { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}` }
export function relativeDay(s: string, today = iso()): string {
  if (s === today) return 'Today'
  if (s === addDays(today, -1)) return 'Yesterday'
  if (s === addDays(today, 1)) return 'Tomorrow'
  return fmtDate(s, false)
}
