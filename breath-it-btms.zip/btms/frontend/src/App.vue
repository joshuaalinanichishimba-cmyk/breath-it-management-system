<script setup lang="ts">
import { watch } from 'vue'
import ToastHost from '@/components/ui/ToastHost.vue'
import ConfirmHost from '@/components/ui/ConfirmHost.vue'
import { useDb } from '@/stores/db'
import { applyBrand } from '@/services/brand'

const store = useDb()
watch(() => store.db.settings.brand.primary, (c) => applyBrand(c), { immediate: true })
</script>
<template>
  <RouterView />
  <ToastHost />
  <ConfirmHost />
</template>
