/** For student + parent portals: which learner are we looking at? Parents switch between linked children. */
import { computed, watchEffect } from 'vue'
import { useAuth } from '@/stores/auth'
import { useDb } from '@/stores/db'
import { useUi } from '@/stores/ui'

export function usePortalStudent() {
  const auth = useAuth(); const store = useDb(); const ui = useUi()
  const children = computed(() => auth.role === 'parent' ? store.db.students.filter((s) => s.parentId === auth.user?.linkedId) : store.db.students.filter((s) => s.id === auth.user?.linkedId))
  watchEffect(() => {
    if (!children.value.length) return
    if (!ui.selectedChildId || !children.value.some((c) => c.id === ui.selectedChildId)) ui.selectedChildId = children.value[0].id
  })
  const student = computed(() => children.value.find((c) => c.id === ui.selectedChildId) ?? children.value[0] ?? null)
  return { children, student, isParent: computed(() => auth.role === 'parent') }
}
