/** Brand colour maths + theme injection. One primary colour drives every brand token in light and dark mode. */
type RGB = [number, number, number]

export function hexToRgb(hex: string): RGB | null {
  const m = hex.trim().replace('#', '').match(/^([0-9a-f]{3}|[0-9a-f]{6})$/i)
  if (!m) return null
  const h = m[1].length === 3 ? m[1].split('').map((c) => c + c).join('') : m[1]
  return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as RGB
}
export const rgbToHex = (c: RGB) => '#' + c.map((v) => Math.round(v).toString(16).padStart(2, '0')).join('')
const mix = (a: RGB, b: RGB, t: number): RGB => [0, 1, 2].map((i) => a[i] + (b[i] - a[i]) * t) as RGB
const lum = (c: RGB) => {
  const f = (v: number) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4 }
  return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2])
}
export function contrast(a: RGB, b: RGB): number { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05) }
const v = (c: RGB) => c.map(Math.round).join(' ')

const WHITE: RGB = [255, 255, 255]
const INK: RGB = [29, 26, 47]
const DARK_BG: RGB = [27, 26, 38]

export function brandTokens(hex: string) {
  const c = hexToRgb(hex) ?? [73, 58, 143]
  const ink = contrast(c, WHITE) >= 3.2 ? WHITE : INK
  // light mode: darken very light colours so brand text stays readable on white
  let light = c
  while (contrast(light, WHITE) < 3.2 && lum(light) > 0.05) light = mix(light, INK, 0.12)
  const lightInk = contrast(light, WHITE) >= 3.2 ? WHITE : INK
  // dark mode: lighten until readable on the dark surface
  let dark = c
  while (contrast(dark, DARK_BG) < 4.5 && lum(dark) < 0.9) dark = mix(dark, WHITE, 0.12)
  return {
    light: { brand: v(light), soft: v(mix(light, WHITE, 0.88)), ink: v(lightInk) },
    dark: { brand: v(dark), soft: v(mix(c, DARK_BG, 0.72)), ink: v(contrast(dark, WHITE) >= 3.2 ? WHITE : [19, 18, 27]) },
    rawContrast: contrast(c, ink),
  }
}

export function applyBrand(hex: string) {
  const t = brandTokens(hex)
  let el = document.getElementById('brand-theme') as HTMLStyleElement | null
  if (!el) { el = document.createElement('style'); el.id = 'brand-theme'; document.head.appendChild(el) }
  const l = `--brand: ${t.light.brand}; --brand-soft: ${t.light.soft}; --brand-ink: ${t.light.ink};`
  const d = `--brand: ${t.dark.brand}; --brand-soft: ${t.dark.soft}; --brand-ink: ${t.dark.ink};`
  el.textContent = `:root { ${l} }\n@media (prefers-color-scheme: dark) { :root:not([data-theme='light']) { ${d} } }\n:root[data-theme='dark'] { ${d} }`
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', hex)
}

/** Finds the most prominent saturated colour in a logo (ignores white, black and greys). */
export function dominantColour(dataUrl: string): Promise<string | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.onload = () => {
      const size = 64
      const cv = document.createElement('canvas'); cv.width = size; cv.height = size
      const ctx = cv.getContext('2d'); if (!ctx) return resolve(null)
      ctx.drawImage(img, 0, 0, size, size)
      const { data } = ctx.getImageData(0, 0, size, size)
      const buckets = new Map<string, { n: number; sum: RGB }>()
      for (let i = 0; i < data.length; i += 4) {
        const [r, g, b, a] = [data[i], data[i + 1], data[i + 2], data[i + 3]]
        if (a < 128) continue
        const max = Math.max(r, g, b), min = Math.min(r, g, b)
        const sat = max === 0 ? 0 : (max - min) / max
        if (sat < 0.25 || max < 40 || (max > 235 && sat < 0.35)) continue
        const key = [r >> 5, g >> 5, b >> 5].join(',')
        const bk = buckets.get(key) ?? { n: 0, sum: [0, 0, 0] as RGB }
        bk.n++; bk.sum = [bk.sum[0] + r, bk.sum[1] + g, bk.sum[2] + b]; buckets.set(key, bk)
      }
      const best = [...buckets.values()].sort((a, b) => b.n - a.n)[0]
      resolve(best ? rgbToHex(best.sum.map((x) => x / best.n) as RGB) : null)
    }
    img.onerror = () => resolve(null)
    img.src = dataUrl
  })
}

/** Downscale an uploaded logo so it fits comfortably in local storage and PDFs. */
export function resizeLogo(file: File, max = 320): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('Could not read the file.'))
    reader.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('That file is not an image we can read. Use PNG or JPG.'))
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height))
        const cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k)
        cv.getContext('2d')!.drawImage(img, 0, 0, cv.width, cv.height)
        resolve(cv.toDataURL('image/png'))
      }
      img.src = reader.result as string
    }
    reader.readAsDataURL(file)
  })
}
