<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { CheckCircle2, MessageCircle } from 'lucide-vue-next'
import BrandMark from '@/components/ui/BrandMark.vue'
import { useDb } from '@/stores/db'
import type { LeadSource } from '@/types'
import { normalisePhone } from '@/services/payments'
import { waLink } from '@/services/whatsapp'
import { kwacha } from '@/services/format'

const store = useDb()
const f = reactive({ parentName: '', phone: '', childName: '', gradeId: '', subjectIds: [] as string[], source: '' as LeadSource | '', code: '', website: '' })
const err = ref(''); const done = ref(false)
const grades = computed(() => store.db.grades.filter((g) => g.active).sort((a, b) => a.order - b.order))
const subjects = computed(() => store.db.subjects.filter((s) => s.active && s.gradeIds.includes(f.gradeId)))
const fee = computed(() => store.db.feeStructures.find((x) => x.gradeId === f.gradeId && x.category === 'Tuition')?.amount)
function submit() {
  err.value = ''
  if (f.website) { done.value = true; return } // honeypot: bots fill hidden fields
  if (!f.parentName.trim() || !f.childName.trim()) return (err.value = 'Please enter your name and your child’s name.')
  if (!normalisePhone(f.phone)) return (err.value = 'Please enter a Zambian phone number we can call or WhatsApp, e.g. 0977 123 456.')
  if (!f.gradeId) return (err.value = 'Please choose your child’s grade.')
  const referrer = Object.entries(store.db.referralCodes).find(([, c]) => c.toLowerCase() === f.code.trim().toLowerCase())?.[0]
  store.addLead({ childName: f.childName.trim(), parentName: f.parentName.trim(), phone: f.phone.trim(), gradeId: f.gradeId, subjectIds: f.subjectIds,
    source: referrer ? 'Referral' : (f.source || 'Website'), referredByParentId: referrer, notes: f.code && !referrer ? `Gave code “${f.code}” (not recognised)` : 'Submitted through the online enquiry form' }, true)
  done.value = true
}
</script>
<template>
  <div class="min-h-full bg-canvas">
    <header class="bg-brand"><div class="max-w-2xl mx-auto px-5 py-5"><BrandMark on-brand :size="36" /></div></header>
    <main class="max-w-2xl mx-auto px-5 py-8">
      <div v-if="done" class="card card-pad text-center py-10">
        <CheckCircle2 :size="40" class="mx-auto text-ok" />
        <h1 class="text-[22px] font-semibold mt-3">Thank you, {{ f.parentName.split(' ')[0] || 'we have your details' }}</h1>
        <p class="sub mt-2 max-w-md mx-auto">We will call or WhatsApp you within one working day to arrange a free trial lesson for {{ f.childName || 'your child' }}.</p>
        <a :href="waLink(store.db.settings.phone, `Good day, I have just sent an enquiry for ${f.childName} (${store.gradeName(f.gradeId)}).`)" target="_blank" rel="noopener noreferrer" class="btn btn-primary mt-5"><MessageCircle :size="15" />Message us on WhatsApp now</a>
      </div>
      <template v-else>
        <h1 class="text-[26px] font-semibold tracking-[-0.015em]">Enquire about lessons</h1>
        <p class="sub mt-1.5 max-w-[60ch]">{{ store.db.settings.centreName }}, {{ store.db.settings.address }}. Grades 7, 8, 9, 12 and GCE. Send your details and we will arrange a free trial lesson.</p>
        <form class="card card-pad mt-6 grid sm:grid-cols-2 gap-4" @submit.prevent="submit">
          <div><label class="label" for="eq-p">Your name</label><input id="eq-p" v-model="f.parentName" class="input h-10" autocomplete="name" /></div>
          <div><label class="label" for="eq-ph">Phone or WhatsApp</label><input id="eq-ph" v-model="f.phone" class="input h-10" inputmode="tel" autocomplete="tel" placeholder="0977 123 456" /></div>
          <div><label class="label" for="eq-c">Child’s name</label><input id="eq-c" v-model="f.childName" class="input h-10" /></div>
          <div><label class="label" for="eq-g">Grade</label><select id="eq-g" v-model="f.gradeId" class="select h-10"><option value="" disabled>Choose…</option><option v-for="g in grades" :key="g.id" :value="g.id">{{ g.name }}</option></select>
            <p v-if="fee" class="text-[12px] text-muted mt-1">Tuition from {{ kwacha(fee) }} per term</p></div>
          <div v-if="subjects.length" class="sm:col-span-2"><span class="label">Subjects needed</span>
            <div class="flex flex-wrap gap-2"><label v-for="s in subjects" :key="s.id" :class="['flex items-center h-8 px-3 rounded-full border text-[13px] cursor-pointer', f.subjectIds.includes(s.id) ? 'border-brand bg-brand-soft' : 'border-line bg-surface']"><input v-model="f.subjectIds" type="checkbox" :value="s.id" class="sr-only" />{{ s.name }}</label></div></div>
          <div><label class="label" for="eq-s">How did you hear about us?</label><select id="eq-s" v-model="f.source" class="select h-10"><option value="">Choose…</option><option>Facebook</option><option>WhatsApp</option><option>Walk-in</option><option>Flyer</option><option>School visit</option><option value="Referral">A friend or family</option></select></div>
          <div><label class="label" for="eq-code">Referral code (optional)</label><input id="eq-code" v-model="f.code" class="input h-10 uppercase" placeholder="e.g. BI-BAN11" /></div>
          <input v-model="f.website" type="text" name="website" tabindex="-1" autocomplete="off" class="hidden" aria-hidden="true" />
          <p v-if="err" class="sm:col-span-2 field-error text-[13px]" role="alert">{{ err }}</p>
          <button class="btn btn-primary h-10 sm:col-span-2">Send enquiry</button>
        </form>
        <p class="text-[12px] text-muted mt-4">We use your details only to contact you about lessons. <RouterLink to="/login" class="text-brand hover:underline">Staff and parent sign-in</RouterLink></p>
      </template>
    </main>
  </div>
</template>
